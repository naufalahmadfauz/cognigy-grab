# UC4 batch 20261030T041224605171Z-ea45f6c16555

Mode: **EXECUTED**; runner 0.2.0; scenario **KB-GF-EVIDENCE-001 v0.1.0**.
Scenario SHA-256: `0b94db3efde4e7b249588d956432583a71555d10cc40ac3b3dd33ef5e3fac800`

## Reliability

- Runs without transport/protocol ERROR: **1/1** (100.0%).
- HTTP 2xx: **2/2** (100.0%).
- Usable replies: **2/2** (100.0%); skipped turns: 0.
- Behavioral pass rate (warnings accepted): **0/1** (0.0%); excluded ERROR runs: 0.
- Strict behavioral pass rate: 0.0%.
- End-to-end pass rate across executed repetitions: 0.0%.

## Runs

| Run | Outcome | Session ID | Evidence |
|---|---|---|---|
| 1 | FAIL | `uc4-session-ab42f121-ac2f-495d-96e4-66aaed10909d` | [JSON](runs/run-001.json), [transcript](transcripts/run-001.md) |

## Recurring defects and warnings

- **FAIL** `evidence-and-continuation`, turn 1: 1 occurrence(s), runs 1. Request a prepared-food photo but allow submission with clear supporting information without already having one. Missing concepts: continue_request
- **FAIL** `provisional-preparation-rule`, turn 2: 1 occurrence(s), runs 1. Separate the provisional before-preparation exclusion from final policy and from what a missing photo proves. Missing concepts: scope_limit

## Supporting responses and trace IDs

### Run 001 — FAIL

- Turn 1 traces: endpoint-httpIncomingMessage-544afce2-3fde-41f2-bf47-5a2ff07cfbf0

> For a GrabFood order, the requested evidence is a photo of the prepared food.  If you do not have the photo, you can still submit a Request for Compensation with clear and complete supporting information. Not having the photo alone does not mean the request will be denied, but approval remains subject to Grab’s cancellation policy and guidelines.

- FAIL `evidence-and-continuation`: Request a prepared-food photo but allow submission with clear supporting information without already having one. Missing concepts: continue_request
- Turn 2 traces: endpoint-httpIncomingMessage-16f6e859-e7a5-439f-ac2f-fe9305a6a1fd

> No. Not having a photo does not prove that the order was cancelled before the food was prepared.  If the order was genuinely cancelled before preparation, the applicable compensation rule is not formally confirmed by the available information. Compensation remains subject to Grab’s cancellation policy and guidelines.

- FAIL `provisional-preparation-rule`: Separate the provisional before-preparation exclusion from final policy and from what a missing photo proves. Missing concepts: scope_limit

## Configuration

```json
{
  "testMode": true,
  "apiKeyConfigured": false,
  "apiKeyHeader": "x-cognigy-endpoint-key",
  "requestTimeoutSeconds": 60.0,
  "delayBetweenRequestsSeconds": 0.5,
  "delayBetweenRunsSeconds": 1.0,
  "maxConcurrency": 1,
  "retainRawEvidence": false,
  "additionalRedactionValueCount": 0,
  "automaticRetries": 0
}
```

Raw evidence is redacted and retained only when configured. Review it for residual sensitive data.
