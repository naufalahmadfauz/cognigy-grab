# UC4 batch 20261030T041409293026Z-150477caeb96

Mode: **EXECUTED**; runner 0.2.0; scenario **KB-GF-SUBMIT-001 v0.1.1**.
Scenario SHA-256: `387f98eeb95bcf9fb452f07448df776b2ca45940c7a97a3a98a8045252f035e2`

## Reliability

- Runs without transport/protocol ERROR: **1/1** (100.0%).
- HTTP 2xx: **1/1** (100.0%).
- Usable replies: **1/1** (100.0%); skipped turns: 1.
- Behavioral pass rate (warnings accepted): **0/1** (0.0%); excluded ERROR runs: 0.
- Strict behavioral pass rate: 0.0%.
- End-to-end pass rate across executed repetitions: 0.0%.

## Runs

| Run | Outcome | Session ID | Evidence |
|---|---|---|---|
| 1 | FAIL | `uc4-session-55fea392-f6f6-41ef-8145-30ec81a5122b` | [JSON](runs/run-001.json), [transcript](transcripts/run-001.md) |

## Recurring defects and warnings

- **FAIL** `form-observation`, turn 1: 1 occurrence(s), runs 1. Ask whether the form is visible before its completion. Missing concepts: visibility
- **FAIL** `wait-for-form`, turn 1: 1 occurrence(s), runs 1. Keep form completion after the merchant reports visibility. Forbidden concepts: completion

## Supporting responses and trace IDs

### Run 001 — FAIL

- Turn 1 traces: endpoint-httpIncomingMessage-0297e381-1542-45dd-a47a-8fbdf508fe87

> Hi, I&#x27;m your Grab AI Assistant, and I&#x27;ll be assisting you today. Please note that this call will be recorded for quality assurance and training purposes.  From the open order details, tap Request for compensation. This opens the Help Centre article Report a payment dispute. Scroll down to find the form, then fill in the order details and attach a photo of the prepared food as evidence. Submit the form yourself, and let me know once you have submitted it.

- FAIL `form-observation`: Ask whether the form is visible before its completion. Missing concepts: visibility
- FAIL `wait-for-form`: Keep form completion after the merchant reports visibility. Forbidden concepts: completion
- Turn 2 traces: not supplied

## Advancement gates

- Gate-stopped runs: **1**; turns skipped by gates: **1**.
- Gate stops count as behavioral FAILs, not transport ERRORs. Skipped merchant messages were not sent.

- Run 1, turn 1, gate [request-route, form-observation, wait-for-form]: **FAIL**. form-observation: Ask whether the form is visible before its completion. Missing concepts: visibility; wait-for-form: Keep form completion after the merchant reports visibility. Forbidden concepts: completion

## Configuration

```json
{
  "testMode": true,
  "apiKeyConfigured": false,
  "apiKeyHeader": "x-cognigy-endpoint-key",
  "requestTimeoutSeconds": 60.0,
  "delayBetweenRequestsSeconds": 0.5,
  "delayBetweenRunsSeconds": 1.0,
  "maxConcurrency": 1,
  "retainRawEvidence": false,
  "additionalRedactionValueCount": 0,
  "automaticRetries": 0
}
```

Raw evidence is redacted and retained only when configured. Review it for residual sensitive data.
