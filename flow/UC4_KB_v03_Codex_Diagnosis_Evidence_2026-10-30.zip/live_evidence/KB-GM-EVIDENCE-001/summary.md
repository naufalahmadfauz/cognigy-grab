# UC4 batch 20261030T041243671331Z-4060f4043d1b

Mode: **EXECUTED**; runner 0.2.0; scenario **KB-GM-EVIDENCE-001 v0.1.0**.
Scenario SHA-256: `7e712258845b1406af9d9345e7e4e53d9c465ed39ee95d6edc0c6a1855d978c9`

## Reliability

- Runs without transport/protocol ERROR: **1/1** (100.0%).
- HTTP 2xx: **2/2** (100.0%).
- Usable replies: **2/2** (100.0%); skipped turns: 0.
- Behavioral pass rate (warnings accepted): **0/1** (0.0%); excluded ERROR runs: 0.
- Strict behavioral pass rate: 0.0%.
- End-to-end pass rate across executed repetitions: 0.0%.

## Runs

| Run | Outcome | Session ID | Evidence |
|---|---|---|---|
| 1 | FAIL | `uc4-session-5dc909b7-f050-445b-92b7-10d72f2c343d` | [JSON](runs/run-001.json), [transcript](transcripts/run-001.md) |

## Recurring defects and warnings

- **FAIL** `provisional-packing-rule`, turn 2: 1 occurrence(s), runs 1. Separate the provisional before-packing exclusion from final policy and from what a missing photo proves. Missing concepts: scope_limit

## Supporting responses and trace IDs

### Run 001 — FAIL

- Turn 1 traces: endpoint-httpIncomingMessage-2224a40a-5c0d-4dd8-b267-f0688f5258c5
- Turn 2 traces: endpoint-httpIncomingMessage-e08c16da-ef37-42a5-a147-1bc3b8548a79

> Let me verify what the guidance confirms about evidence and eligibility. No. Not having a photo does not prove that the order was cancelled before the items were packed.  Even if the cancellation occurred before packing, compensation for an individual order is not formally confirmed automatically. Eligibility remains subject to Grab’s applicable Cancellations Policy and Guidelines and review of the submitted information.

- FAIL `provisional-packing-rule`: Separate the provisional before-packing exclusion from final policy and from what a missing photo proves. Missing concepts: scope_limit

## Configuration

```json
{
  "testMode": true,
  "apiKeyConfigured": false,
  "apiKeyHeader": "x-cognigy-endpoint-key",
  "requestTimeoutSeconds": 60.0,
  "delayBetweenRequestsSeconds": 0.5,
  "delayBetweenRunsSeconds": 1.0,
  "maxConcurrency": 1,
  "retainRawEvidence": false,
  "additionalRedactionValueCount": 0,
  "automaticRetries": 0
}
```

Raw evidence is redacted and retained only when configured. Review it for residual sensitive data.
