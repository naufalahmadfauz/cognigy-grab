# UC4 batch 20261030T041303773072Z-be045c1ec878

Mode: **EXECUTED**; runner 0.2.0; scenario **KB-GM-SPLIT-001 v0.1.0**.
Scenario SHA-256: `ee31d6f8e19d7da248b3eceec77cb51f699511a050f4f0cf0a72694e31c8a69d`

## Reliability

- Runs without transport/protocol ERROR: **1/1** (100.0%).
- HTTP 2xx: **1/1** (100.0%).
- Usable replies: **1/1** (100.0%); skipped turns: 0.
- Behavioral pass rate (warnings accepted): **0/1** (0.0%); excluded ERROR runs: 0.
- Strict behavioral pass rate: 0.0%.
- End-to-end pass rate across executed repetitions: 0.0%.

## Runs

| Run | Outcome | Session ID | Evidence |
|---|---|---|---|
| 1 | FAIL | `uc4-session-9d7f4300-7f9d-436d-b6d9-49d30cf3ba20` | [JSON](runs/run-001.json), [transcript](transcripts/run-001.md) |

## Recurring defects and warnings

- **FAIL** `conditional-automatic-route`, turn 1: 1 occurrence(s), runs 1. Eligible split cancellations are reimbursed automatically with no merchant action and weekly App-record updates. Missing concepts: eligible, automatic, no_action, app, weekly

## Supporting responses and trace IDs

### Run 001 — FAIL

- Turn 1 traces: endpoint-httpIncomingMessage-6a20f1e6-cf0b-42a2-993e-fb156faee3ed

> I’ll check the applicable GrabMart compensation guidance. Is this about a GrabFood or GrabMart cancelled order?

- FAIL `conditional-automatic-route`: Eligible split cancellations are reimbursed automatically with no merchant action and weekly App-record updates. Missing concepts: eligible, automatic, no_action, app, weekly

## Configuration

```json
{
  "testMode": true,
  "apiKeyConfigured": false,
  "apiKeyHeader": "x-cognigy-endpoint-key",
  "requestTimeoutSeconds": 60.0,
  "delayBetweenRequestsSeconds": 0.5,
  "delayBetweenRunsSeconds": 1.0,
  "maxConcurrency": 1,
  "retainRawEvidence": false,
  "additionalRedactionValueCount": 0,
  "automaticRetries": 0
}
```

Raw evidence is redacted and retained only when configured. Review it for residual sensitive data.
