# UC4 batch 20261030T041420349950Z-6977d6103056

Mode: **EXECUTED**; runner 0.2.0; scenario **KB-GM-SUBMIT-001 v0.1.1**.
Scenario SHA-256: `cc84ab1be8957a2579e91e1dbe2b8d7c99121d83a9768e74e4c6824b6c098f47`

## Reliability

- Runs without transport/protocol ERROR: **1/1** (100.0%).
- HTTP 2xx: **2/2** (100.0%).
- Usable replies: **2/2** (100.0%); skipped turns: 0.
- Behavioral pass rate (warnings accepted): **1/1** (100.0%); excluded ERROR runs: 0.
- Strict behavioral pass rate: 0.0%.
- End-to-end pass rate across executed repetitions: 100.0%.

## Runs

| Run | Outcome | Session ID | Evidence |
|---|---|---|---|
| 1 | PASS_WITH_WARNINGS | `uc4-session-f007558b-b8e6-4281-8a18-85cd5d9d61df` | [JSON](runs/run-001.json), [transcript](transcripts/run-001.md) |

## Recurring defects and warnings

- **WARN** `partial-policy-review`, turn 1: 1 occurrence(s), runs 1. Preserve the observed notice for separate human review of its certainty. Forbidden concepts: partial_notice

## Supporting responses and trace IDs

### Run 001 — PASS_WITH_WARNINGS

- Turn 1 traces: endpoint-httpIncomingMessage-81983f66-608f-438d-9e7a-5053616f2ee5

> Hi, I&#x27;m your Grab AI Assistant, and I&#x27;ll be assisting you today. Please note that this call will be recorded for quality assurance and training purposes.  Please note that compensation will be partial, based on the assessment of the perishable items.  Tap “Request for compensation” in the open order. This will open the Help Centre article “Report a payment dispute.” Scroll down to find the form. Is the form visible?

- WARN `partial-policy-review`: Preserve the observed notice for separate human review of its certainty. Forbidden concepts: partial_notice
- Turn 2 traces: endpoint-httpIncomingMessage-cce63183-d2a9-4e25-a9ff-8d43b403a1d5

## Advancement gates

- Gate-stopped runs: **0**; turns skipped by gates: **0**.
- Gate stops count as behavioral FAILs, not transport ERRORs. Skipped merchant messages were not sent.

- Run 1, turn 1, gate [request-route, form-observation, wait-for-form, no-status-detour]: **PASS**. All advancement assertions passed.

## Configuration

```json
{
  "testMode": true,
  "apiKeyConfigured": false,
  "apiKeyHeader": "x-cognigy-endpoint-key",
  "requestTimeoutSeconds": 60.0,
  "delayBetweenRequestsSeconds": 0.5,
  "delayBetweenRunsSeconds": 1.0,
  "maxConcurrency": 1,
  "retainRawEvidence": false,
  "additionalRedactionValueCount": 0,
  "automaticRetries": 0
}
```

Raw evidence is redacted and retained only when configured. Review it for residual sensitive data.
