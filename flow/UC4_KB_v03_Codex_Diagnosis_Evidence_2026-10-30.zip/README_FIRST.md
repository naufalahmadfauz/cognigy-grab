# UC4 v0.3 — Codex diagnosis handoff (2026-10-30)

This package holds the four problematic KB scenarios, one working GrabMart submission comparison, full independent findings, and a previously verified POC export. No runtime or Cognigy configuration was modified to produce it.

## READ FIRST

- analysis/UC4_KB_v03_Live_Test_Review_2026-10-30.md
- live_evidence/KB-GM-SPLIT-001/
- live_evidence/KB-GF-SUBMIT-001/
- live_evidence/KB-GF-EVIDENCE-001/
- live_evidence/KB-GM-EVIDENCE-001/
- live_evidence/KB-GM-SUBMIT-001/ (working visibility-check comparison)

## IMPORTANT LIMITATIONS

- reference_baseline/Package-Naufal_2026-10-29_13-33-26.zip is a verified October 29 POC export. It is NOT a newly generated October 30 export, and it does NOT prove deployed state on October 30.
- The Job instructions text is the approved October 29 source.
- Recorded live scenario data contains conversation content/trace correlation IDs, but not Cognigy internal execution traces, effective resolver inputs, or retrieved Knowledge Search chunks. Do not claim verified root cause or exact live retrieval.
- Do not edit [MAIN], shared AI Agent, shared Knowledge Store, runner, scenarios, or historical evidence.

## ACTION

Diagnose using available evidence and POC baseline. Propose the smallest hypothesis-driven correction to isolated POC Job/Flow only. Clearly distinguish confirmed behavior from unverified root cause and list a current export or targeted execution trace as optional evidence needed before a verified deployment patch. Do NOT demand full traces just to make a preliminary diagnosis. Do not run live requests or apply a patch without explicit approval.
