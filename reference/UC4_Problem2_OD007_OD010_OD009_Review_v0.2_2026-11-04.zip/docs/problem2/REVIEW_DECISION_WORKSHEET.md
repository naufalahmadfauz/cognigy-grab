# UC4 Problem #2 — business/benchmark worksheet and internal agreement log

**Package:** P2-DRAFT-0.2 + P2-ENG-DECISIONS-0.3 / OD002-REVIEW-0.2 / OD004-OD005-REVIEW-0.2 / OD004-RECENT-GUIDANCE-REVIEW-0.2 / OD007-OD010-OD009-REVIEW-0.2 internal agreements

**Status:** Four Round 1 internal agreements plus **OD-002 Q1–Q4** (2026-11-02), **qualified OD-004/005 Q1–Q7**, **qualified Q8 Option B design direction** (2026-11-03) and **qualified Q9–Q13 criteria** (2026-11-04) agreed internally; **no formal benchmark or Grab policy approvals recorded**. See [Round 1 record](ENGINEERING_DECISIONS_2026-11-02.md) and [OD-002 approval provenance](OD002_STATUS_DECISION_REVIEW.md#recorded-q1q4-approval-and-provenance).

**Input authority:** October 23 Problem #2 PLAN/PB; Grab benchmark workbook (immutable); KB v0.3 POC source decisions; existing `OPEN_DECISIONS.md`.  
**Use:** Record selections from named benchmark/business and QA reviewers. An LLM recommendation cannot approve or change a business rule.

**Current agreement, 2026-11-04:** `OD007-OD010-OD009-REVIEW-0.2`; Q9–Q13 are
**answered with qualifications**, Q12 explicitly provisional. Earlier agreements
and formal authority limits persist.

## Historical options for formal benchmark review

The next table retains the pre-agreement source options and formal acceptance
blockers. The internal choices are already recorded in the following agreement
log; they are not reopened by unfilled formal fields. OD-002 Q1–Q4 have explicit
answers in [the Round 2 record](OD002_STATUS_DECISION_REVIEW.md#7-review-frontier-and-adoption-limits).
Formal business/benchmark and QA sign-off remains pending for both rounds.

**Round 3, OD-004/005:** the [qualified approval record](OD004_OD005_TRIGGER_TIMING_REVIEW.md#recorded-q1q7-approval-and-provenance)
contains the user's actual answers, full qualifications and superseded proposals.
All seven internal choices are recorded below; formal policy-owner and QA sign-off
remain separate. Q4 is conditional on genuine ambiguity, not a universal question.

| OD | Issue and source evidence | Candidate option A (historical proposal; formal approval pending) | Alternative / why it matters | Historical / formal state |
|---|---|---|---|---|
| OD-001 | TC-006 `WB:S!D9` expects retry declined, while `E9` accepts re-login and successful form submission | Keep D9 declined retry/soft close as **proposed** original fixture; keep accepted/success as `VAR-TC-006-A`; failed retry separately | Stakeholder could choose E9 as original target. Either way preserve both and specify fixture; don't fabricate consensus. | CONFLICT; original TC coverage BLOCKED_SPEC |
| OD-008 | TC-009 `WB:S!D12` says Portal *status*, `E12` explicitly declines status and requests submission only | Use E12 Portal submission + failed retry + separate consented mock transfer as **proposed** original fixture | If D12 is required, confirm supported GF Portal status route before requiring it; current KB supports GF App status. | CONFLICT; original TC coverage BLOCKED_SPEC |
| OD-003 | TC-027 `WB:S!E16` selects App, then shifts into Portal Finance/Transactions; `F16` says Portal-only for GM status | Keep App selection; explicitly explain computer Portal status route, confirm Portal readiness and preserve style | Portal unavailable needs separate supported recovery/consent; don't silently treat App as Portal. | CONFLICT; target fixture review pending |
| OD-015 | Reviewer ownership/acceptance scope/sample count not assigned | Assign business/benchmark owner and QA reviewer; sign off only on chosen fixture/BR applicability with version and date | Without reviewer authority, mark draft and don't convert proposed instructions into Grab policy. | PROPOSED; no approvals |

## Project-side engineering agreement log (recorded 2026-11-02)

| OD | Selected internal POC direction | Scope | Formal reviewer sign-off |
|---|---|---|---|
| OD-001 | Declined retry = provisional original TC-006; success = VAR-TC-006-A; failed retry separate | Engineering fixture agreed; original workbook contradiction retained | Pending |
| OD-008 | Portal **submission-only**; failed retry → person offer → separate explicit consent → mock transfer | Engineering fixture agreed; original workbook contradiction retained | Pending |
| OD-003 | App selection → explain computer Portal requirement → verify readiness → Portal status guidance; preserve preferences | Engineering transition agreed; benchmark conflict retained | Pending |
| OD-015 | Appoint business/benchmark and QA reviewers; review and freeze scoped accepted requirements before baseline execution | Review governance agreed; appointments and sign-off not performed | Pending |
| OD-002 | Q1 Approved: visible-blank review-request target with intent/prerequisites, no eligibility/award claim. Q2 Approved provisionally: reported approval/status-only explanation without unnecessary duplicate. Q3 Approved provisionally: approval/payout/bank-receipt explanation and clarification priority, no invented remedy/date/guarantee. Q4 Approved: clarify observed status before status-dependent submission. | **VERIFIED [POC] / ENGINEERING_AGREED_POC**, OD002-REVIEW-0.2; all four provisional internal POC decisions. Behavior and original TC-003 coverage remain independent; dependent requirements, formal semantics and remedies remain open | Pending |

**Recorded authority:** the requesting project-side user's explicit conversation
agreement, 2026-11-02. Personal name, official role and formal business/benchmark
or QA authority were not supplied. OD-002's source quotation, rationale, affected
versions and superseded wording are in its linked record. These entries do not
create formal Grab policy approval or authorize runtime changes.

## Qualified Round 3 agreement log (recorded 2026-11-03)

All entries below are **VERIFIED [POC] / ENGINEERING_AGREED_POC**, provisional
internal engineering scope only. Source: requesting project-side user's explicit
qualified approval message; personal name/official role/formal Grab or QA authority
not supplied. The linked full approval text governs any abbreviated row.

| Choice / OD | Recorded answer and scope | Remaining conflict / formal sign-off |
|---|---|---|
| Q1 / OD-004 | Approved: defined recent age-only education without unnecessary goal question; no inferred preparation/packing. | Job-source conflict retained; formal sign-off pending. |
| Q2 / OD-004 | Approved conditionally: requested/accepted navigation priority, including same-order age correction; preserve mandatory disclosures and necessary intake. | Implementation conflict retained; qualified Q8 below now settles design direction. Exact implementation/fixtures remain open; no runtime authorization or official early-form support. |
| Q3 / OD-004 | Approved: TC-027 clear upfront dual request omits unsolicited timing/redundant accepted-guidance offer; preserve GM notice, computer-Portal transition, preferences and status observation before submission. | Original benchmark conflict and final GM policy retained; formal sign-off pending. |
| Q4 / OD-004 | Approved as modified, conditional: clarify once only for genuine ambiguity; no redundant clear-status clarification or unnecessary age/loudspeaker intake under the direct GM-only exception. | No universal phrase-triggered clarification; formal acceptance pending. |
| Q5 / OD-004 | Approved: answer new timing question after decline without automatic repeat offer; new explicit guidance request may change branch. | Applicable entry/Tool and finish/consent boundaries remain. |
| Q6 / OD-005 | Approved: explicit cancellation-age fixtures, declared Asia/Kuala_Lumpur (UTC+8) reference, reproducible same-session dates and documented relative expressions; approval after order made stays distinct. | Absolute dates, midnight boundaries and official business-calendar conventions unresolved. |
| Q7 / OD-005 | Approved conditionally: KB-supported no-photo continuation with available evidence/information; retain recommendations, no eligibility/acceptance/completeness/approval promise; flag separately established mandatory UI/business conditions for review. | Exact text, UI acceptance/conditions, final evidence policy and substitutes unresolved. |

No execution or regrade result accompanies these agreements. Formal fields below
remain unfilled; their pending status does not reopen internal Q1–Q7.

## Qualified Q8 design agreement log (recorded 2026-11-03)

Source: [OD004-RECENT-GUIDANCE-REVIEW-0.2 — full approval/provenance](OD004_RECENT_GUIDANCE_CONTRACT_REVIEW.md#recorded-q8-approval-and-provenance).
The requesting project-side user explicitly agreed to Option B with seven
qualifications. Personal name, official role and formal Grab business/benchmark
or QA authority were not supplied. The full quoted approval governs this summary.

| Choice | Selected design direction and qualifications | Recorded answer / authority |
|---|---|---|
| [Q8 — Option B](OD004_RECENT_GUIDANCE_CONTRACT_REVIEW.md#recorded-q8-approval-and-provenance), OD-004 Q2 dependency | (1) Coordinate existing admission/checkpoint validation/age correction; (2) retain compatible intent, consent, preferences, location and actions, invalidate only changed-fact-dependent progress; (3) actual education/disclosure delivery differs from resolver selection; (4) Agent-first, smallest instruction/contract changes, no new controller protocol, unnecessary persistent walkthrough state or additional Flow infrastructure; (5) retain Q1–Q7 and GM direct status-only exception; (6) no early eligibility, compensation guarantee, unsupported submission or policy/UI override; (7) protect TC-001/025, TC-002/026, navigation variants and same-order corrections. | **Approved with seven qualifications — VERIFIED [POC] / ENGINEERING_AGREED_POC**, requesting project-side user, 2026-11-03. **Documentation/design direction only**; formal sign-off pending. |

Q8 is answered; the original question, alternative options and v0.1 audit are
preserved in the [twelve-member pre-approval snapshot](../../reference/UC4_Problem2_OD004_Recent_Guidance_Review_v0.1_2026-11-03.zip).
Qualification 4 constrains prior representation/API suggestions; no exact mechanism
or new fixture acceptance is selected. No Cognigy/Job/Tool/Code/KB/runner change,
live test or baseline freeze is authorized. Formal sign-off below remains separate.

## Qualified Q9–Q13 agreement log (recorded 2026-11-04)

Source: [full qualified approval and provenance](OD007_OD010_OD009_RECOVERY_ACCESS_CONSENT_REVIEW.md#recorded-q9q13-approval-and-provenance).
All five answers are **VERIFIED [POC] / ENGINEERING_AGREED_POC** for provisional
internal POC specification/test-fixture design only. **Decision-maker:** requesting
project-side user, **2026-11-04**; personal name, official role and formal Grab
business/benchmark or QA authority were not supplied. The full quotation governs.
All behavior/coverage verdicts remain `NOT_RUN`.

| Question / OD | Recorded criterion and scope | Actual answer / authority / date |
|---|---|---|
| Q9 / OD-007 | History only for the relevant order missing from Cancelled; TC-007 Date-selector first failure → one supported repeat → observed success. Preserve one-by-one action/wait boundaries; actual failure is distinct from Q8 correction-invalidated progress. No unsupported recovery steps. | **YES, qualified**; requesting project-side user; 2026-11-04 |
| Q10 / OD-010 | Separate App request-link availability, article opening, scroll, form visibility, authorization, retry consent, retry outcome and merchant-reported submission. Preserve TC-006 decline, VAR-TC-006-A success, TC-008 fallback and TC-009 submit-only. Missing form never proves wrong role. | **YES, qualified**; requesting project-side user; 2026-11-04 |
| Q11 / OD-010 | Owner/Manager submission authorization remains required; explain conditionally during access recovery and actual role questions. No universal successful-path spoken reminder unless separately approved. | **YES, qualified**; requesting project-side user; 2026-11-04 |
| Q12 / OD-009 | TC-004 explicit guidance decline and finish; TC-028 reviewed optional-offer/no-offer endings with explicit finish. Required offers retain their triggers; acknowledgement, silence or submission does not establish resolution. **Benchmark fixture changes require reviewer approval.** | **YES, PROVISIONALLY**, qualified; requesting project-side user; 2026-11-04 |
| Q13 / OD-009 | Supported trigger → separate person offer → later explicit acceptance → one Flow-owned mock transfer. Retry consent/acknowledgement/silence cannot transfer. TC-010 menu-update request is the proposed internal out-of-scope fixture; ordinary closing and transfer terminals stay separate. | **YES, qualified**; requesting project-side user; 2026-11-04 |

The old unanswered frontier is preserved in the [pre-approval snapshot](../../reference/UC4_Problem2_OD007_OD010_OD009_Review_v0.1_2026-11-04.zip)
and the report's historical questions. Q1–Q8 remain controlling. Approval covers
the stated criteria, not every detailed profile, whole variant or unknown remedy.
Owner evidence for [unsupported outcomes](OD007_OD010_OD009_RECOVERY_ACCESS_CONSENT_REVIEW.md#outcomes-still-needing-an-authorized-disposition)
and formal benchmark/business/QA acceptance remain pending. Q11's conditional
criterion no longer awaits an internal universal-reminder decision. The A/B/C
aliases allocate no new VARs; the [12-specification phase](OPEN_DECISIONS.md#proposed-next-phase--12-specifications-and-scoped-baseline-review)
is proposed, not completed in this update.

## Formal human review record — leave unfilled until named authorized reviewer signs off

| OD | Selected option / alternative | Business or benchmark reviewer | QA reviewer | Date | Approval scope and rationale | Impacted BR/JRN/VAR version | Decision state |
|---|---|---|---|---|---|---|---|
| OD-001 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | BR-012/014/015; JRN-TC-006; VAR-TC-006-A/B | CONFLICT |
| OD-008 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | BR-009/011/012/015; JRN-TC-009 | CONFLICT |
| OD-003 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | BR-005/008; JRN-TC-027; TC-029 comparison | CONFLICT |
| OD-015 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | Review framework and high-risk sampling | PROPOSED |
| OD-002 | _pending formal confirmation_ | _unassigned_ | _unassigned_ | — | _formal scope pending; internal Q1–Q4 recorded above_ | OD002-REVIEW-0.2: BR-009; JRN-TC-003; VAR-TC-003-A/B/C | UNKNOWN formal policy; sign-off pending |
| OD-004 | _pending formal confirmation_ | _unassigned_ | _unassigned_ | — | _qualified internal Q1–Q5 and Q8 recorded; exact implementation/fixtures and formal source acceptance open_ | OD004-OD005-REVIEW-0.2 and OD004-RECENT-GUIDANCE-REVIEW-0.2: BR-001/002/003/005/009/014 and conditional §6 impacts; JRN-TC-027 entry | Internal design agreement; formal/implementation CONFLICT retained |
| OD-005 | _pending formal confirmation_ | _unassigned_ | _unassigned_ | — | _qualified internal Q6–Q7 recorded; official timing/UI/evidence conditions unresolved_ | OD004-OD005-REVIEW-0.2: BR-002/003/013; shared fixture/evidence scope | Internal agreement; formal policy/UI/timing UNKNOWN/CONFLICT |
| OD-007 | _pending formal confirmation_ | _unassigned_ | _unassigned_ | — | _qualified internal Q9 recorded; formal fixture attribution and further remedies pending_ | OD007-OD010-OD009-REVIEW-0.2: BR-006/007/019; TC-007 and conditional recovery | Internal agreement; formal CONFLICT / unsupported outcomes UNKNOWN |
| OD-010 | _pending formal confirmation_ | _unassigned_ | _unassigned_ | — | _qualified internal Q10–Q11 recorded; conditional reminder criterion settled internally_ | OD007-OD010-OD009-REVIEW-0.2: BR-010/011/012/013/014 and applicable variants | Internal agreement; formal policy/UI and unsupported remedies pending |
| OD-009 | _pending formal confirmation_ | _unassigned_ | _unassigned_ | — | _Q12 provisional fixture repairs and qualified Q13 recorded; benchmark fixture approval required_ | OD007-OD010-OD009-REVIEW-0.2: BR-014/015/016/020; TC-004/028/010 and supported handoff paths | Internal agreement; formal fixture/wording/evidence acceptance pending |

## Reviewer checklist

- [ ] Confirm the two separate questions for each fixture: Agent behavior on observed branch and coverage of intended original TC.
- [ ] Confirm the proposed target and any distinct test variant, without overwriting Grab's workbook.
- [ ] Check BR source authority and its **POC adoption** vs **formal business approval** boundary.
- [ ] Identify which requirements are business obligations versus QA/evidence rules.
- [x] Record qualified OD-004/005 Q1–Q7 as provisional internal decisions with authority limits and preserved source conflicts.
- [x] Record [qualified Q8 Option B approval](OD004_RECENT_GUIDANCE_CONTRACT_REVIEW.md#recorded-q8-approval-and-provenance), all seven qualifications, Agent-first boundary and documentation/design-only authority.
- [x] Record [qualified Q9–Q13](OD007_OD010_OD009_RECOVERY_ACCESS_CONSENT_REVIEW.md#recorded-q9q13-approval-and-provenance), including Q12's provisional fixture-review limit, TC-010's proposed fixture and actual authority/date; preserve Q1–Q8.
- [ ] Complete the proposed 12 specifications, reconcile the three pilots and prepare the versioned scoped baseline review candidate with explicit blockers and exclusions.
- [ ] Obtain formal OD-002/014 status, duplicate/dispute, unpaid-remedy and access evidence; retain answered internal choices. Follow this review with scoped OD-006/011 wording review.
- [ ] Record an owner, date, rationale, changed versions, evidence and dissent/unresolved status.
- [ ] After applicable decisions and named sign-off, consider a scoped baseline version and separate execution authorization. Full Business Acceptance Baseline v1.0 remains **NOT FROZEN** under this update.

**Recommended next phase:** complete remaining journey specifications from the
existing evidence and agreements, then submit the scoped candidate for named
review. Seek additional contract evidence only for a genuine acceptance blocker.
Later execution/evidence assessment requires separate authorization. Retain
independent historical/new verdicts; KB coverage is not 15 benchmark passes.
