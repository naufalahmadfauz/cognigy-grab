# Problem #2 — open decisions and review frontier

**P2-DRAFT-0.2 source register + P2-ENG-DECISIONS-0.3 / OD002-REVIEW-0.2 / OD004-OD005-REVIEW-0.2 / OD004-RECENT-GUIDANCE-REVIEW-0.2 internal agreements · 2026-11-03.**

**Round 1 (preserved):** Project-side user explicitly agreed to internal POC engineering directions for **OD-001, OD-008, OD-003 and OD-015** on 2026-11-02. See [engineering decision record](ENGINEERING_DECISIONS_2026-11-02.md). These are **not formal Grab approvals**; source conflicts in the register remain, and formal reviewer names/acceptance sign-off are still missing.

**Round 2 recorded:** the requesting project-side user explicitly approved
[OD-002 Q1–Q4](OD002_STATUS_DECISION_REVIEW.md#recorded-q1q4-approval-and-provenance)
on 2026-11-02 as **provisional internal POC engineering decisions**. Q1/Q4 are
Approved; Q2/Q3 Approved provisionally, all within that internal scope.
A/B/C/D preserve the existing target / VAR-TC-003-A/B/C identities. Internal
explanation priority is settled; formal status/duplicate semantics, payment
remedies and the unchanged Job-source conflict remain explicit. Scoped
OD-004/005/010/014 dispositions in review §5 do not close those whole ODs.

**Round 3 recorded, 2026-11-03:** the requesting project-side user approved
[OD-004/005 Q1–Q7 with qualifications](OD004_OD005_TRIGGER_TIMING_REVIEW.md#recorded-q1q7-approval-and-provenance)
as **VERIFIED [POC] / ENGINEERING_AGREED_POC**, provisional internal decisions only.
Q2/Q7 are conditional; Q4 is approved as modified, **only for genuine ambiguity**.
Q6 uses a declared **Asia/Kuala_Lumpur (UTC+8) test reference**. The drafting
choices are settled; Tool-contract, UI, official timing/policy and formal
acceptance gaps remain explicit. OD-002 Q1–Q4 and the Round 1 records are unchanged.

**Q8 recorded, 2026-11-03:** [OD004-RECENT-GUIDANCE-REVIEW-0.2](OD004_RECENT_GUIDANCE_CONTRACT_REVIEW.md#recorded-q8-approval-and-provenance)
records the requesting project-side user's **Option B approval with seven
qualifications**, **VERIFIED [POC] / ENGINEERING_AGREED_POC** for documentation and
design direction only. Coordinate existing admission/checkpoint/correction rules,
retain compatible context/progress, invalidate only changed-fact-dependent progress
and distinguish actual delivery from branch selection. The **Agent-first** and
minimal-existing-instruction/contract boundary excludes a new controller protocol,
unnecessary persistent walkthrough state and additional Flow infrastructure.
Q1–Q7, the GM-only exception and policy/UI limits remain; Q8 is no longer pending.

[Sources and requirements](BASELINE_MODEL.md) · [Classification](TC_CLASSIFICATION_MATRIX.md) ·
[Pilots](JOURNEY_PILOT.md) · [Defect impact](DEFECT_GROUP_IMPACT_MATRIX.md)

The agreed root is the October 23 process direction: preserve the original
workbook, evaluate business milestones, distinguish behavior from coverage and
review inferred branches. This register distinguishes recorded internal agreements
from recommendations awaiting review. `CONFLICT`, `UNKNOWN` and `PROPOSED` use
PB §9's meanings. Named formal business/benchmark and QA owners and sign-off dates
remain **unassigned**; they are not implicitly the preparer, the LLM or the user.

## Decision register

| ID / label | Source-grounded question | Recorded direction / remaining review; decision owner | Remaining scope / dependencies |
|---|---|---|---|
| OD-001 **VERIFIED [POC]** fixture; formal source **CONFLICT** retained | TC-006's path declines role retry (`WB:S!D9`), but its dialogue accepts re-login, sees the form and submits (`E9`). PB §5; PLAN §6/P101. | Existing internal agreement: declined-retry primary; successful retry `VAR-TC-006-A`, failed retry `VAR-TC-006-B`. Named benchmark/business review still required for official attribution. | Internal target choice settled; dependent requirements remain reviewed separately. External TC certification pending; BR-012/014/015. |
| OD-002 **VERIFIED [POC] / ENGINEERING_AGREED_POC**; formal policy **UNKNOWN**; Job-source applicability **CONFLICT** retained | [Four-branch review](OD002_STATUS_DECISION_REVIEW.md): WB:S!A6:F6; WB:D!D21/G21/K21; PB §4; PLAN §5; KB30 GF status/timing/submission claims; JOB30. Visible blank status differs from no observation; Auto approved differs from bank receipt. | Requesting project-side user approved Q1–Q4 on 2026-11-02: visible-blank review-request A with prerequisites and no eligibility/award claim; narrow status-only/no-unnecessary-request B; approval/payout/bank-receipt explanation and clarification priority C; clarify before status-dependent submission D. Q2/Q3 explicitly provisional; all four internal POC only. | Internal choices settled. Original submission coverage remains separate from B/C handling; D supplies coverage only after A and its stages are established/exercised. Formal status/duplicate policy, C's financial remedy and dependent OD-004/005/007/010/014 requirements remain open. BR-009/JRN-TC-003/VAR-TC-003-A/B/C use the OD002-REVIEW-0.2 overlay; other BR/BP impact is unchanged. |
| OD-003 **VERIFIED [POC]** transition; formal source **CONFLICT** retained | TC-027 selects/opens App before Finance → Transactions (`WB:S!E16`); F16 says Portal only, D16 says App or Portal. TC-029 E18 includes the computer-Portal redirect. PB §5; PLAN P103; KB GM-STATUS. | Existing internal agreement: retain App selection, explicitly explain computer Portal and confirm readiness before controls; retain style/preferences. Portal-unavailable recovery keeps its scope/consent limits. | Internal transition settled; formal benchmark review and dependent policies remain pending. TC-029 / GM variants share BR-005/008/015. |
| OD-004 **VERIFIED [POC] / ENGINEERING_AGREED_POC** for qualified Q1–Q5 and Q8 design direction; source/implementation **CONFLICT** retained | [Trigger table T01–T18](OD004_OD005_TRIGGER_TIMING_REVIEW.md#2-intent-entry-age-and-lob-trigger-table): recent age-only education conflicts with J01's open question; explicit recent navigation conflicts with recent/correction rules and the beyond-only Tool. The [full chain](OD004_RECENT_GUIDANCE_CONTRACT_REVIEW.md#2-source-grounded-static-trace) also exposes checkpoint availability/validation, deletion and false delivery accounting. WB TC-027 E16 and TC-004/DF-018 source conflicts persist. | [Qualified Q1–Q5](OD004_OD005_TRIGGER_TIMING_REVIEW.md#recorded-q1q7-approval-and-provenance) remain as agreed: recent education, conditional navigation priority, direct TC-027 dual entry, genuine-ambiguity-only clarification and timing answers after decline. [Qualified Q8 Option B](OD004_RECENT_GUIDANCE_CONTRACT_REVIEW.md#recorded-q8-approval-and-provenance), requesting user, 2026-11-03, adds coordinated existing-path design, compatible-progress retention/selective invalidation and actual-output-based education accounting within the Agent-first/minimal-change boundary. | Core BR-001/002/003/005/014 and conditional progression/disclosure/access impacts in review §6. Exact implementation and versioned recent/correction fixtures remain open. No new controller protocol, unnecessary persistent walkthrough state or additional Flow infrastructure approved. No runtime authorization, early eligibility/form acceptance, guaranteed award or policy/UI override. TC-003/009, Q1–Q7 and GM-only exception retain scope; formal certification/closures remain separate. |
| OD-005 **VERIFIED [POC] / ENGINEERING_AGREED_POC** for qualified Q6–Q7; formal timing/UI/policy **UNKNOWN/CONFLICT** | [Timing/date/evidence sheet](OD004_OD005_TRIGGER_TIMING_REVIEW.md#3-timing-and-date-conventions): cancellation routing versus approval after order made; inclusive elapsed-day cutoffs; stored fixed-UTC+8 initialization clock with no automatic refresh found; no absolute-date API. WB timing/photo statements and unconditional Job attachment text retain their conflicts with qualified POC sources. | [Requesting user's 2026-11-03 approval](OD004_OD005_TRIGGER_TIMING_REVIEW.md#recorded-q1q7-approval-and-provenance): Q6 explicit cancellation-age fixtures, declared Asia/Kuala_Lumpur (UTC+8) test reference, reproducible same-session assumptions and documented relative expressions; Q7 conditional KB-supported continuation without photo, with available evidence/information and recommendations retained. | BR-002/003/013. Absolute-date, midnight-boundary and official business-calendar conventions remain unresolved. No promise of eligibility, acceptance, completeness or approval; flag separately established mandatory UI/policy conditions for review. No early-form acceptance, evidence substitute, bank deadline or 90/5/3-day SLA is established. |
| OD-006 **CONFLICT** | TC-027/029 allow full-or-partial compensation and TC-029 repeats the notice (`WB:S!E16,E18`). Adopted POC text says “will be partial”; H1 §6 item 2/KBC flag its certainty. | Business/content owner: decide amount/qualification wording and exactness. Until reviewed, retain the existing POC control as source-qualified, once before applicable navigation; never convert either example into a guaranteed individual award. | BR-018; TC-027/029; historical DF-014's delayed notice, not wholly absent content. |
| OD-007 **CONFLICT** / fixture detail **UNKNOWN** | TC-003's order is already visible before unconditional Date selector steps (`WB:S!E6`). TC-007 D10/F10 require a stuck-step repeat, but E10 shows bundled History/date/Confirm and no explicit failed-step retry. TC-006 E9 has consecutive cannot-see/can-see replies. JOB29 makes History conditional on missing order and separates one-by-one actions. | Benchmark + QA reviewers: define missing-order versus missing-control facts explicitly; propose a Date-selector first-failure fixture for TC-007, without claiming it already exists. Preserve mandatory waits; require only applicable recovery steps, not gratuitous Date selector usage. | BR-006/007/019; TC-003/005/006/007. Date-selector omissions need the actual precondition, not a wording-only verdict. |
| OD-008 **VERIFIED [POC]** fixture; formal source **CONFLICT** retained | TC-009 path says **GrabFood Portal status** (`WB:S!D12`); E12 declines status guidance and requests **Portal submission only**. KB GF-STATUS supports App status; JOB30 does not supply GF Portal status. | Existing internal agreement: Portal submission → failed accepted role retry → separate consented mock transfer. Preserve D12 discrepancy for formal review. | Internal target settled; do not add a status-first detour under OD-002. External target certification remains pending; BR-009/011/012/015. |
| OD-009 **CONFLICT** / final intent **UNKNOWN** | TC-004 offers guidance and immediately asks anything else with no reply (`WB:S!E7`, PLAN P105). TC-028 closes after “okay” (`E17`). DF-012 demands “Thank you for Calling Grab,” absent from TC-010's transfer script (`WB:D!G16`; `WB:S!E13`). “Payout question” in E13 may still be UC4-related. | Business + benchmark reviewers: add explicit offer response/finish signals to fixtures; distinguish normal closing from Flow-owned mock transfer. Require a clearly unrelated TC-010 topic or clarification. Review DF-012's possible truncated closing separately from its courtesy-phrase complaint. | BR-014/015/016/020; TC-004/009/010/028 and consent variants. Acknowledgement ≠ transfer consent or automatic resolution. |
| OD-010 **UNKNOWN**; conflicting recovery assumptions **CONFLICT** | Role authorization is documented (KB SHARED-REQUEST), but scope/timing of a **spoken role reminder on every successful submission** is unsettled. DF-007/009 request role/date advice absent from their example transcripts. DF-008 N12 suggests role establishes menu visibility; KB says missing link/form does not prove wrong role. | Business + benchmark reviewers: distinguish missing App link from missing form after article/scroll; adopt explicit role-access, retry-offer, consent, attempt and observation stages for the POC. Decide universal reminder applicability separately. Keep lack of role/access and lack of computer access distinct. | BR-010/012/015/019; TC-003/005/006/007/008/009/027/029. Do not declare every omitted reminder a confirmed defect or promise the UI will appear. |
| OD-011 **PROPOSED** | Which exact text is binding, for which version/channel? WB's sample speeches are illustrative (PB D-03); JOB29 explicitly fixes some POC statements. | Business/content owner + QA: approve a compact controlled-text register with source/version, exact text or hash and applicability. All other language is evaluated semantically. `PB D-*` and `PLAN D-*` must remain namespaced because their numbering differs. | BR-004/020 and exact portions of BR-003/015/018. No new mandatory greeting/preparation/thanks phrase is inferred from WB alone. |
| OD-012 **UNKNOWN** current verification | WB statuses are dated history. PLAN P012/P033 and PB §§0,7 explicitly report DF-014/018 resolved; DF-001 is Closed/Pass, DF-016 Not a defect, DF-017 status blank. “Recent defects resolved” is not an enumerated closure of all 18. | Defect owner + QA: retain each status event and obtain cited fix/retest evidence only where a new closure assurance or current baseline claim is required. Do not reopen by default. H1's KB closure stays separate from benchmark acceptance. | All groups: current regression verification not established. Owner-reported resolutions remain recorded as such. |
| OD-013 **UNKNOWN** | DF-013's silence/ASR explanation and DF-017's barge-in cause are hypotheses (`WB:D!G17,G21`). No numerical response SLA or synchronized audio/trace record is supplied for those reports. | Voice/environment owner + QA: define measurable response/audibility expectations and collect aligned audio, recognized input, displayed text and timing before attribution. Do not change barge-in settings from a tester hypothesis. | BR-017; voice impact plausibly spans all 15, but is directly reported only for TC-026/003. REST text alone cannot close audibility findings. |
| OD-014 **UNKNOWN** formal policy/UI | H1 §6 and KB retain provisional preparation/packing, evidence substitutes, early form acceptance and authenticated-screen limits; 90/5/3-day UC4 applicability is unresolved. OD-002 also exposes missing canonical status/duplicate policy and approved-but-unpaid remedies/triggers. Other Portal KB routes exist but standard POC guidance uses Search Bar. | Grab policy/UI owner: provide authoritative status meanings, dispute exceptions and any overdue-payment check/contact/escalation route and trigger; confirm applicable policy and screens. Keep reference facts qualified; defer alternate Portal routes and unsupported escalation rather than inventing rules. | BR-009/010/011/012/013 and alternate branches. Q1–Q4's internal guidance is agreed; formal semantics, financial resolution, individual eligibility and authenticated UI assurance remain blocked. Retrieval success is not eligibility, UI or production approval. |
| OD-015 **VERIFIED [POC]** governance; appointments/sign-off pending | Staged internal POC review is agreed in the v0.3 engineering record. Reviewer identities, accepted requirement versions and sampling plan are still unassigned. PB §§7–11's proposed five runs is not a reliability guarantee or established external count. | Retain agreed engineer draft → project-side provisional review → named business/benchmark and QA acceptance → scoped freeze; authorize executions separately. | OD-002 has its own explicit internal approval provenance. Governance alone does not appoint reviewers, approve dependent requirements, freeze a baseline or authorize tests. |

## 2026-11-02 limited engineering adjudication (does not resolve original conflicts)

| OD | Engineering status | Remaining benchmark / approval status |
|---|---|---|
| OD-001 | **ENGINEERING_AGREED_POC**: decline retry as original internal TC-006 fixture; accepted/success as VAR-TC-006-A; failed retry separate. | Original D9/E9 conflict retained; **benchmark owner review required**. |
| OD-008 | **ENGINEERING_AGREED_POC**: TC-009 Portal submission-only, failed role retry, separate explicit consent to mock transfer. | Original D12/E12 conflict retained; **benchmark owner review required**. |
| OD-003 | **ENGINEERING_AGREED_POC**: TC-027 explicit App → computer Portal readiness before navigation, preserve preferences. | Original E16/F16 conflict retained; **benchmark/business review required**. |
| OD-015 | **PROCESS_AGREED_POC**: named business/benchmark + QA review before freeze; distinct POC and formal sign-off. | **Names and acceptance authority still unassigned**; no baseline frozen. |
| OD-002 | **ENGINEERING_AGREED_POC**, Round 2 Q1–Q4: A review-request fixture; B status-only/no unnecessary duplicate; C approval-aware explanation/clarification priority; D status clarification before submission. | Requesting project-side user, 2026-11-02; [provenance and superseded wording](OD002_STATUS_DECISION_REVIEW.md#recorded-q1q4-approval-and-provenance). Formal policy/benchmark and QA sign-off pending; original Job-source conflict and dependent limits retained. |

No live test has been run under this update. These decisions guide **internal drafting only** until the dependent BR and fixture review is complete.

## 2026-11-03 qualified OD-004/005 engineering agreement

Q1/Q3/Q5/Q6 are Approved; Q2/Q7 Approved conditionally; Q4 Approved as modified,
conditional rather than universal. All seven are **provisional internal POC**
agreements, with the user's full text and authority limits in the linked approval
record. This is not a formal closure of OD-004/005. The unchanged older-order-only
Tool restriction is an **implementation conflict**; UI/policy and official timing
gaps remain **UNKNOWN/CONFLICT**, while the scoped drafting choices are resolved.
No prior decision, historical DF status or evidence verdict is replaced.

## 2026-11-03 qualified Q8 design agreement

**Option B is agreed**, subject to all seven qualifications in the
[full approval/provenance record](OD004_RECENT_GUIDANCE_CONTRACT_REVIEW.md#recorded-q8-approval-and-provenance).
The approval is for documentation/design direction only, with the requesting
project-side user's personal name, official role and formal business/QA authority
not supplied. It settles coordinated reuse and the behavior obligations; it does
not select an API/schema or promote detailed fixture proposals to accepted tests.
The Agent-first qualification controls over v0.1's broader representation/migration
wording. Recent education TC-001/025, declined guidance TC-002/026, affected
navigation variants and same-order corrections are protected regression scope.
Both verdicts remain `NOT_RUN`; no whole OD or acceptance baseline is closed.

## Remaining blockers and next review batch

OD-002 Q1–Q4, Round 3 OD-004/005 Q1–Q7 and qualified Q8 no longer need internal answers.
The following items block only the named requirements, outcomes or formal
acceptance scope; they do not rescind the agreed fixtures or drafting choices.

| Remaining decision | What is blocked / owner evidence needed |
|---|---|
| **OD-004 residual — minimal implementation details and fixture acceptance** | Q8's [qualified Option B basis](OD004_RECENT_GUIDANCE_CONTRACT_REVIEW.md#4-qualified-option-b-design-basis) is settled. Exact recent/correction fixture identities, observations/endings and dependent BR acceptance remain open. Later design must reconcile existing instruction/admission/checkpoint/correction and legacy education-accounting contracts within the Agent-first limit; no exact representation, current conformance or implementation authorization is established. |
| **OD-005 residual — timing and evidence conditions** | Q6 settles the Asia/Kuala_Lumpur (UTC+8) test-reference convention, not absolute dates, midnight boundaries or official calendar/clock policy. Q7 settles qualified no-photo guidance, not guaranteed completeness or waiver of separately established UI/business conditions. Exact wording/final evidence rules and payment dates remain unresolved. |
| **OD-002 residual / OD-014 — formal policy and UI** | Canonical status meanings, universal duplicate/dispute policy, authorized approved-but-unpaid remedy/trigger, individual eligibility, evidence substitutes, early acceptance, 90/5/3-day applicability and authenticated routes/access. Policy/UI owners must supply authoritative evidence. C's bounded explanation is agreed; end-to-end financial resolution remains **BLOCKED_SPEC**. |
| **OD-006 / OD-011 — policy wording and exact text** | GM partial-compensation certainty/applicability and the versioned controlled-text register. Business/content and QA review must establish wording authority without converting sample dialogue or POC statements into guaranteed individual awards. |
| **OD-007 / OD-010 / OD-009 — fixture, access and finish boundaries** | Conditional History/stuck-step facts; universal successful-path role reminder and unavailable-role outcomes; explicit guidance/finish/transfer consent and genuine out-of-scope intent. Benchmark/business and QA reviewers must decide the applicable conditions. Agreed TC-006/009/027 primary choices remain intact. |
| **OD-001/003/008 formal attribution; OD-015 appointments/sign-off** | Formal benchmark ownership of the preserved source conflicts; named business/benchmark and QA reviewers, accepted requirement/fixture versions and sampling scope. Internal choices and staged governance are agreed; formal certification and any baseline freeze are pending. |
| **OD-012 / OD-013 — evidence acceptance dependencies** | Current closure/regression assurance and voice response/audibility expectations need defect/voice owner and QA evidence. These are evidence/acceptance gaps, not new business rules or proof that historical closures are invalid. |

**Completed review:** qualified Q8 Option B is recorded; the source conflicts,
independent behavior/coverage criteria and affected BR/TC/VAR/DG scope remain in
the [contract report](OD004_RECENT_GUIDANCE_CONTRACT_REVIEW.md). Its exact coverage
profiles are still candidates for acceptance, not implemented scenarios.

**Recommended next focused business-acceptance workstream: OD-007/010/009 —
recovery, access and consent/finish fixtures.** This recommendation is **PROPOSED**;
it does not decide those open questions or start implementation. It is the next
useful dependency because the agreed navigation direction still needs observable
recovery preconditions and permitted endings for assessable target coverage.

| Review slice | Proposed output / acceptance decision still needed | Protected scope |
|---|---|---|
| OD-007 — missing-order and ordinary stuck-step recovery | Explicit visible/missing-order observations; when History/date/Confirm applies; TC-007's actual first-failed action, one supported repeat and observed continuation. Distinguish an invalidated date action after correction from an ordinary failed action. | TC-003 visible-blank target, TC-006 consistent observations and existing recovery variants retain identities. No unconditional History or invented second-failure remedy. |
| OD-010 — link, form and role access | Distinct absent-App-link versus absent-form-after-scroll fixtures; known/unknown/unavailable authorized access; separate retry offer/answer, one attempt and observed success/failure. Review universal successful-path role-reminder applicability and leave unsupported access outcomes explicitly blocked. | TC-006 declined-retry primary and separate accepted variants; TC-008 fallback; TC-009 Portal submit-only; applicable GM form/Portal boundaries. No guaranteed UI access or inferred wrong role. |
| OD-009 — guidance/transfer consent and finish | Explicit offer replies and finish signals for TC-004/028; separate later handoff consent after supported failed retry; a genuinely unrelated TC-010 topic or necessary clarification; normal close versus Flow-owned mock terminal. | No conversion of acknowledgement, role confirmation or retry consent into transfer consent. Preserve unresolved goals, TC-009's internal target and TC-027 readiness/access-recovery boundary. |

**Deliverable proposed for that review:** a bounded source-to-fixture decision
sheet with starting facts, conditional milestones, merchant observations, consent
and finish points, permitted/blocked outcomes, BR links and separately assessed
behavior/coverage. Review exact version/identity for additional recent requested,
accepted and same-order correction candidates; N01–N08 remain aliases, not new
VAR IDs. Protect TC-001/025 education and TC-002/026 decline as distinct controls,
including real output evidence for education and compatible progress across
correction. Retain all 18 registered variants and three pilot identities; do not
expand the other 12 full journey specifications as a prerequisite for this batch.

Obtain **OD-014 owner evidence** on early-form/mandatory-evidence conditions,
status/duplicate policy and unpaid remedies alongside that future review. Follow
with **OD-006/011** GM certainty/controlled text; obtain OD-005 official clock/
calendar evidence and OD-015 reviewer appointments. Track OD-012/013 current
configuration, closure and voice-evidence dependencies. Minimal implementation
design comes later within Q8's qualifications; **Business Acceptance Baseline
v1.0 remains NOT FROZEN** and both verdicts remain `NOT_RUN`.

## Round 1 — original structured review prompts (historical)

The following Round 1 prompts preserve the earlier review history. Their internal
choices were subsequently agreed as recorded above; they are **not new questions
to reopen**. The [worksheet](REVIEW_DECISION_WORKSHEET.md) retains the separate
unfilled formal approval fields. For each new OD decision capture selected option,
scope, named deciding/QA reviewers, date, rationale/evidence and affected versions.

TC-003's [Round 2 Q1–Q4](OD002_STATUS_DECISION_REVIEW.md#7-review-frontier-and-adoption-limits)
are now agreed internally; its remaining frontier is the scoped dependency table above.
For TC-006/009, the internal fixture choices are settled; remaining source conflicts
block formal target certification, not use of those agreed drafting choices.
TC-027 preserves the agreed redirect and readiness checkpoint.

## Review round 1 — original questions retained as history

These recommendations formed the Round 1 review frontier. A **yes** to a question
accepts only its stated recommendation, not formal Grab policy or live execution.
Dependent policy/wording decisions remain in the register for the next round.

❓ **Q1 — TC-006 fixture:** Shall the proposed primary target follow D9's declined
retry, with E9's successful retry retained as `VAR-TC-006-A`, pending named review?

➡️ **Recommended: yes.** Preserve both branches and explicitly approve which one
counts toward the original TC; keep failed retry separate (OD-001).

❓ **Q2 — TC-009 fixture:** Shall the proposed target be E12's submission-only
Portal role-retry failure and consented mock transfer, with D12's Portal-status
description recorded as a conflict requiring correction approval?

➡️ **Recommended: yes.** This avoids introducing an unsupported GrabFood status
route and preserves the benchmark discrepancy (OD-008).

❓ **Q3 — TC-027 transition:** Shall the proposed journey retain App selection,
explicitly establish computer-Portal readiness, then continue the Portal status
route with the existing preferences?

➡️ **Recommended: yes.** It matches the documented POC navigation boundary while
keeping portal-unavailable recovery and policy wording under review (OD-003).

❓ **Q4 — Review ownership:** Shall the next step be a named business/benchmark
and QA review of the three pilots and their blocked decisions before freezing an
acceptance version?

➡️ **Recommended: yes.** Resolve high-impact semantics, then use the same saved
evidence to check that two reviewers agree; authorize fresh baseline execution
separately (OD-015).

Decision capture must record `OD ID`, selected option, rationale, source/approval
scope, named decision-maker, date, affected BR/JRN/VAR versions and superseded
interpretation. Future unanswered recommendations remain **PROPOSED**; OD-002
Q1–Q4, Round 3 OD-004/005 Q1–Q7 and Q8 Option B have explicit qualified answers recorded above.
Original formal source/implementation conflicts remain **CONFLICT** alongside
the bounded engineering agreements.
