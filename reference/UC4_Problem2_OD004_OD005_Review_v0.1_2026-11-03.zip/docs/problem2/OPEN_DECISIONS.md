# Problem #2 — open decisions and review frontier

**P2-DRAFT-0.2 source register + P2-ENG-DECISIONS-0.3 / OD002-REVIEW-0.2 agreements; OD004-OD005-REVIEW-0.1 proposed overlay · 2026-11-03.**

**Round 1 (preserved):** Project-side user explicitly agreed to internal POC engineering directions for **OD-001, OD-008, OD-003 and OD-015** on 2026-11-02. See [engineering decision record](ENGINEERING_DECISIONS_2026-11-02.md). These are **not formal Grab approvals**; source conflicts in the register remain, and formal reviewer names/acceptance sign-off are still missing.

**Round 2 recorded:** the requesting project-side user explicitly approved
[OD-002 Q1–Q4](OD002_STATUS_DECISION_REVIEW.md#recorded-q1q4-approval-and-provenance)
on 2026-11-02 as **provisional internal POC engineering decisions**. Q1/Q4 are
Approved; Q2/Q3 Approved provisionally, all within that internal scope.
A/B/C/D preserve the existing target / VAR-TC-003-A/B/C identities. Internal
explanation priority is settled; formal status/duplicate semantics, payment
remedies and the unchanged Job-source conflict remain explicit. Scoped
OD-004/005/010/014 dispositions in review §5 do not close those whole ODs.

**Round 3, 2026-11-03:** [OD-004/005 coupled review](OD004_OD005_TRIGGER_TIMING_REVIEW.md)
investigates education triggers and timing/date conventions. Its
[human-review frontier](OD004_OD005_TRIGGER_TIMING_REVIEW.md#6-human-review-frontier)
is **PROPOSED**, with source facts and missing formal policy kept separate.
OD-002 Q1–Q4 remain settled; the prior agreement record is unchanged.

[Sources and requirements](BASELINE_MODEL.md) · [Classification](TC_CLASSIFICATION_MATRIX.md) ·
[Pilots](JOURNEY_PILOT.md) · [Defect impact](DEFECT_GROUP_IMPACT_MATRIX.md)

The agreed root is the October 23 process direction: preserve the original
workbook, evaluate business milestones, distinguish behavior from coverage and
review inferred branches. This register distinguishes recorded internal agreements
from recommendations awaiting review. `CONFLICT`, `UNKNOWN` and `PROPOSED` use
PB §9's meanings. Named formal business/benchmark and QA owners and sign-off dates
remain **unassigned**; they are not implicitly the preparer, the LLM or the user.

## Decision register

| ID / label | Source-grounded question | Recorded direction / remaining review; decision owner | Remaining scope / dependencies |
|---|---|---|---|
| OD-001 **VERIFIED [POC]** fixture; formal source **CONFLICT** retained | TC-006's path declines role retry (`WB:S!D9`), but its dialogue accepts re-login, sees the form and submits (`E9`). PB §5; PLAN §6/P101. | Existing internal agreement: declined-retry primary; successful retry `VAR-TC-006-A`, failed retry `VAR-TC-006-B`. Named benchmark/business review still required for official attribution. | Internal target choice settled; dependent requirements remain reviewed separately. External TC certification pending; BR-012/014/015. |
| OD-002 **VERIFIED [POC] / ENGINEERING_AGREED_POC**; formal policy **UNKNOWN**; Job-source applicability **CONFLICT** retained | [Four-branch review](OD002_STATUS_DECISION_REVIEW.md): WB:S!A6:F6; WB:D!D21/G21/K21; PB §4; PLAN §5; KB30 GF status/timing/submission claims; JOB30. Visible blank status differs from no observation; Auto approved differs from bank receipt. | Requesting project-side user approved Q1–Q4 on 2026-11-02: visible-blank review-request A with prerequisites and no eligibility/award claim; narrow status-only/no-unnecessary-request B; approval/payout/bank-receipt explanation and clarification priority C; clarify before status-dependent submission D. Q2/Q3 explicitly provisional; all four internal POC only. | Internal choices settled. Original submission coverage remains separate from B/C handling; D supplies coverage only after A and its stages are established/exercised. Formal status/duplicate policy, C's financial remedy and dependent OD-004/005/007/010/014 requirements remain open. BR-009/JRN-TC-003/VAR-TC-003-A/B/C use the OD002-REVIEW-0.2 overlay; other BR/BP impact is unchanged. |
| OD-003 **VERIFIED [POC]** transition; formal source **CONFLICT** retained | TC-027 selects/opens App before Finance → Transactions (`WB:S!E16`); F16 says Portal only, D16 says App or Portal. TC-029 E18 includes the computer-Portal redirect. PB §5; PLAN P103; KB GM-STATUS. | Existing internal agreement: retain App selection, explicitly explain computer Portal and confirm readiness before controls; retain style/preferences. Portal-unavailable recovery keeps its scope/consent limits. | Internal transition settled; formal benchmark review and dependent policies remain pending. TC-029 / GM variants share BR-005/008/015. |
| OD-004 **CONFLICT**; new directions **PROPOSED** | [Trigger table T01–T18 and source conflicts](OD004_OD005_TRIGGER_TIMING_REVIEW.md#2-intent-entry-age-and-lob-trigger-table): JOB30's age-only open question conflicts with first-recent education; direct/accepted recent guidance conflicts with recent rules and the beyond-only `start_guidance` gate; WB TC-027 E16 adds education to upfront dual intent. Generic upfront status interest and re-offers after decline also need bounded precedence. DF-018 remains TC-004 beyond (`WB:S!C7:D7`), despite within-threshold fix note N22. | [Round 3 Q1–Q5](OD004_OD005_TRIGGER_TIMING_REVIEW.md#6-human-review-frontier) await project-side internal decisions: recent age-only education, recent explicit-guidance direction, older GM upfront direct handling, one clarification for ambiguous upfront interest, and no automatic repeated offer after decline. Business/benchmark certification remains separate; original sources and owner-reported closures retained. | BR-001/002/003/009/014 and shared impact in review §5. Recent-guidance admission/fixture details depend on Q2; no current recent accepted path is asserted. TC-003's agreed subset, TC-009 submit-only and the narrow GM status-only exception remain settled. Neither universal education nor universal status-first intake is adopted. |
| OD-005 **CONFLICT**; formal date conventions **UNKNOWN**; new directions **PROPOSED** | [Timing/date/evidence sheet](OD004_OD005_TRIGGER_TIMING_REVIEW.md#3-timing-and-date-conventions): cancellation-age routing differs from approval after order made; exact weekday cutoffs are inclusive elapsed days. Export initializes a stored UTC+8 weekday once, with no automatic age increment/weekday refresh found. No absolute-date Tool API. WB “days”/bank-credit and GM prepared-food wording conflict with qualified POC timing and stage-specific evidence; unconditional Job take/attach wording conflicts with no-photo continuation. | [Round 3 Q6–Q7](OD004_OD005_TRIGGER_TIMING_REVIEW.md#6-human-review-frontier) await internal decisions on bounded same-date cancellation-age fixtures and a known-no-photo instruction exception. Source-qualified approval/payout/receipt distinctions remain usable; business/policy owners must supply official calendar/clock and evidence policy. | BR-002/003/013; all applicable timing paths. Preserve GM recent “photo of the order,” older GF existing-photo condition and GM submission packed-items reference. No new exact payment date, photo-based denial, 90/5/3-day SLA, evidence substitute or early-form acceptance rule. |
| OD-006 **CONFLICT** | TC-027/029 allow full-or-partial compensation and TC-029 repeats the notice (`WB:S!E16,E18`). Adopted POC text says “will be partial”; H1 §6 item 2/KBC flag its certainty. | Business/content owner: decide amount/qualification wording and exactness. Until reviewed, retain the existing POC control as source-qualified, once before applicable navigation; never convert either example into a guaranteed individual award. | BR-018; TC-027/029; historical DF-014's delayed notice, not wholly absent content. |
| OD-007 **CONFLICT** / fixture detail **UNKNOWN** | TC-003's order is already visible before unconditional Date selector steps (`WB:S!E6`). TC-007 D10/F10 require a stuck-step repeat, but E10 shows bundled History/date/Confirm and no explicit failed-step retry. TC-006 E9 has consecutive cannot-see/can-see replies. JOB29 makes History conditional on missing order and separates one-by-one actions. | Benchmark + QA reviewers: define missing-order versus missing-control facts explicitly; propose a Date-selector first-failure fixture for TC-007, without claiming it already exists. Preserve mandatory waits; require only applicable recovery steps, not gratuitous Date selector usage. | BR-006/007/019; TC-003/005/006/007. Date-selector omissions need the actual precondition, not a wording-only verdict. |
| OD-008 **VERIFIED [POC]** fixture; formal source **CONFLICT** retained | TC-009 path says **GrabFood Portal status** (`WB:S!D12`); E12 declines status guidance and requests **Portal submission only**. KB GF-STATUS supports App status; JOB30 does not supply GF Portal status. | Existing internal agreement: Portal submission → failed accepted role retry → separate consented mock transfer. Preserve D12 discrepancy for formal review. | Internal target settled; do not add a status-first detour under OD-002. External target certification remains pending; BR-009/011/012/015. |
| OD-009 **CONFLICT** / final intent **UNKNOWN** | TC-004 offers guidance and immediately asks anything else with no reply (`WB:S!E7`, PLAN P105). TC-028 closes after “okay” (`E17`). DF-012 demands “Thank you for Calling Grab,” absent from TC-010's transfer script (`WB:D!G16`; `WB:S!E13`). “Payout question” in E13 may still be UC4-related. | Business + benchmark reviewers: add explicit offer response/finish signals to fixtures; distinguish normal closing from Flow-owned mock transfer. Require a clearly unrelated TC-010 topic or clarification. Review DF-012's possible truncated closing separately from its courtesy-phrase complaint. | BR-014/015/016/020; TC-004/009/010/028 and consent variants. Acknowledgement ≠ transfer consent or automatic resolution. |
| OD-010 **UNKNOWN**; conflicting recovery assumptions **CONFLICT** | Role authorization is documented (KB SHARED-REQUEST), but scope/timing of a **spoken role reminder on every successful submission** is unsettled. DF-007/009 request role/date advice absent from their example transcripts. DF-008 N12 suggests role establishes menu visibility; KB says missing link/form does not prove wrong role. | Business + benchmark reviewers: distinguish missing App link from missing form after article/scroll; adopt explicit role-access, retry-offer, consent, attempt and observation stages for the POC. Decide universal reminder applicability separately. Keep lack of role/access and lack of computer access distinct. | BR-010/012/015/019; TC-003/005/006/007/008/009/027/029. Do not declare every omitted reminder a confirmed defect or promise the UI will appear. |
| OD-011 **PROPOSED** | Which exact text is binding, for which version/channel? WB's sample speeches are illustrative (PB D-03); JOB29 explicitly fixes some POC statements. | Business/content owner + QA: approve a compact controlled-text register with source/version, exact text or hash and applicability. All other language is evaluated semantically. `PB D-*` and `PLAN D-*` must remain namespaced because their numbering differs. | BR-004/020 and exact portions of BR-003/015/018. No new mandatory greeting/preparation/thanks phrase is inferred from WB alone. |
| OD-012 **UNKNOWN** current verification | WB statuses are dated history. PLAN P012/P033 and PB §§0,7 explicitly report DF-014/018 resolved; DF-001 is Closed/Pass, DF-016 Not a defect, DF-017 status blank. “Recent defects resolved” is not an enumerated closure of all 18. | Defect owner + QA: retain each status event and obtain cited fix/retest evidence only where a new closure assurance or current baseline claim is required. Do not reopen by default. H1's KB closure stays separate from benchmark acceptance. | All groups: current regression verification not established. Owner-reported resolutions remain recorded as such. |
| OD-013 **UNKNOWN** | DF-013's silence/ASR explanation and DF-017's barge-in cause are hypotheses (`WB:D!G17,G21`). No numerical response SLA or synchronized audio/trace record is supplied for those reports. | Voice/environment owner + QA: define measurable response/audibility expectations and collect aligned audio, recognized input, displayed text and timing before attribution. Do not change barge-in settings from a tester hypothesis. | BR-017; voice impact plausibly spans all 15, but is directly reported only for TC-026/003. REST text alone cannot close audibility findings. |
| OD-014 **UNKNOWN** formal policy/UI | H1 §6 and KB retain provisional preparation/packing, evidence substitutes, early form acceptance and authenticated-screen limits; 90/5/3-day UC4 applicability is unresolved. OD-002 also exposes missing canonical status/duplicate policy and approved-but-unpaid remedies/triggers. Other Portal KB routes exist but standard POC guidance uses Search Bar. | Grab policy/UI owner: provide authoritative status meanings, dispute exceptions and any overdue-payment check/contact/escalation route and trigger; confirm applicable policy and screens. Keep reference facts qualified; defer alternate Portal routes and unsupported escalation rather than inventing rules. | BR-009/010/011/012/013 and alternate branches. Q1–Q4's internal guidance is agreed; formal semantics, financial resolution, individual eligibility and authenticated UI assurance remain blocked. Retrieval success is not eligibility, UI or production approval. |
| OD-015 **VERIFIED [POC]** governance; appointments/sign-off pending | Staged internal POC review is agreed in the v0.3 engineering record. Reviewer identities, accepted requirement versions and sampling plan are still unassigned. PB §§7–11's proposed five runs is not a reliability guarantee or established external count. | Retain agreed engineer draft → project-side provisional review → named business/benchmark and QA acceptance → scoped freeze; authorize executions separately. | OD-002 has its own explicit internal approval provenance. Governance alone does not appoint reviewers, approve dependent requirements, freeze a baseline or authorize tests. |

## 2026-11-02 limited engineering adjudication (does not resolve original conflicts)

| OD | Engineering status | Remaining benchmark / approval status |
|---|---|---|
| OD-001 | **ENGINEERING_AGREED_POC**: decline retry as original internal TC-006 fixture; accepted/success as VAR-TC-006-A; failed retry separate. | Original D9/E9 conflict retained; **benchmark owner review required**. |
| OD-008 | **ENGINEERING_AGREED_POC**: TC-009 Portal submission-only, failed role retry, separate explicit consent to mock transfer. | Original D12/E12 conflict retained; **benchmark owner review required**. |
| OD-003 | **ENGINEERING_AGREED_POC**: TC-027 explicit App → computer Portal readiness before navigation, preserve preferences. | Original E16/F16 conflict retained; **benchmark/business review required**. |
| OD-015 | **PROCESS_AGREED_POC**: named business/benchmark + QA review before freeze; distinct POC and formal sign-off. | **Names and acceptance authority still unassigned**; no baseline frozen. |
| OD-002 | **ENGINEERING_AGREED_POC**, Round 2 Q1–Q4: A review-request fixture; B status-only/no unnecessary duplicate; C approval-aware explanation/clarification priority; D status clarification before submission. | Requesting project-side user, 2026-11-02; [provenance and superseded wording](OD002_STATUS_DECISION_REVIEW.md#recorded-q1q4-approval-and-provenance). Formal policy/benchmark and QA sign-off pending; original Job-source conflict and dependent limits retained. |

No live test has been run under this update. These decisions guide **internal drafting only** until the dependent BR and fixture review is complete.

## Remaining blockers and next review batch

Q1–Q4 no longer need an internal answer. The following items block only the named
requirements, outcomes or formal acceptance scope; they do not rescind the agreed
fixtures or turn every journey into an undifferentiated blocker.

| Remaining decision | What is blocked / owner evidence needed |
|---|---|
| **OD-004 — education/intent triggers** | The prepared 18-row source table is reviewable, not accepted. Round 3 Q1–Q5 address the actual precedence gaps; a recent accepted-guidance contract depends on Q2 because the exported standard gate is beyond-only. DF-018's original beyond fixture and historical closure both remain. TC-003's settled subset and protected direct-submission/GM status-only boundaries are usable. |
| **OD-005 — timing/date interpretation** | Exact cutoff values and initialization-clock behavior are documented facts. Q6 proposes same-date internal fixtures; Q7 proposes the narrow no-photo wording exception. Official calendar/timezone/effective-date, absolute-date/cross-midnight conventions and final evidence policy remain unconfirmed. Qualified approval/payout/receipt distinctions do not establish a precise bank-payment or overdue trigger. |
| **OD-002 residual / OD-014 — formal policy and UI** | Canonical status meanings, universal duplicate/dispute policy, authorized approved-but-unpaid remedy/trigger, individual eligibility, evidence substitutes, early acceptance, 90/5/3-day applicability and authenticated routes/access. Policy/UI owners must supply authoritative evidence. C's bounded explanation is agreed; end-to-end financial resolution remains **BLOCKED_SPEC**. |
| **OD-006 / OD-011 — policy wording and exact text** | GM partial-compensation certainty/applicability and the versioned controlled-text register. Business/content and QA review must establish wording authority without converting sample dialogue or POC statements into guaranteed individual awards. |
| **OD-007 / OD-010 / OD-009 — fixture, access and finish boundaries** | Conditional History/stuck-step facts; universal successful-path role reminder and unavailable-role outcomes; explicit guidance/finish/transfer consent and genuine out-of-scope intent. Benchmark/business and QA reviewers must decide the applicable conditions. Agreed TC-006/009/027 primary choices remain intact. |
| **OD-001/003/008 formal attribution; OD-015 appointments/sign-off** | Formal benchmark ownership of the preserved source conflicts; named business/benchmark and QA reviewers, accepted requirement/fixture versions and sampling scope. Internal choices and staged governance are agreed; formal certification and any baseline freeze are pending. |
| **OD-012 / OD-013 — evidence acceptance dependencies** | Current closure/regression assurance and voice response/audibility expectations need defect/voice owner and QA evidence. These are evidence/acceptance gaps, not new business rules or proof that historical closures are invalid. |

**Current review batch: OD-004 + OD-005**, because the education trigger and the
timing/evidence content it selects must agree. The
[coupled review](OD004_OD005_TRIGGER_TIMING_REVIEW.md) now supplies the following
two outputs for scoped human decisions; their proposals are not yet adopted:

1. **Intent/entry/age/LOB trigger table:** required explanation, guidance offer/wait
   or direct navigation for each documented condition; preserve OD-008 submit-only,
   the GM status-only exception, TC-003 upfront dual intent and Q2/Q3's approval-aware
   handling. Use existing TCs as source examples, not 12 newly expanded specs.
2. **Date and stage convention sheet:** routing age versus approval origin,
   business-day/calendar conventions, timezone/boundaries and stage-appropriate
   evidence reminders; label unsupported decisions **UNKNOWN/CONFLICT** and
   preserve the existing approval/payout/bank-receipt distinction.

Alongside this batch, request **OD-014 owner evidence** on status/dispute meanings
and approved-but-unpaid remedies/triggers. Do not infer a remedy from a general
timeline. OD-015 reviewer appointments remain an outstanding governance action;
the user is not assigned formal authority by this recommendation.

Then prioritize **OD-007/010/009** for navigation/access/consent fixtures and
**OD-006/011** for GM certainty and controlled wording. Track OD-012/013 evidence
needs before any new closure or voice acceptance claim. BP taxonomy confirmation
remains pending without restarting classification. This is a recommendation for
subsequent review, not adoption of those decisions. **Business Acceptance Baseline
v1.0 remains NOT FROZEN**; no execution or evidence regrade follows this record.

## Round 1 — original structured review prompts (historical)

The following Round 1 prompts preserve the earlier review history. Their internal
choices were subsequently agreed as recorded above; they are **not new questions
to reopen**. The [worksheet](REVIEW_DECISION_WORKSHEET.md) retains the separate
unfilled formal approval fields. For each new OD decision capture selected option,
scope, named deciding/QA reviewers, date, rationale/evidence and affected versions.

TC-003's [Round 2 Q1–Q4](OD002_STATUS_DECISION_REVIEW.md#7-review-frontier-and-adoption-limits)
are now agreed internally; its remaining frontier is the scoped dependency table above.
For TC-006/009, the internal fixture choices are settled; remaining source conflicts
block formal target certification, not use of those agreed drafting choices.
TC-027 preserves the agreed redirect and readiness checkpoint.

## Review round 1 — original questions retained as history

These recommendations formed the Round 1 review frontier. A **yes** to a question
accepts only its stated recommendation, not formal Grab policy or live execution.
Dependent policy/wording decisions remain in the register for the next round.

❓ **Q1 — TC-006 fixture:** Shall the proposed primary target follow D9's declined
retry, with E9's successful retry retained as `VAR-TC-006-A`, pending named review?

➡️ **Recommended: yes.** Preserve both branches and explicitly approve which one
counts toward the original TC; keep failed retry separate (OD-001).

❓ **Q2 — TC-009 fixture:** Shall the proposed target be E12's submission-only
Portal role-retry failure and consented mock transfer, with D12's Portal-status
description recorded as a conflict requiring correction approval?

➡️ **Recommended: yes.** This avoids introducing an unsupported GrabFood status
route and preserves the benchmark discrepancy (OD-008).

❓ **Q3 — TC-027 transition:** Shall the proposed journey retain App selection,
explicitly establish computer-Portal readiness, then continue the Portal status
route with the existing preferences?

➡️ **Recommended: yes.** It matches the documented POC navigation boundary while
keeping portal-unavailable recovery and policy wording under review (OD-003).

❓ **Q4 — Review ownership:** Shall the next step be a named business/benchmark
and QA review of the three pilots and their blocked decisions before freezing an
acceptance version?

➡️ **Recommended: yes.** Resolve high-impact semantics, then use the same saved
evidence to check that two reviewers agree; authorize fresh baseline execution
separately (OD-015).

Decision capture must record `OD ID`, selected option, rationale, source/approval
scope, named decision-maker, date, affected BR/JRN/VAR versions and superseded
interpretation. Future unanswered recommendations remain **PROPOSED**; OD-002
Q1–Q4 have explicit answers recorded above. Original formal source conflicts
remain **CONFLICT** alongside the Round 1 agreements and the bounded OD-002 approval.
