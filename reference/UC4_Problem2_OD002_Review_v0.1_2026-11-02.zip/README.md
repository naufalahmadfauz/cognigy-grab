# UC4 Problem #2 — Engineering Review Pack v0.3 + OD-002 review

**Date:** 2026-11-02  
**Status:** **four limited internal POC engineering directions recorded** (OD-001/003/008/015); individual BR/JRN acceptance and formal Grab benchmark/policy approval **NOT obtained**; **NOT executed**  
**Scope:** business journey classification and defect impact/traceability only. This package does not edit Cognigy, the Python runner, or original source records.

## Round 2 — OD-002 status decision review

[OD002_STATUS_DECISION_REVIEW.md](OD002_STATUS_DECISION_REVIEW.md) is the new
`OD002-REVIEW-0.1` addendum. It supplies source-backed A/B/C/D decisions, mandatory
milestones/prohibitions, separate behavior and TC-003 coverage criteria, limited
OD-004/005/010/014 dependencies, existing BP/BR/JRN/DG impact and four unanswered
human-review questions. Recommendations remain **PROPOSED**.

The eight source-pack documents were integrated from the actual v0.3 archive,
then amended only for this addendum's links and current internal decision scope.
The historical decision record and BP memberships are retained. The original
pack's v0.2 README title/stale decision checklist did not supersede its explicit
v0.3 engineering agreements. Latest historical KB/Job evidence was read from the
October 30 export matching the Problem #1 handover hash.

**Change summary:** new OD-002 review; restored v0.3 records/family register;
focused cross-references and stale internal-versus-formal status clarification;
source/version preservation; glossary definitions for the status/payment and
existing process-family distinctions. No new business approval or execution.

## What changed in P2-ENG-DECISIONS-0.3 (2026-11-02)

The user explicitly agreed in the conversation to four **provisional internal engineering directions**. See [ENGINEERING_DECISIONS_2026-11-02.md](ENGINEERING_DECISIONS_2026-11-02.md). The former source contradictions remain documented, no named business/QA reviewers have been assigned, no new Agent runs have been executed, and no acceptance baseline is frozen. The existing 0.2 source classifications and proposed groupings remain draft.

## What changed from P2-DRAFT-0.1

Historical v0.2 change record: that pack was a narrowly revised **copy** of the
five uploaded Markdown drafts. This repository now continues the supplied v0.3
pack; earlier document bytes are preserved in the archives below.

1. `TC_CLASSIFICATION_MATRIX.md`: adds **BP-01 to BP-07** reusable shared process families, a 15-TC primary/secondary/conditional map, and safeguards against turning families into blanket pass or defect labels.
2. `DEFECT_GROUP_IMPACT_MATRIX.md`: adds a **BR-first impact-based regression selection procedure** and a worked DG-005 case, explicitly separating directly reported TCs, plausible applicability and negative controls.
3. `BASELINE_MODEL.md`: classifies **BR-017 as QA_EVIDENCE** and **BR-020 as QA_SEMANTIC_ACCEPTANCE**, leaving the IDs and source provenance unchanged; other BRs remain candidate Agent behavior rules.
4. `JOURNEY_PILOT.md`: adds a compact TC-003/006/027 process-family and review-gate crosswalk.
5. `OPEN_DECISIONS.md`: adds unapproved decision-capture guidance and points to the review worksheet.
6. `REVIEW_DECISION_WORKSHEET.md`: a four-decision **review artifact**, not a decision or authorization.

## Most important distinction

**BP** = shared business-process family; **BR** = source-linked requirement; **JRN** = normalized journey; **TC** = original Grab test; **DF** = original defect report; **DG** = proposed grouping of behavior findings; **VAR** = fixture variant. Their mappings are many-to-many. Group membership does **not** demonstrate a common implementation cause, active failure, or remediation. Review source `BASELINE_MODEL.md` for provenance and authority.

## Next human review (in order)

- [ ] Confirm that BP family membership correctly groups business capabilities (not just similar dialogue).
- [ ] Review [OD-002 Q1–Q4](OD002_STATUS_DECISION_REVIEW.md#7-review-frontier-and-adoption-limits); distinguish status behavior from original submission coverage.
- [x] Preserve OD-001 internal choice: TC-006 declined-retry primary; formal benchmark adjudication remains pending.
- [x] Preserve OD-008 internal choice: TC-009 Portal submission-only; formal benchmark adjudication remains pending.
- [x] Preserve OD-003 internal choice: TC-027 explicit App → Portal readiness; formal benchmark adjudication remains pending.
- [x] Preserve OD-015 staged internal POC review governance.
- [ ] Assign OD-015 reviewers and approval scope; unresolved issues stay UNKNOWN/CONFLICT.
- [ ] Once the appropriate reviewers approve, freeze a versioned **business acceptance baseline**, then take an independent snapshot of the **currently served Agent** before behavior comparisons.

**Do not infer:** 15/15 benchmark passes, 18 open defects, 9 common root causes, formal Grab policy approval, or that a POC configuration change was made. Problem #1 KB v0.3 is separately closed for its verified isolated-POC scope.

## Files

- `BASELINE_MODEL.md`
- `TC_CLASSIFICATION_MATRIX.md`
- `JOURNEY_PILOT.md`
- `DEFECT_GROUP_IMPACT_MATRIX.md`
- `OPEN_DECISIONS.md`
- `REVIEW_DECISION_WORKSHEET.md`
- `ENGINEERING_DECISIONS_2026-11-02.md`
- `OD002_STATUS_DECISION_REVIEW.md`

The original documents have **repository-relative links** to original sources and other repo files, which resolve when these Markdown files are placed into `docs/problem2/` in the original repo. The ZIP itself does not contain or alter those source assets.

## Version history and preservation

| Version / date | Immutable archive and SHA-256 | Change scope |
|---|---|---|
| `P2-DRAFT-0.1` / 2026-11-02 | [Local draft snapshot](../../reference/UC4_Problem2_Local_Draft_v0.1_2026-11-02.zip); `e07f611fa420c1bba181de8275d4eb3b7649c37338e65cbf8bb2634ca47c100f` | Preservation ZIP created in Round 2 from the five untouched pre-edit local files; not a newly discovered external release. |
| `P2-DRAFT-0.2` / 2026-11-02 | [Supplied structural pack](../../reference/UC4_Problem2_Structural_Review_Pack_v0.2.zip); `175d562783fbaec5f731a7f59861eb53d55def151882c872c856a6ac76fc9ea1` | BP-01–BP-07, requirement kinds, BR-led regression selection and review worksheet. |
| `P2-ENG-DECISIONS-0.3` / 2026-11-02 | [Supplied engineering pack](../../reference/UC4_Problem2_Engineering_Review_Pack_v0.3.zip); `3244e5ec8ae7cdd28a76dd3f4aec144ebbf34fa56a83b5b23b24be5080463606` | Four limited agreements and dedicated decision record. TC classification/defect matrix identical to supplied v0.2; other overlays preserved in this archive. |
| `OD002-REVIEW-0.1` / 2026-11-02 | [Round 2 addendum and verification](OD002_STATUS_DECISION_REVIEW.md#8-version-and-verification-record) | New review proposals and focused integration corrections; not a global acceptance-version freeze or formal approval. |

Both supplied packs are byte-identical copies of their Downloads originals. The
October 23 source bundle and Grab workbook are unchanged. The v0.3
`ENGINEERING_DECISIONS_2026-11-02.md` remains byte-identical to its archive member;
unfilled formal reviewer fields do not rescind the four internal agreements.
