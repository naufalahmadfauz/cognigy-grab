# Problem #2 — open decisions and review frontier

**P2-DRAFT-0.2 source register + P2-ENG-DECISIONS-0.3 overlay · 2026-11-02.**

**Update:** Project-side user explicitly agreed to internal POC engineering directions for **OD-001, OD-008, OD-003 and OD-015** on 2026-11-02. See [engineering decision record](ENGINEERING_DECISIONS_2026-11-02.md). These are **not formal Grab approvals**; source conflicts in the register remain, and reviewer names/acceptance sign-off are still missing. Other OD entries retain their prior status.

**Round 2:** [OD-002 decision review](OD002_STATUS_DECISION_REVIEW.md) is ready for
human review, **not adopted**. It uses the actual v0.3 pack and handover-verified
JOB30/KB30. A/B/C/D preserve the existing target / VAR-TC-003-A/B/C identities.
Scoped OD-004/005/010/014 dispositions are in its §5; none closes those whole ODs.

[Sources and requirements](BASELINE_MODEL.md) · [Classification](TC_CLASSIFICATION_MATRIX.md) ·
[Pilots](JOURNEY_PILOT.md) · [Defect impact](DEFECT_GROUP_IMPACT_MATRIX.md)

The agreed root is the October 23 process direction: preserve the original
workbook, evaluate business milestones, distinguish behavior from coverage and
review inferred branches. This draft records recommendations; it does not enact
them. `CONFLICT`, `UNKNOWN` and `PROPOSED` use PB §9's meanings. Named owners and
review dates are **unassigned**, not implicitly the preparer or the LLM.

## Decision register

| ID / label | Source-grounded question | Recommendation for review; decision owner | Effect while unresolved |
|---|---|---|---|
| OD-001 **VERIFIED [POC]** fixture; formal source **CONFLICT** retained | TC-006's path declines role retry (`WB:S!D9`), but its dialogue accepts re-login, sees the form and submits (`E9`). PB §5; PLAN §6/P101. | Existing internal agreement: declined-retry primary; successful retry `VAR-TC-006-A`, failed retry `VAR-TC-006-B`. Named benchmark/business review still required for official attribution. | Internal target choice settled; dependent requirements remain reviewed separately. External TC certification pending; BR-012/014/015. |
| OD-002 **PROPOSED**; policy **UNKNOWN**; follow-up applicability **CONFLICT** | [Four-branch review](OD002_STATUS_DECISION_REVIEW.md): WB:S!A6:F6; WB:D!D21/G21/K21; PB §4; PLAN §5; KB30 GF status/timing/submission claims; JOB30. Visible blank status differs from no observation; Auto approved differs from bank receipt. | Q1–Q4 await human answers: review-only A fixture, narrow no-unnecessary-request B, bounded explanation/clarification C with status-aware priority over generic FOLLOW-UP, and deferred submission while D is unclear. No automatic transfer or inferred payout remedy. | Original submission coverage remains separate from B/C/D behavior. Precise status/duplicate semantics and C's financial-resolution policy remain blocking. BR-001/003/006/007/009–014; BP-04 primary, conditional shared impact in review §6. |
| OD-003 **VERIFIED [POC]** transition; formal source **CONFLICT** retained | TC-027 selects/opens App before Finance → Transactions (`WB:S!E16`); F16 says Portal only, D16 says App or Portal. TC-029 E18 includes the computer-Portal redirect. PB §5; PLAN P103; KB GM-STATUS. | Existing internal agreement: retain App selection, explicitly explain computer Portal and confirm readiness before controls; retain style/preferences. Portal-unavailable recovery keeps its scope/consent limits. | Internal transition settled; formal benchmark review and dependent policies remain pending. TC-029 / GM variants share BR-005/008/015. |
| OD-004 **CONFLICT** | Education triggers differ by intent/entry path. DF-018's TC-004 is beyond threshold (`WB:S!C7:D7`), but its fix note cites **within threshold** (`WB:D!N22`). PB D-05's relevant-status rule must also be scoped alongside JOB29's submit-only path and POC's later direct GM status-only exception. | Business + benchmark reviewers: publish an intent/age trigger table: age-only → clarify goal; recent education where applicable; older open-question policy response where applicable; direct status/submission paths governed by their explicit exceptions. Keep DF-018's owner-reported closure, but do not treat N22 as proof of original-fixture regression. | BR-001/002/003/009; TC-003/004/005/009/027/028/029 and direct-status negative controls. Do not make universal education or universal status-first intake binding. |
| OD-005 **CONFLICT**; date conventions **UNKNOWN** | WB uses “days” for usual approval; E16/E18 instead promise bank credit in 3–5 business days. KB GF/GM TIMING and H1 distinguish business-day approval, regular payout and bank receipt. C cells say order age; sample inputs sometimes say order **made**, while routing uses cancellation age. GM E14/E15/E17 refer to prepared-food photos. | Business/policy reviewer: use source-qualified KB timing distinctions for the POC; clarify age origin/timezone and the correct stage-specific evidence reminder. GM recent JOB29 says “photo of the order”; submission requires packed-items guidance. Preserve conflicting WB text as history. | BR-002/003/013; all timing paths, especially TC-025–029. No guaranteed payment date or automatic photo-based ineligibility. |
| OD-006 **CONFLICT** | TC-027/029 allow full-or-partial compensation and TC-029 repeats the notice (`WB:S!E16,E18`). Adopted POC text says “will be partial”; H1 §6 item 2/KBC flag its certainty. | Business/content owner: decide amount/qualification wording and exactness. Until reviewed, retain the existing POC control as source-qualified, once before applicable navigation; never convert either example into a guaranteed individual award. | BR-018; TC-027/029; historical DF-014's delayed notice, not wholly absent content. |
| OD-007 **CONFLICT** / fixture detail **UNKNOWN** | TC-003's order is already visible before unconditional Date selector steps (`WB:S!E6`). TC-007 D10/F10 require a stuck-step repeat, but E10 shows bundled History/date/Confirm and no explicit failed-step retry. TC-006 E9 has consecutive cannot-see/can-see replies. JOB29 makes History conditional on missing order and separates one-by-one actions. | Benchmark + QA reviewers: define missing-order versus missing-control facts explicitly; propose a Date-selector first-failure fixture for TC-007, without claiming it already exists. Preserve mandatory waits; require only applicable recovery steps, not gratuitous Date selector usage. | BR-006/007/019; TC-003/005/006/007. Date-selector omissions need the actual precondition, not a wording-only verdict. |
| OD-008 **VERIFIED [POC]** fixture; formal source **CONFLICT** retained | TC-009 path says **GrabFood Portal status** (`WB:S!D12`); E12 declines status guidance and requests **Portal submission only**. KB GF-STATUS supports App status; JOB30 does not supply GF Portal status. | Existing internal agreement: Portal submission → failed accepted role retry → separate consented mock transfer. Preserve D12 discrepancy for formal review. | Internal target settled; do not add a status-first detour under OD-002. External target certification remains pending; BR-009/011/012/015. |
| OD-009 **CONFLICT** / final intent **UNKNOWN** | TC-004 offers guidance and immediately asks anything else with no reply (`WB:S!E7`, PLAN P105). TC-028 closes after “okay” (`E17`). DF-012 demands “Thank you for Calling Grab,” absent from TC-010's transfer script (`WB:D!G16`; `WB:S!E13`). “Payout question” in E13 may still be UC4-related. | Business + benchmark reviewers: add explicit offer response/finish signals to fixtures; distinguish normal closing from Flow-owned mock transfer. Require a clearly unrelated TC-010 topic or clarification. Review DF-012's possible truncated closing separately from its courtesy-phrase complaint. | BR-014/015/016/020; TC-004/009/010/028 and consent variants. Acknowledgement ≠ transfer consent or automatic resolution. |
| OD-010 **UNKNOWN**; conflicting recovery assumptions **CONFLICT** | Role authorization is documented (KB SHARED-REQUEST), but scope/timing of a **spoken role reminder on every successful submission** is unsettled. DF-007/009 request role/date advice absent from their example transcripts. DF-008 N12 suggests role establishes menu visibility; KB says missing link/form does not prove wrong role. | Business + benchmark reviewers: distinguish missing App link from missing form after article/scroll; adopt explicit role-access, retry-offer, consent, attempt and observation stages for the POC. Decide universal reminder applicability separately. Keep lack of role/access and lack of computer access distinct. | BR-010/012/015/019; TC-003/005/006/007/008/009/027/029. Do not declare every omitted reminder a confirmed defect or promise the UI will appear. |
| OD-011 **PROPOSED** | Which exact text is binding, for which version/channel? WB's sample speeches are illustrative (PB D-03); JOB29 explicitly fixes some POC statements. | Business/content owner + QA: approve a compact controlled-text register with source/version, exact text or hash and applicability. All other language is evaluated semantically. `PB D-*` and `PLAN D-*` must remain namespaced because their numbering differs. | BR-004/020 and exact portions of BR-003/015/018. No new mandatory greeting/preparation/thanks phrase is inferred from WB alone. |
| OD-012 **UNKNOWN** current verification | WB statuses are dated history. PLAN P012/P033 and PB §§0,7 explicitly report DF-014/018 resolved; DF-001 is Closed/Pass, DF-016 Not a defect, DF-017 status blank. “Recent defects resolved” is not an enumerated closure of all 18. | Defect owner + QA: retain each status event and obtain cited fix/retest evidence only where a new closure assurance or current baseline claim is required. Do not reopen by default. H1's KB closure stays separate from benchmark acceptance. | All groups: current regression verification not established. Owner-reported resolutions remain recorded as such. |
| OD-013 **UNKNOWN** | DF-013's silence/ASR explanation and DF-017's barge-in cause are hypotheses (`WB:D!G17,G21`). No numerical response SLA or synchronized audio/trace record is supplied for those reports. | Voice/environment owner + QA: define measurable response/audibility expectations and collect aligned audio, recognized input, displayed text and timing before attribution. Do not change barge-in settings from a tester hypothesis. | BR-017; voice impact plausibly spans all 15, but is directly reported only for TC-026/003. REST text alone cannot close audibility findings. |
| OD-014 **UNKNOWN** formal policy/UI | H1 §6 and KB retain provisional preparation/packing, evidence substitutes, early form acceptance and authenticated-screen limits; 90/5/3-day UC4 applicability is unresolved. Other Portal KB routes exist but standard POC guidance uses Search Bar. | Grab policy/UI owner: confirm applicable policy and screens. Keep reference facts qualified; defer alternate Portal routes and unsupported escalation rather than inventing rules. | BR-010/011/012/013 and alternate branches. Retrieval success is not eligibility, UI or production approval. |
| OD-015 **VERIFIED [POC]** governance; appointments/sign-off pending | Staged internal POC review is agreed in the v0.3 engineering record. Reviewer identities, accepted requirement versions and sampling plan are still unassigned. PB §§7–11's proposed five runs is not a reliability guarantee or established external count. | Retain agreed engineer draft → project-side provisional review → named business/benchmark and QA acceptance → scoped freeze; authorize executions separately. | Process agreement does not approve OD-002, appoint reviewers, freeze a baseline or authorize tests. |

## 2026-11-02 limited engineering adjudication (does not resolve original conflicts)

| OD | Engineering status | Remaining benchmark / approval status |
|---|---|---|
| OD-001 | **ENGINEERING_AGREED_POC**: decline retry as original internal TC-006 fixture; accepted/success as VAR-TC-006-A; failed retry separate. | Original D9/E9 conflict retained; **benchmark owner review required**. |
| OD-008 | **ENGINEERING_AGREED_POC**: TC-009 Portal submission-only, failed role retry, separate explicit consent to mock transfer. | Original D12/E12 conflict retained; **benchmark owner review required**. |
| OD-003 | **ENGINEERING_AGREED_POC**: TC-027 explicit App → computer Portal readiness before navigation, preserve preferences. | Original E16/F16 conflict retained; **benchmark/business review required**. |
| OD-015 | **PROCESS_AGREED_POC**: named business/benchmark + QA review before freeze; distinct POC and formal sign-off. | **Names and acceptance authority still unassigned**; no baseline frozen. |

No live test has been run under this update. These decisions guide **internal drafting only** until the dependent BR and fixture review is complete.

## Round 1 — original structured review prompts (historical)

The following Round 1 prompts preserve the earlier review history. Their internal
choices were subsequently agreed as recorded above; they are **not new questions
to reopen**. The [worksheet](REVIEW_DECISION_WORKSHEET.md) retains the separate
unfilled formal approval fields. For each new OD decision capture selected option,
scope, named deciding/QA reviewers, date, rationale/evidence and affected versions.

TC-003's current frontier is [Round 2 Q1–Q4](OD002_STATUS_DECISION_REVIEW.md#7-review-frontier-and-adoption-limits).
For TC-006/009, the internal fixture choices are settled; remaining source conflicts
block formal target certification, not use of those agreed drafting choices.
TC-027 preserves the agreed redirect and readiness checkpoint.

## Review round 1 — original questions retained as history

These recommendations formed the Round 1 review frontier. A **yes** to a question
accepts only its stated recommendation, not formal Grab policy or live execution.
Dependent policy/wording decisions remain in the register for the next round.

❓ **Q1 — TC-006 fixture:** Shall the proposed primary target follow D9's declined
retry, with E9's successful retry retained as `VAR-TC-006-A`, pending named review?

➡️ **Recommended: yes.** Preserve both branches and explicitly approve which one
counts toward the original TC; keep failed retry separate (OD-001).

❓ **Q2 — TC-009 fixture:** Shall the proposed target be E12's submission-only
Portal role-retry failure and consented mock transfer, with D12's Portal-status
description recorded as a conflict requiring correction approval?

➡️ **Recommended: yes.** This avoids introducing an unsupported GrabFood status
route and preserves the benchmark discrepancy (OD-008).

❓ **Q3 — TC-027 transition:** Shall the proposed journey retain App selection,
explicitly establish computer-Portal readiness, then continue the Portal status
route with the existing preferences?

➡️ **Recommended: yes.** It matches the documented POC navigation boundary while
keeping portal-unavailable recovery and policy wording under review (OD-003).

❓ **Q4 — Review ownership:** Shall the next step be a named business/benchmark
and QA review of the three pilots and their blocked decisions before freezing an
acceptance version?

➡️ **Recommended: yes.** Resolve high-impact semantics, then use the same saved
evidence to check that two reviewers agree; authorize fresh baseline execution
separately (OD-015).

Decision capture must record `OD ID`, selected option, rationale, source/approval
scope, named decision-maker, date, affected BR/JRN/VAR versions and superseded
interpretation. For new decisions, including OD-002, unanswered recommendations
remain **PROPOSED**. Original formal source conflicts remain **CONFLICT** alongside
the four already-recorded internal agreements.
