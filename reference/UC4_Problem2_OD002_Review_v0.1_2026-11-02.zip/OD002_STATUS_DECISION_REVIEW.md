# OD-002 — compensation-status decision review

**OD002-REVIEW-0.1 · 2026-11-02 · PROPOSED for internal POC human review.**

[Decision register](OPEN_DECISIONS.md) · [TC-003 pilot](JOURNEY_PILOT.md#jrn-tc-003) ·
[Requirements / source manifest](BASELINE_MODEL.md) ·
[Defect impact](DEFECT_GROUP_IMPACT_MATRIX.md)

## 1. Decision in brief and continuity

**Recommendation:** choose the next action from the merchant's observed
compensation status **and remaining goal**. Preserve TC-003's full App submission
target; a correct already-approved answer does not complete that target.

- **A:** A visible relevant order with no compensation status, plus a retained
  request for review, supports the existing POC submission guidance. It does not
  establish rejection, eligibility or an entitlement to compensation.
- **B:** For reported `Auto approved` and a status-only goal, propose explaining
  the reported approval and avoiding an unnecessary new compensation request.
- **C:** For reported `Auto approved` and missing money, explain approval versus
  regular payout versus bank receipt; retain the unpaid concern. A guaranteed
  payment date, new-claim remedy or escalation rule is not established.
- **D:** If the status cannot be identified, clarify the current screen/observation
  before selecting a submission branch. A missing order is not a blank status.

The narrow B/C no-duplicate interpretation remains **PROPOSED**. There is no
blanket rule here that an approved order can never be disputed again. The existing
Job's generic non-arrival follow-up needs an explicit priority decision when
approval is already reported; see §3.

### Preserved agreements and source continuity

The v0.3 [engineering decision record](ENGINEERING_DECISIONS_2026-11-02.md) and
the user's Round 2 instruction establish these **VERIFIED [POC] internal
engineering agreements**, not formal Grab approvals. This preserves the record's
`ENGINEERING_AGREED_POC` / `PROCESS_AGREED_POC` scope:

| Decision | Preserved scope |
|---|---|
| OD-001 | TC-006's primary fixture declines the role retry; successful and failed accepted retries remain distinct variants. |
| OD-008 | TC-009 targets Portal submission only; no invented GrabFood Portal-status route. |
| OD-003 | TC-027 explicitly transitions from App selection to computer Portal before Portal status controls. |
| OD-015 | Internal POC review and acceptance governance; review does not authorize execution or formal Grab acceptance. |

**Input reconciliation completed:** the repository initially held five v0.1
drafts. The supplied [Engineering Review Pack v0.3](../../reference/UC4_Problem2_Engineering_Review_Pack_v0.3.zip)
was located, authenticated and read against them; its eight documents were
integrated before this review's focused amendments. The pack is a
`P2-ENG-DECISIONS-0.3` overlay on `P2-DRAFT-0.2`, not a frozen acceptance baseline.
Its README's older v0.2 title and pending-decision prompts are historical residue;
the explicit v0.3 agreement record takes precedence for internal fixture choices.
Existing BP-01–BP-07 classifications/mappings are retained. Original v0.1, supplied
v0.2 and supplied v0.3 bytes are preserved in the [version history](README.md#version-history-and-preservation).

This document introduces no approved OD-002 business rule. Its acceptance criteria
are review proposals; `behavior_verdict=NOT_RUN` and `coverage_verdict=NOT_RUN`
throughout. No saved conversation is regraded. Business Acceptance Baseline v1.0
is not declared complete.

## 2. Source-backed findings

Source keys and original archive paths/hashes are retained in
[BASELINE_MODEL.md](BASELINE_MODEL.md#sources-and-authority).
`WB:S` means **Scenarios**; `WB:D` means **Defect Log**. A cell extraction is a
documentary fact, not an approved policy. `VERIFIED [POC]` means an existing
source-backed internal POC rule; `PROPOSED` means this review still needs a
decision; `UNKNOWN` means missing policy/evidence; `CONFLICT` preserves incompatible
statements or an unresolved rule interaction.

### Original benchmark and decision records

| Source | What a reviewer needs to know | Authority / consequence |
|---|---|---|
| `WB:S!A6:F6` | TC-003 is GrabFood, beyond threshold/about two weeks, App, one-by-one, no loudspeaker. D6 includes status then App submission; F6 calls it the full App happy path. E6 supplies both goals upfront and ends with a merchant completion report. | Original intended coverage. E6 never supplies an explicit not-compensated status or an individual eligibility decision. Greeting text does not prove preparation. |
| `WB:S!E6` | The Agent describes auto-approved statuses, but the merchant only confirms order/details visibility before submission. There is **no literal merchant reply “Auto approved.”** Date selector is used even after order visibility. | Preserve the missing status observation and OD-007's conditional-recovery conflict. Do not manufacture a transcript or require unnecessary date recovery. |
| `WB:D!D21,G21(1)` / `DF-017/F01` | DF-017 is directly associated with **TC-003**. Tester says Auto approved needs no new Request for Compensation and the merchant waits for the next payout cycle; the reported script comparison includes the quoted Auto approved answer missing from E6. | Strong feedback for a **PROPOSED** no-unnecessary-request interpretation; not independent policy approval or proof of an actual payment. |
| `WB:D!G21(2)` / `DF-017/F02` | Tester positively describes asking what the merchant sees and adapting the next step. | Positive evidence for observation-based behavior, not a complete TC pass. |
| `WB:D!G21(3)` / `DF-017/F03` | Spoken/displayed response divergence during barge-in is reported separately; disabling barge-in is the tester's suggested remedy. | Voice evidence/cause remains **UNKNOWN**, under OD-013 / BR-017 / DG-009. OD-002 does not establish or resolve that cause. |
| `WB:D!K21,M21` | Original status and retest-result cells are blank. | Retain blanks; do not turn DF-017 into Open, Closed or Pass. |
| `PB §4`, `PLAN §5/P079–098` | Both present the four status/goal branches as candidates needing approval. PB D-09 forbids inferred branches becoming policy; PB D-10 separates behavior from coverage. | Existing agreed evaluation direction; branch outcomes remain source-qualified proposals. PLAN/PB `D-*` numbers are separately namespaced. |

### KB v0.3 article and claim evidence

Each article below is version **0.3.0**, `adoption=provisional_poc`,
`formal_approval=pending` in the inspected **KB30** export. Full article ID is
the chunk ID without its `-C01`/`-C02` suffix. Metadata, claim associations and text
were read from the export and compared with the previously inspected KB29 source:
all 17 articles' metadata and 20 chunks' text/claim associations match. This agrees
with H1 §§2–3; neither static comparison establishes today's served configuration.

| Chunk / exact claim IDs | Supported fact | Limit relevant to OD-002 |
|---|---|---|
| `UC4-MY-GF-STATUS-001-C01`; `UC4-MY-GF-CLAIM-005` | App → Orders → Cancelled → relevant order's displayed compensation status. Describes current-month cancellations/auto-approved status. **“An approved status is not proof that the bank received payment.”** | Missing order/link is not rejection. No complete status dictionary, universal duplicate-request prohibition or authenticated-screen validation. |
| `UC4-MY-GF-TIMING-001-C01`; `UC4-MY-GF-CLAIM-007` | Usual approval within **1–2 business days after the order was made**, followed by the next regular payout cycle, subject to policy. Approval, processing, payout cycle and bank receipt are separate stages. | Not an end-to-end SLA, a new clock starting at the status inquiry, or a bank-credit guarantee. |
| `UC4-MY-GF-SUBMIT-001-C01`; `UC4-MY-GF-CLAIM-012`, `UC4-MY-GF-CLAIM-013`, `UC4-MY-GF-CLAIM-014` | Relevant cancelled order → present Request for compensation link → Report a payment dispute → scroll/form → details/evidence → merchant submission. Missing App link has a Portal alternative. | A missing link proves neither ineligibility nor wrong role; current screens and early request acceptance are untested. A route's existence does not decide when an approved-payment dispute is warranted. |
| `UC4-MY-SHARED-REQUEST-001-C01`; `UC4-MY-SHARED-CLAIM-007` | Authorized Owner/Manager login is required to submit; the merchant completes/submits the form. | Form visibility/authenticated access untested. Does not require a fresh role interrogation or identical spoken reminder on every successful path. |
| `UC4-MY-GF-EVIDENCE-001-C01`; `UC4-MY-GF-CLAIM-009`, `UC4-MY-GF-CLAIM-010` | Prepared-food photo guidance; documented request may proceed without already having a photo with clear, complete supporting information. | No photo is not denial, exemption, proof of non-preparation or approval. Substitutes/final evidence policy remain **UNKNOWN**. |
| `UC4-MY-GF-EVIDENCE-001-C02`; `UC4-MY-GF-CLAIM-011` | Existing isolated-POC assumption treats cancellation before preparation as outside compensation. | Provisional scope assumption, not an individual eligibility determination. Do not infer preparation from a greeting, missing photo or status. |
| `UC4-MY-GF-THRESHOLD-001-C01`; `UC4-MY-GF-CLAIM-015`, `UC4-MY-GF-CLAIM-016` | Elapsed-day thresholds select recent/older conversation handling; older orders retain review guidance. | Not eligibility, a submission deadline or a payment date; operating timezone/effective-version conventions unconfirmed. |
| `UC4-MY-SHARED-DEADLINES-001-C01`; `UC4-MY-SHARED-CLAIM-008`, `UC4-MY-SHARED-CLAIM-010` | Older-order routing is distinct from the public 90-day enquiry reference. | UC4 applicability unresolved; no automatic rejection or indefinite submission right. |
| `UC4-MY-SHARED-DEADLINES-001-C02`; `UC4-MY-SHARED-CLAIM-008`, `UC4-MY-SHARED-CLAIM-009` | Indexed five-working-day investigation/response and at-least-three-business-day bank-credit/contact wording concerns different stages. | UC4 applicability **UNKNOWN**. Do not add these numbers to the approval period or invent a contact/escalation trigger for C. |
| `UC4-MY-SHARED-PORTAL-001-C01`; `UC4-MY-SHARED-CLAIM-011`, `UC4-MY-SHARED-CLAIM-012`, `UC4-MY-SHARED-CLAIM-013` | Documents payment-dispute destinations. Existing standard POC route is Help Centre → Search Bar → dispute → Report a payment dispute. | Alternate indexed menus are not newly accepted POC routes or proof of live UI. |
| `UC4-MY-GF-SPLIT-001-C01`; `UC4-MY-GF-CLAIM-001`, `UC4-MY-GF-CLAIM-002` | Eligible split-large-order cancellations have automatic reimbursement/no merchant action and weekly App-record updates in that specific FAQ. | **Not** a general no-action rule or weekly payment schedule for every cancelled/Auto approved order. TC-003 does not establish this split-order precondition. |
| `UC4-MY-SHARED-ELIGIBILITY-001-C01`; `UC4-MY-SHARED-CLAIM-006` | Cancellation reasons are examples subject to policy. | No exhaustive eligibility checklist or authority to declare this order eligible. |

H1 §§0,4–6 and KBC's “Remaining limits and sign-off conditions” preserve Problem
#1's closure: **17 article-level Top 1 observations** (15 Agent, two Search Only)
and 15 functional KB scenarios, one manually completed. These establish neither
formal policy approval, all-chunk coverage, actual backend status nor original
TC-003 completion.

## 3. Existing POC Job rules and the decision gap

**JOB30 / KB30:** `C:\Users\Nau\Downloads\Package-Naufal_2026-10-30_06-38-33.zip`,
SHA-256 `e92afdf8d41c5a348e65e18e0a1cad77f827d26dab5c6d3fe136d3439c1a8a1f`,
matches H1's last verified export. Job member
`nodeData/6ae43b6f90878ce305636d97`, JSON pointer
`/localizedData/0/config/instructions`, has instructions UTF-8 SHA-256
`d89731bb49f09959e0c9c35550cb0b9fa71fa03a88295916887672c20390d860`.
KB article/chunk content comes from its `knowledgeSource/*` / `knowledgeChunk/*`.

Compared by heading with [JOB29](../../flow/poc-correction-2026-10-29/01-job-instructions.txt),
39 of 42 sections are unchanged after whitespace normalization. The three changed
sections, read in full, contain the H1-approved additions for current-order LOB
recognition (`MERCHANT CONTEXT`), provisional preparation/packing explanations
(`KNOWLEDGE`) and all-at-once form observation (`REQUEST FOR COMPENSATION —
GRABMERCHANT APP`). This table cites **JOB30** throughout. It is a verified
historical POC reference, not evidence of today's served binding; its ZIP excludes
the Endpoint and `[MAIN]`.

| Exact Job section | Existing source-backed POC rule | OD-002 implication |
|---|---|---|
| `STATUS AND SUBMISSION TOGETHER` | Dual goals remain active; status first; wait for observed status; submission second **only if still needed**. Submit-only does not require status first. | **VERIFIED [POC]** ordering. “Only if needed” does not itself define every approved-status outcome. Preserve OD-008's negative control. |
| `GRABFOOD APP — COMPENSATION STATUS` | Separates missing order from visible order/blank status. For the latter, status check is complete and an already-requested submission continues without re-asking the goal. History/date recovery is only for a missing order. | **VERIFIED [POC]** support for A's visible-blank continuation, not evidence of individual eligibility or support for “no observation → claim.” |
| `OLDER CANCELLED ORDER`; `STATUS AND SUBMISSION TOGETHER` | Upfront explicit dual guidance goes directly to missing preferences; no unsolicited timeline/re-offer. General status/dual intent supplied in response to the older-order open question gets the fixed GF timeline, existing-photo reminder and guidance offer; wait for acceptance. | TC-003 E6 uses the upfront-dual profile. This limited OD-004 dependency can use the existing rule without settling all education triggers. |
| `FIXED LOB TIMELINES`; `FOLLOW-UP` | When a timeline is needed, preserve the exact GF approval-plus-payout sentence. Generic non-arrival follow-up explains the request option and offers cancelled-order guidance. | **CONFLICT in applicability:** applying that generic follow-up unchanged after a reported approval could lead to an unnecessary new request. No inspected explicit approved-but-unpaid exception resolves this. Proposed status-aware priority needs human review. |
| `REQUEST FOR COMPENSATION — GRABMERCHANT APP`; `POST-SUBMISSION RESPONSE CONSTRAINTS` | Article/scroll → observed form → details/evidence/self-submission → merchant submission report → conditional acknowledgement. Form visibility is not submission or eligibility. | **VERIFIED [POC]** procedural controls for A; no backend confirmation or promised result date. |
| `APP REQUEST LINK MISSING — PORTAL FALLBACK`; `FORM NOT VISIBLE — ROLE ACCESS AND ONE RETRY`; `CONNECTION AFTER FAILED FORM RETRY` | Missing link and missing form have different preconditions. Role confirmation, one retry offer, later retry consent, attempt/result, then any authorized person offer/consent are separate. | **VERIFIED [POC]** conditional recovery. A fallback/recovery cannot count as TC-003's normal full-App fixture merely because it is handled correctly. |
| `GROUNDING`; `OUT OF SCOPE`; `CLOSING` | No invented policy, outcome, callback or date. Cancelled-order payout concerns remain in scope. Normal close needs an appropriate finish signal. | B/C/D cannot use unknown status, the word payout, or a missing payment to manufacture a transfer. A conversation may finish while the financial outcome remains unverified. |

**Recommended priority, PROPOSED:** once a reported compensation status is
available, use that status and the remaining goal before applying generic
non-arrival/request-option wording. For approved/non-arrival, explain the supported
stages and acknowledge the limit of available order-specific payout information;
do not automatically issue a second request or borrow role-failure/out-of-scope
handoff authority. This is an acceptance proposal, not a Job patch or an approved
business escalation policy.

## 4. Four-branch decision and acceptance model

### Observation rules and shared prerequisites

Reuse `JRN-TC-003/M01–M10`; the letters below are this review's situation labels,
**not replacements for VAR suffixes**. A is the original target; B is
`VAR-TC-003-A`; C is `VAR-TC-003-B`; D is `VAR-TC-003-C` (PB §4).

Before selecting a branch, retain current-order identity/GrabFood, the merchant's
goal and already-known preferences (M01/M03; BR-001/005). Use the supported App
status route and required observations when navigation is needed (M04/M05;
BR-006/007/009). Do not ask for order IDs or credentials in chat; guiding the
merchant to their order/form does not authorize collecting its contents.

- **Visible order + explicitly blank/not-shown compensation status** is an
  observation supporting A under the POC rule. **No observation yet** belongs to D.
- **“Not compensated”** must be clarified if it could mean only “money has not
  arrived.” It is not assumed to be an exact documented screen label or rejection.
- **Missing order** invokes the existing conditional History/date/Confirm recovery
  (`VAR-TC-003-D`); observe the order/status afterward. Do not skip to submission.
- **Auto approved + bank non-receipt** is not inherently contradictory; it is C.
  Ambiguous order identity or contradictory *compensation-status reports* is D.
- A known pending/rejected/other unreviewed status is not silently folded into A
  or B. Its disposition remains **UNKNOWN** until its semantics are sourced.

If status is already clearly reported, reuse it for the behavioral decision. A run
that skips the target's required navigation may still lack original-target
coverage. Status comes from the merchant, not an Agent backend lookup.

### Source-backed decision table

| Situation / retained ID | Expected behavior and mandatory milestones | Forbidden actions | Source / approval status |
|---|---|---|---|
| **A — visible order, no compensation shown; wants review** / TC-003 target | M01/M03–M06: establish the actual visible-order/status observation and retain the requested review. M02 only for its applicable entry trigger. Then M07: relevant details → present App request link → article → scroll → observed form. M08: appropriate order details/evidence and merchant self-submission, one action/wait at a time. M09: obtain submission report and conditional acknowledgement. M10: further help/appropriate finish. Apply form-access constraints only where relevant. | No status absence ⇒ rejection/eligibility/mandatory claim; no submission before observations; no assumed preparation; no missing-photo denial; no forced History when order visible; no backend submission/approval claim. Do not repeat an already-clear submission request. | **VERIFIED [POC]** visible-blank continuation and procedural controls: JOB30 GF status/request sections; GF-005/012/013/014; SHARED-007; GF-009/010/011. **PROPOSED** normalized TC fixture and acceptance; eligibility meaning in PB's candidate “eligible” precondition remains **UNKNOWN** beyond the scoped review process. |
| **B — Auto approved; status inquiry only** / `VAR-TC-003-A` | M05/M06: confirm/reuse the compensation label on the relevant order and the status-only goal. Explain it as the merchant-reported approval indication; distinguish bank receipt. Do not initiate another request solely to obtain the same approval. M10: further help/finish only when appropriate. If the merchant still wants a dispute or reports unpaid funds, retain that concern and clarify/change branch. | No “money deposited,” guaranteed award/date, Agent-verified backend claim, automatic close, or universal ban on future disputes. Do not discard a previously pending submission goal without establishing that status confirmation now satisfies it. | **PROPOSED** narrow no-unnecessary-request decision: WB:D!G21(1), PB §4, PLAN P088–090. **VERIFIED [POC]** approval/receipt distinction: GF-005/007. Exact `Auto approved` semantics and universal duplicate/dispute rules **UNKNOWN**. |
| **C — Auto approved; payment not received** / `VAR-TC-003-B` | M05/M06: reuse approval report and explicit unpaid goal. Explain the distinct stages and qualified usual approval/regular-payout reference when timing is asked; do not restart approval time from today. Ask only a genuinely missing, relevant question about what the merchant sees or what remains unanswered. State that order-specific payout/bank detail is unavailable when it is. Continue only supported guidance, preserving the unresolved financial concern. M10 permits an explicit finish, not a claim of financial resolution. | No 1–2-day bank guarantee, accumulated 1–2 + 5 + 3 SLA, arbitrary wait/contact threshold, fabricated payout/adjustment screens, automatic duplicate claim, out-of-scope dismissal, automatic transfer, callback or promised investigation. Approval does not negate non-receipt. | **VERIFIED [POC]** stage distinction/grounding: GF-005/007; JOB30 fixed timeline/grounding/scope. **PROPOSED** status-aware priority over generic FOLLOW-UP. A concrete overdue-payment remedy, authorized payout-dispute submission or escalation remains **UNKNOWN / blocking** under OD-014. |
| **D — unclear/inconsistent status** / `VAR-TC-003-C` | M05 remains unresolved. Ask one targeted clarification and wait: first order visibility if unknown; otherwise the actual compensation label or the specific inconsistency. Use only supported navigation from confirmed location. Once clarified, select A/B/C or retain an unsupported-status limitation. If still unclear, defer status-conditioned submission, explain the limit and preserve the open goal. | No guessing approved/rejected, no treating “order visible” as “approved,” no treating “cannot read” as blank, no repeated generic intake, no forced submission/transfer/claimed success. No indefinite invented recovery ladder. | **VERIFIED [POC]** non-fabrication and observation rules: JOB30 grounding/GF status; GF-005. **PROPOSED** branch acceptance: PB §4, PLAN P094–096. Unresolved status meanings and further recovery **UNKNOWN**. |

The abbreviated claim references in that table expand to the exact IDs in §2.
Guidance consent, existing one-by-one pacing and separate observations remain
required. An action acknowledgement confirms only the action just requested.

### A's primary fixture and eligibility/access boundary

For human approval, retain **beyond-threshold, upfront dual request, App,
one-by-one, no loudspeaker** from E6. Make these previously implicit branch-driving
facts explicit: relevant order visible; compensation status blank/not shown;
review still requested; App request link present; article reached and scrolled;
form visible; merchant reports completing submission, then finishes.

The controlled POC fixture should establish an in-scope prepared-food order and
authorized Owner/Manager access as supplied merchant facts, not Agent inference
or authenticated validation. These are **PROPOSED fixture clarifications**, not
claims that E6 already contains them or new mandatory interview questions for all
callers. Reuse known facts; do not add a role retry to a form-visible happy path.
Universal spoken-role reminder timing stays under OD-010.

PB §4/PLAN P085's candidate says “eligible.” The inspected sources supply a
review/request procedure, provisional preparation scope and illustrative eligibility
examples, but no complete order-specific eligibility determination mechanism.
**Recommendation, PROPOSED:** evaluate A as *guidance to request review without
asserting entitlement*. A mandatory eligibility-certified submission target remains
**BLOCKED_SPEC** until an owner supplies that policy/check. Known contrary scope
facts must not be ignored, but absent evidence is not a newly invented denial rule.

Form access is an operational prerequisite to form completion, not proof of
eligibility. Article/scroll and visibility must be established before instructing
completion. If the link is missing, use `VAR-TC-003-E`'s accepted Portal fallback;
if the form is absent, use `VAR-TC-003-F`/JRN-TC-006's conditional role recovery.
Keep the agreed TC-006 declined-retry target intact.

### Two independent acceptance verdicts

These are **future adjudication criteria**, not test results. Before human adoption,
an unresolved OD-002 interpretation yields `BLOCKED_SPEC`/`NEEDS_REVIEW` for that
judgment; independently established violations must still be recorded.

| Branch | Behavior acceptance after scoped adoption | Original TC-003 submission coverage |
|---|---|---|
| A | Applicable M01–M10 and branch conditions met; correct entry-specific education, observation gates, pacing, access/evidence/self-submission and conditional acknowledgement; no unsupported claim. | **Potential PASS only with evidence of the full target fixture and stages.** A chosen branch, visible form, or submission instruction alone is insufficient. Correct decline/access recovery/Portal fallback does not prove the normal full-App target. |
| B | Correctly attribute approval to the displayed report; satisfy status-only goal without unnecessary new request; no bank claim; retain any changed/unresolved goal and finish appropriately. | **INCOMPLETE_COVERAGE** for original TC-003 even if behavior is PASS. The separately targeted B variant can have its own coverage PASS. |
| C | Correct stage explanation, preserved unpaid concern, justified clarification and explicit information limit; no invented remedy. Acceptance may cover this bounded explanatory outcome after review. | **INCOMPLETE_COVERAGE** for TC-003. Complete financial-resolution behavior remains **BLOCKED_SPEC** if the target requires an unsupported overdue-payment remedy; do not call explanatory success “payment resolved.” |
| D | Relevant clarification with wait; no fabricated status/submission; appropriate supported recovery or explicit unresolved outcome. | **INCOMPLETE_COVERAGE / NEEDS_REVIEW** while target stages are absent/uncertain. If later clarification genuinely establishes A and all target milestones occur, assess that observed continuation; D alone never supplies missing stages. |

Coverage and behavior are independent: fully traversing A with a false payment
promise can yield `FAIL / PASS`; handling B correctly can yield
`PASS / INCOMPLETE_COVERAGE`. Preserve fixture/requirement version, observed branch,
milestone evidence, merchant-reported versus independently confirmed facts, channel
and reviewer on both axes (BASELINE_MODEL, “Two independent verdicts”). Text-only
evidence cannot establish audible completeness for DF-017/F03.

## 5. Limited dependency disposition

Here **resolved** means sufficient for the stated internal POC sub-question,
**conditionally supported** means usable with explicit applicability/limits, and
**blocking** means the specified judgment/outcome cannot be authorized from the
available evidence. These dependency dispositions do not close the whole OD.

| Dependency | Disposition for OD-002 | Supported boundary and remaining approval |
|---|---|---|
| **OD-004 — education applicability** | **Conditionally supported**; the TC-003 upfront-dual versus older-open-question distinction is **resolved for the documented POC profile**. | JOB30 explicitly supplies both triggers (§3). For E6's upfront dual goal, do not add unsolicited education/re-offer; for an older-order open-question answer, education/photo reminder/offer precede accepted guidance. B/C factual timing answers do not force a new intake. Broader education table remains **CONFLICT**; preserve DF-018's owner-reported closure and its original/fix-note mismatch. |
| **OD-005 — timing and age** | **Conditionally supported**; approval ≠ bank receipt is **resolved [POC]**. A precise payment deadline or overdue trigger is **blocking**. | GF-007 plus the fixed Job sentence supports usual business-day approval after order made, then regular payout. Routing uses cancellation age/elapsed-day thresholds, not that approval interval. TC-003's beyond-threshold fixture does not require inventing timezone/boundary arithmetic. Do not reinterpret “two weeks” as proof of unpaid status or eligibility; exact date conventions/formal timing policy remain **UNKNOWN/CONFLICT**. |
| **OD-010 — form and role** | **Conditionally supported** for A; not a prerequisite to B/C/D explanation. | SHARED-007 and Job recovery provide authorized role, article/scroll, visibility, one separately accepted retry and outcome. Universal successful-path spoken reminder, unavailable-role disposition and authenticated UI remain **UNKNOWN**. They do not justify a blanket block on navigation or a fabricated role check. A known access problem blocks form completion until supported recovery succeeds. |
| **OD-014 — policy/UI unknowns** | **Blocking** for formal status/duplicate policy, authenticated UI assurance and C's end-to-end remedy; **conditionally supported** for bounded internal POC guidance. | No supplied policy establishes every status meaning, approved-payment dispute trigger, payout-screen route, escalation SLA, early acceptance or definitive individual eligibility. Preserve the scoped KB assumptions and test-fixture observations. A hypothetical screen or successful retrieval cannot resolve this dependency. |

OD-007's conditional History/date issue and OD-013's separate voice evidence remain
existing adjacent items, not expanded reviews. No dependency change reopens
OD-001/003/008/015 or the scoped Problem #1 closure.

## 6. Shared impact and proposed regression scope

**Directly documented** means the cited source explicitly supplies the association
or shared journey segment. **Plausible regression impact** means the same
requirement/boundary could be affected. **Unverified** means the status semantics,
failure, family mapping or common cause is not established. No selection is a
new failure report or permission to execute tests.

### Existing journeys and requirement boundaries

| Existing journey / variant | Association and confidence | Proposed regression reason / limit |
|---|---|---|
| `JRN-TC-003`; `VAR-TC-003-A/B/C` | **Direct:** WB:S!A6:F6, WB:D!D21/G21, PB §4; primary OD-002 subject. | Preserve A target plus B/C/D independent behavior/coverage. BR-001/003/006/007/009/010/012/013/014/020. |
| `VAR-TC-003-D/E/F` | **Direct register relationship** to JRN-TC-003; new failures unverified. | Order missing versus visible blank; absent link versus absent form; accepted fallback/retry must not bypass status/visibility or become original happy-path coverage. |
| `JRN-TC-005` / TC-005 | **Direct shared segment:** WB:S!D8:F8 documents status then submission, with no-status answer. **Plausible** changed-rule regression. | All-at-once must stop at status and form observations; retain pending submission. BR-006/007/009/010/012/013. No direct DF-017 association. |
| `JRN-TC-006`, `JRN-TC-007`, `JRN-TC-008` | **Direct shared segments:** WB:S!D9:F11 contains status before form recovery, stuck-step continuation or App-link fallback. **Plausible** upstream gate impact. | Ensure legitimate A reaches each distinct target; B/C/D must not be forced into a form to satisfy that target. Preserve TC-006 decline primary, TC-007's unresolved stuck fixture and TC-008's accepted Portal fallback. BR-007/009/010/012/014/015/019. |
| `JRN-TC-027`, `JRN-TC-029`; `VAR-TC-027-B` | **Direct shared structure:** WB:S!D16:F16,D18:F18; existing pilot's approved/compensated variant. **Plausible** cross-LOB status/goal and coverage impact. | Retain OD-003's App-to-Portal transition and GM-specific route/timing. KB `UC4-MY-GM-STATUS-001-C01` claims `UC4-MY-GM-CLAIM-003` and `UC4-MY-GM-CLAIM-004`, and `UC4-MY-GM-TIMING-001-C01` claim `UC4-MY-GM-CLAIM-006` support the GM boundaries. Exact GF `Auto approved` semantics applied to GM remain **unverified**, not approved by analogy. BR-008/009/011/013/018. |
| `JRN-TC-009`; `VAR-TC-027-G` | **Direct existing submit-only boundary**, reaffirmed by OD-008 / Job. **Plausible negative-control impact** if status-first is overgeneralized. | No new compulsory status detour for submit-only. Preserve Portal submission-only TC-009 and GM App submit-only support. |
| `JRN-TC-002/004/026/028`; `VAR-TC-027-F` | **Direct education/non-arrival or status-only descriptions** in inventory; **plausible** clarification/timing/finish impact. | Do not force submission into education-only, declined-guidance or direct navigation-only cases. Preserve the narrow GM status-only intake exception; do not extend it to GF/combined journeys by analogy. BR-001/003/014. |
| `JRN-TC-001/025`; `JRN-TC-010` | Shared timing or scope **negative controls**, not direct status-decision failures. | GF/GM recent education retains its own triggers. TC-010 remains genuine out-of-scope handoff; cancelled-order non-receipt must not be misclassified as unrelated payout. BR-003/015/016. |

Slash-separated journey/claim numbers retain their full prefix. The table reuses
existing inventory and pilot records; it does not expand the other 12 journey
specifications or redefine their primary classifications.

### Existing business-process families

Use the unchanged v0.3 [BP register and TC matrix](TC_CLASSIFICATION_MATRIX.md#candidate-shared-business-process-families-bp).
These families/memberships remain **PROPOSED taxonomy**, even though their presence
in the source pack is directly verified. This impact overlay adds no memberships.

| Existing BP / exact family name | Existing mapped journeys relevant here | OD-002 relationship and regression confidence |
|---|---|---|
| **BP-04 — Compensation status and conditional submission decision** | Primary TC-003/005/027/029; secondary TC-007. | **Direct core process association** through BR-006/007/008/009. Status/goal branching and separate coverage are primary review scope. Wider regression effect is **plausible**, not a reported failure of all members. |
| **BP-05 — Request/form submission and role access** | Primary TC-006/009; secondary/conditional TC-003/005/007/008/027/029 in the existing TC matrix. | **Direct downstream process association** for A; BR-010/011/012/013. **Plausible** reachability/overapplication impact. TC-009 is the agreed submit-only negative control, not an added status-first case. |
| **BP-06 — Navigation recovery, missing-link fallback and platform transition** | Primary TC-007/008; conditional TC-003/006/027. | **Direct conditional process association** for distinguishing missing order/status/link/form. **Plausible** BR-005/006/007/008/010/019 impact; preserve TC-027's agreed readiness transition. |
| **BP-02 — Recent follow-up and guidance declined** | TC-002/026; BP-01 prerequisite. | **Plausible shared follow-up impact** when qualifying generic non-arrival advice. Original declined-guidance targets remain intact; no claim they reported Auto approved or need new expanded variants. |
| **BP-03 — Older-order inquiry and education** | TC-004/028. | **Plausible** OD-004/005 timing/intent-trigger impact; preserve information-only targets. This does not move TC-003 into BP-03 merely because conditional education can apply. |
| **BP-07 — In-scope recovery boundary, out-of-scope handling and consented handoff** | Primary TC-010; secondary TC-009; conditional TC-006/027. | **Plausible negative-control/conditional impact** on BR-014/015/016. Unpaid compensation is not automatically out of scope. B/C/D ordinary finishing does not create BP-07 membership for TC-003 or authorize transfer. |
| **BP-01 — Recent cancellation education** | TC-001/025; prerequisite for TC-002/026. | **Plausible timing/education negative control** if shared wording changes later. A direct OD-002 status-branch failure association is **unverified**. |

BR-017 remains `QA_EVIDENCE` and BR-020 `QA_SEMANTIC_ACCEPTANCE` under v0.3;
they govern evidence/adjudication, not merchant-facing lines or extra process
families. No BP or DG is treated as a demonstrated implementation root cause.

### Existing defect groups and atomic evidence

| Group | Direct evidence versus plausible impact |
|---|---|
| **DG-006 — status-conditioned submission/fallback** | **Direct:** DF-017/F01 (policy/script concern) and F02 (positive adaptive guidance), linked to TC-003. DF-009/F04–F05 reports a further-help question after no status, then submission continuation after an explicit request on **TC-007**. Whether that earlier question was premature needs evidence; this is not another DF-017 association. DF-008/016 memberships retain their own observations/statuses. Shared-rule regressions are **plausible**, common cause **unverified**. |
| **DG-004 — status route/observations/pacing** | **Direct:** DF-017/F02 positive adaptation; DF-004/F01 reports date-instruction omission on TC-003. Applicability of that omission depends on the missing-order condition. Other route reports/controls are **plausible** regression scope; status policy does not prove a navigation failure. |
| **DG-002 — context and pending intent** | TC-003's DF-003/F03 is directly recorded but concerns the “phone issue” framing; it does not prove an approved-status error. Preserving dual goals and clarifying status versus payment has **plausible** BR-001 impact. |
| **DG-003 — education/timing** | Shared BR-003 impact is **plausible**. DF-018 directly belongs to **TC-004**, even though G22 compares TC003 scripts. Preserve DF-014/018 owner-reported resolutions; no blanket reopening. |
| **DG-005 — role/access** | TC-003's DF-003/F01 and DF-004/F02 directly report role-advice concerns; their universal-reminder applicability remains OD-010. A's downstream form stages have **plausible** impact; B/C/D do not automatically require form-role advice. |
| **DG-007 — unresolved goals/consent/closing** | DF-003/F02–F03 is direct TC-003 recovery/offer evidence. Premature closing of C/D and inappropriate handoff have **plausible** shared impact, not a proven recurring cause. |
| **DG-009 — voice continuity** | **Direct but separate:** DF-017/F03 ↔ TC-003 ↔ BR-017. Voice regression is relevant to audible observation/education; linkage of barge-in to the status decision's cause is **unverified**. No barge-in setting change follows. |
| **DG-001 / DG-008** | No direct OD-002 defect finding established. Greeting and GM once-only partial notice are boundary controls if adjacent guidance changes later; a shared failure or causal dependency is **unverified**. |

For a future authorized regression, select A/B/C/D first, then the existing
one-by-one/all-at-once, recovery and submit-only controls above. Record which
boundary motivated each selection. Preserve original fixtures and known closures;
use OD-015 governance for scope, reviewers and separate execution authorization.
Neither retrieval smoke results nor DF-016's positive TC-029 comment replaces this
coverage. No repeat count or new scenario is prescribed in this round.

## 7. Review frontier and adoption limits

| Adoption boundary | Decision-ready disposition |
|---|---|
| Existing POC controls | Retain status observation, goal retention, approval/receipt distinction, supported request/access sequencing and bounded education triggers as **VERIFIED [POC]**. They still do not certify official policy or live UI. |
| New internal OD-002 interpretation | Q1–Q4 below are **PROPOSED** and can be adopted provisionally by the project-side review process. They permit bounded review guidance/explanation, not an award decision or payment guarantee. |
| Formal business-policy approval | Still required for authoritative status meanings, universal duplicate/dispute rules, individual eligibility certification and an approved-but-unpaid remedy/trigger. These remain **UNKNOWN**, with the generic-follow-up priority **CONFLICT** explicitly exposed. |
| Authenticated UI / backend assurance | Still requires independent evidence. Neither a fixture assertion nor KB retrieval establishes live form acceptance, approval, payout or bank receipt. |

The agreed root is the four preserved internal decisions and the independent
behavior/coverage model. The current frontier is the following OD-002 choices.
Each **yes** accepts only its recommendation for the internal POC; unanswered
questions remain **PROPOSED**. No answer here grants formal Grab policy approval.

❓ **Q1 — Review-request target:** May A explicitly use the visible-blank,
review-requested, in-scope/authorized-access fixture in §4, with eligibility and
backend acceptance unverified, rather than claim the Agent certified eligibility?

➡️ **Recommended: yes.** Retain all App status/submission milestones and keep
eligible-award determination outside this bounded acceptance claim. Record the
departure from PB's candidate “eligible” precondition explicitly.

---

❓ **Q2 — Approved/status-only:** May B treat the merchant's `Auto approved`
observation as an approval indication for the limited status-only response and
avoid an unnecessary new request, while preserving any unresolved dispute goal?

➡️ **Recommended: yes, provisionally.** Attribute the status to the merchant's
screen; do not claim bank receipt or a universal prohibition on later disputes.
Require separate business confirmation of status/duplicate-policy semantics.

---

❓ **Q3 — Approved/unpaid boundary:** May C's internal POC acceptance end at
correct stage explanation, relevant clarification and an explicit information
limit, with status-aware handling taking precedence over generic non-arrival
request guidance once approval is reported?

➡️ **Recommended: yes, with the unresolved financial outcome recorded.** No new
claim, payout route or escalation is authorized by this choice. A full remedy
requires a separate business policy decision and later review; it cannot receive
an end-to-end resolution PASS now.

---

❓ **Q4 — Unclear status:** May D defer status-conditioned submission until the
merchant's observation supports a branch, with one relevant clarification at a
time and only the existing supported navigation recovery?

➡️ **Recommended: yes.** Keep no-observation distinct from an observed blank;
neither confusion nor approval-plus-non-receipt automatically authorizes a claim,
rejection or transfer.

### Later decisions and owner evidence

The next frontier depends on these answers. Business/policy owners still need to
supply the canonical status meanings, any duplicate/approved-payment dispute
exception, the eligibility rule if an eligibility-certified target is required,
and any overdue-payout check/contact/escalation route with its trigger and timing.
UI owners must validate current authenticated routes/access independently.
OD-004/005/010 remain separately scoped review work; this document does not settle
their complete trigger, date or reminder policies.

On adoption, record the selected question/options, named decision-maker, date,
internal POC scope, sources, affected JRN/BR/VAR version, unresolved policy/UI limits
and superseded candidate wording in OPEN_DECISIONS. The existing agreements are
already preserved; the OD-002 approver/date remain **unassigned**. Implementation,
new executions, official acceptance and release are separate later decisions.

## 8. Version and verification record

| Version / date | Change and authority |
|---|---|
| `P2-DRAFT-0.1` / 2026-11-02 | Initial five local documents preserved byte-for-byte in the local-draft history ZIP. |
| `P2-DRAFT-0.2` / 2026-11-02 | Supplied structural pack introduced BP-01–BP-07, requirement kinds and BR-led regression selection; preserved unchanged. |
| `P2-ENG-DECISIONS-0.3` / 2026-11-02 | Supplied eight-document engineering pack read and integrated byte-identically before focused amendments. Preserves four limited agreements; classification and defect matrix are identical to the supplied v0.2 members. Immutable source archive retained. |
| `OD002-REVIEW-0.1` / 2026-11-02 | Additive A/B/C/D review, limited dependencies, independent acceptance/coverage, existing-family impact and unanswered frontier. Focused cross-reference/current-status corrections; four agreements preserved; new interpretations **PROPOSED**. No global acceptance-version freeze. |

**Completed offline on 2026-11-02 — documentation/source audit only:**

- All **76 relative links/heading anchors** across nine Problem #2 documents and
  the glossary resolve; Markdown table structure and stable-ID references pass.
- **15 original TC inventory/direct-DF mappings, 18 historical DF records and
  49 atomic records** are retained; nine group memberships/direct-TC unions agree.
  All **seven BP definitions and 15 TC-family memberships** match the supplied
  v0.3 pack. Three pilots, 18 existing variants, 20 BRs and 15 OD IDs are retained.
- **12 claim-table rows** match KB30's exact chunk/claim associations. All 17
  article metadata and 20 chunk text/claim records match the prior KB source;
  39 Job sections match after whitespace normalization, and the three changed
  sections contain the handover-documented additions. **15 source/archive/member
  or instruction fingerprints** checked, including the original workbook.
- The five original local drafts are preserved byte-for-byte in the v0.1 snapshot;
  the supplied v0.2/v0.3 archives and v0.3 four-decision record are unchanged.
  **160 other pre-existing repository files and 467 historical report files** are
  unchanged. The previous glossary is an unchanged prefix with appended terms.
- `git diff --check` passed. **Zero new Agent/runner test executions, live requests,
  saved-evidence regrades or new business approvals.** These checks verify source
  accounting and documentation, not runtime behavior or a business baseline.

Read-only projections, the audit script/result and source comparisons are retained
at `C:\Users\Nau\AppData\Local\Temp\opencode\uc4-od002-review-qfm819b3`:
`preservation-before.json`, `v03/`, `v01-to-v03.diff`, `job30.txt`,
`job29-to-job30.diff`, `kb30-projection.json`, `audit-od002-documents.py` and
`documentation-verification.json`. The original archives and cited hashes remain
the primary provenance; these are offline review artifacts, not conversation runs.
