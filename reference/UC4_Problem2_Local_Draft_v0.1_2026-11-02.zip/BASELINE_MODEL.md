# Problem #2 — acceptance and baseline model

**Version:** `P2-DRAFT-0.1` · **2026-11-02** · **State:** PROPOSED, awaiting human review.

[Classification](TC_CLASSIFICATION_MATRIX.md) · [Pilots](JOURNEY_PILOT.md) ·
[Defect impact](DEFECT_GROUP_IMPACT_MATRIX.md) · [Decisions](OPEN_DECISIONS.md)

This is a documentation model, not a runner schema change or an executed Agent
baseline. All 15 official TCs and proposed variants are **NOT_RUN in this work**.
Existing KB tests remain separate evidence with their original identifiers.

## Sources and authority

Locators below are the citation keys used throughout these five documents.
`WB:S!D9` means the workbook's **Scenarios** sheet, cell D9;
`WB:D!G12` means **Defect Log**, cell G12. A range includes both endpoints.
`PLAN §6/P101` identifies the DOCX section and the 101st `word/document.xml`
paragraph, counting paragraphs inside tables. `PB §4` identifies a Markdown section.

| Key | Original source and precise location | Authority / limits |
|---|---|---|
| PLAN | [Original decision bundle](../../reference/UC4_Problem2_Original_Decision_Documents_2026-10-23.zip), member `UC4_Problem2_Benchmark_Journey_Decision_and_Action_Plan_2026-10-23.docx` | October 23 agreed process direction; individual conversions/approvals remain outstanding. §§3–9 and §§10–13 govern this draft. |
| PB | Same bundle, member `UC4_Problem2_Benchmark_Journey_Implementation_Playbook_2026-10-23.md` | v1.0; existing BR/JRN/VAR definitions, approval labels, templates and pilot proposals. |
| WB | `C:\Users\Nau\Downloads\UC4_Knowledge_Implementation_2026-10-24.zip` → `UC4_Knowledge_Implementation/Provenance/Originals/03_Business_and_Test_Context/Grab_UC4_Benchmark_Test_Scenarios_Feedback (3).xlsx` | Immutable official test reference, not independent policy authority. Scenarios rows 4–18; Defect Log rows 5–22. IDs include original cached formula results; no recalculation. |
| H1 | `C:\Users\Nau\Downloads\UC4_Problem1_KB_v03_LLM_Handover_2026-10-30.md` | §§0, 4–6: closed isolated-POC scope, 17 article-level retrieval checks; 15 functional scenarios, one completed manually. §§3, 8: authority and next workstream. |
| KBC | `C:\Users\Nau\Downloads\UC4_KB_v03_Retrieval_Validation_Closeout_2026-10-30.md` | “Executive conclusion,” “Article-level evidence ledger,” “Remaining limits and sign-off conditions”: article-level smoke coverage, not all chunks, UI validation or formal Grab approval. |
| KB | [October 29 export](../../flow/Package-Naufal_2026-10-29_06-47-07.zip), `knowledgeSource/*` metadata and joined `knowledgeChunk/*` text | All 17 v0.3.0 articles / 20 chunks read. Cite logical article/chunk/claim IDs below. All have `adoption=provisional_poc`, `formal_approval=pending`; H1 §2 reports KB content unchanged in its October 30 audit. |
| KC | [KB coverage and decisions](../KB_TEST_COVERAGE.md), “Source inventory and authority,” “Suite design and POC decisions,” “Known coverage limits” | Supporting article inventory and POC constraints. Its earlier execution narrative is historical; H1 supplies the later closure scope. |
| POC | [Approved October 29 POC policy](../../flow/UC4-PORTAL-DIAGNOSIS-2026-10-29.md#approved-poc-policy) | Explicit GrabMart status-only navigation bypasses age/loudspeaker intake in voice and text; excludes combined status/submission, eligibility and timing. Internal POC decision, not Grab policy approval. |
| JOB29 | [Approved October 29 Job text](../../flow/poc-correction-2026-10-29/01-job-instructions.txt), cited by heading | Historical controlled-language/procedural reference. H1 §§2, 5 reports later application of three scoped additions. It is not proof of the currently served configuration. |

### Fingerprints

| Artifact | SHA-256 |
|---|---|
| Decision bundle | `5fc1ac6e177af2706fa6deb694fa11bb892a7bbee0b13778feeb1aa640802349` |
| PLAN DOCX member | `0fce8536941c45bcae7bae7a65ac1ec1a2959c805c53c2b4f3af674e272d1326` |
| PB Markdown member | `067d1f8680bb5de9f55dcb6ecf57c74bfb0f8ccc3724bc7db7f6dd9f354cc940` |
| WB containing ZIP | `70af7a87677a5e4b0dd9a794513fa1640eb21eb2ef8fe9748a05b1500b2c5f4b` |
| WB XLSX member | `12e17ad51b6ee2053a4e2c56d3ae8b5ff56f544a6f9a1487dd274c05af5c797e` |
| H1 | `42d47a69d9f0d392e17dea60d033f60c0ae6e10e616f129fd8c091b9a67408a1` |
| KBC | `6907060c34d3d9207efbbf306d4974f0479a4dcd4e2c74795f8fed203b1b2c47` |
| KB export | `015b714019081f458b2d8f28047b68761e47c7fe6e7ddab68670ecb0684be6af` |
| JOB29 | `9136fd79342f9053b545a64619d666f29ffd0fa95f6f75e02a875fca9e5ac535` |

PB §0's hierarchy is adopted as **VERIFIED process direction**: applicable
approved Grab project policy; validated supplementary official sources for gaps;
explicitly reviewed project rules. WB examples are test evidence. The supplied KB
has POC adoption, not formal Grab approval. No higher-authority policy is invented
to settle a conflict. PLAN and PB reuse `D-*` numbers differently: always cite
`PLAN D-05` or `PB D-05`, never a bare decision number.

## Interpretation labels and identity rules

Use PB §9 exactly:

- **VERIFIED:** source-backed and reviewed/approved for the stated UC4 scope.
  `VERIFIED [POC]` does not mean formally approved Grab policy.
- **PROPOSED:** candidate interpretation/mapping awaiting review; not binding.
- **UNKNOWN:** necessary policy, UI, evidence or permitted recovery not established.
- **CONFLICT:** incompatible source statements retained together for resolution.

Reading a cell accurately is an **extraction fact**, not a VERIFIED business
interpretation. All new requirement formulations, classifications, groups and
journey mappings below are **PROPOSED** unless explicitly labeled otherwise.
Existing POC adoption and formal approval are separate fields.

Preserve `TC-###`, `DF-###`, `JRN-TC-###`, `BR-###` and `VAR-TC-###-A/B` from PB §2.
**BR means business requirement.** A branch uses its JRN-local name and, where
materially different, a VAR ID. Keep PB's `VAR-TC-003-A/B/C` meanings unchanged.
Internal groups use `DG-###`; atomic findings use `DF-###/F01`. New group and
decision IDs (`OD-###`) are proposed internal identifiers, not Grab-issued IDs.
Definitions are in the [glossary](../../GLOSSARY.md#benchmark-journey-analysis).

## Candidate business requirement register

Each row is **PROPOSED for Problem #2 acceptance**, source-supported within the
stated conditions; linked conflicts remain open. No row grants formal policy
approval. Citations to JOB29 describe the existing POC contract, not a new prompt.

| ID | Applicable requirement / prohibition | Provenance and unresolved dependency |
|---|---|---|
| BR-001 | Establish and retain the current order's business line and merchant goal. Clarify genuinely missing/ambiguous facts; do not repeat clear answers or infer GrabFood merely from “food.” | PB D-02/D-03; JOB29 “MERCHANT CONTEXT,” “CURRENT ORDER LOB CORRECTION,” “OLDER CANCELLED ORDER”; WB:S!D5:D12. OD-004. |
| BR-002 | For age-dependent journeys, use deterministic age/weekday classification; a threshold selects guidance, not eligibility, rejection or a payment deadline. Record age origin/date assumptions. | H1 §§1,3,6; KB `UC4-MY-GF-THRESHOLD-001-C01` claims GF-015/016; `UC4-MY-GM-THRESHOLD-001-C01` claim GM-014. POC status-only exception; OD-004/005. |
| BR-003 | Give applicable education when its trigger applies: usual approval 1–2 business days GF / 3–5 GM after order made, then next regular payout, subject to policy. Distinguish approval from bank receipt. Do not universally insert education before every direct request. | KB `UC4-MY-GF-TIMING-001-C01` claim GF-007; GM equivalent claim GM-006; JOB29 “FIXED LOB TIMELINES,” “OLDER CANCELLED ORDER”; WB:S!E7,E16,E18; OD-004/005. |
| BR-004 | Deliver the applicable opening/recording disclosure once; respond to supplied intent without claiming unestablished preparation/packing. Entry/channel and safety priority determine applicability. | POC approved policy; JOB29 “GREETING OWNERSHIP”; WB:S!E4:E18; OD-011. |
| BR-005 | Collect only missing supported platform, guidance-style and loudspeaker preferences; retain them across recovery and platform changes. A loudspeaker refusal is not refusal of guidance. | WB:S!D6:F6,D8:F12,D16:F18; JOB29 “GUIDANCE PREFERENCES”; POC exception; OD-003/004. |
| BR-006 | One-by-one: one current navigation action and a wait; all-at-once: group actions only until the next required business observation. Status, form visibility and reported submission are separate observations. | PB §§3,6; JOB29 “ALL-AT-ONCE DECISION SEGMENTS,” “GRABMART PORTAL STATUS — ONE-BY-ONE SEGMENTATION”; H1 §5. OD-007. |
| BR-007 | GF status: App → Orders → Cancelled → relevant order/status. Use History → Date selector → Confirm only for an order missing from the Cancelled list; observe visibility before opening it. | KB `UC4-MY-GF-STATUS-001-C01` claim GF-005; JOB29 “GRABFOOD APP — COMPENSATION STATUS”; WB:S!E6,E9,E10; OD-007. History detail is a POC procedural reference, not independently validated UI. |
| BR-008 | GM status: computer Portal → Finance → Transactions → period/store → Category → Compensation for cancelled orders → observed result. Distinguish missing order from visible order with no compensation status; explain App-to-Portal transition. | KB `UC4-MY-GM-STATUS-001-C01` claims GM-003/004; JOB29 “GRABMART GUIDANCE RULES,” “GRABMART PORTAL — COMPENSATION STATUS”; WB:S!E16,F16,E18,F18; OD-003. |
| BR-009 | For a status-and-submission goal, observe status before deciding whether submission remains needed; retain the pending request. Never fabricate status or equate approval with bank receipt. Already-approved/no-duplicate handling needs the specific branch review. | PB §4/D-05/D-10; PLAN §5; WB:D!G21; KB GF/GM status articles; JOB29 “STATUS AND SUBMISSION TOGETHER”; OD-002/004. Submit-only is a distinct journey. |
| BR-010 | App request entry: relevant order → present Request for compensation link → Report a payment dispute → scroll → observe form. Established missing App link permits offering Portal fallback; wait for acceptance, preserve preferences. Missing link proves neither ineligibility nor wrong role. | KB `UC4-MY-GF-SUBMIT-001-C01` claims GF-012/013/014; GM equivalent claims GM-012/013; JOB29 “APP REQUEST LINK MISSING — PORTAL FALLBACK”; WB:S!D11:E11; OD-010. |
| BR-011 | Supported POC Portal submission starts at Help Centre → Search Bar/search dispute → Report a payment dispute → scroll → observe form. No fabricated Portal Request for compensation control. | KB `UC4-MY-SHARED-PORTAL-001-C01` claims SHARED-011/012/013; KC “Suite design”; JOB29 “PORTAL SUBMISSION — SEARCH BAR ROUTE.” Other KB routes are references, not accepted standard POC variants; OD-014. |
| BR-012 | Form access: article/scroll observation precedes role recovery. Owner/Manager authorization is required to submit; missing form is not proof of wrong role. Confirm unknown access, offer one retry, wait for acceptance, attempt once, then observe success/failure. | KB `UC4-MY-SHARED-REQUEST-001-C01` claim SHARED-007; WB:S!D9:F9,D12:F12; JOB29 “FORM NOT VISIBLE — ROLE ACCESS AND ONE RETRY”; OD-001/010. Universal spoken-role reminder remains undecided. |
| BR-013 | After observed form visibility, guide order details, LOB-appropriate evidence and merchant self-submission; obtain the merchant's submission report before acknowledgement. No photo does not prove no preparation/packing or deny access. Approval remains conditional; backend receipt is unverified. | KB GF/GM evidence C01/C02 (GF-009/010/011; GM-008/009/010), SHARED-REQUEST; JOB29 “POST-SUBMISSION RESPONSE CONSTRAINTS”; H1 §6; OD-005/014. |
| BR-014 | Respect declined guidance/retry, retain unresolved intent, offer further help as applicable and close only on an appropriate finish signal. A missing screen/access issue is not a resolved claim; avoid repeated education/offers without a new need. | WB:S!D5,D7,D9,D15,D17; PB §§3,9; JOB29 “GUIDANCE,” “CLOSING”; OD-009. Transport disconnection cannot be attributed to the Agent without evidence. |
| BR-015 | Authorized recovery handoff requires a spoken offer and separate explicit consent; retry consent is not transfer consent. Preserve correct mock-transfer/terminal ownership and avoid repeated offers or false real-connection claims. | WB:S!D12:F13; JOB29 “CONTROLLED FLOW CONTENT,” “CONNECTION AFTER FAILED FORM RETRY,” “GRABMART PORTAL UNAVAILABLE — SUPPORT OFFER”; OD-009/010. |
| BR-016 | Clarify genuinely ambiguous scope; for clearly unrelated issues explain scope and offer supported handoff, then wait for consent. “Payout” alone is not out of scope. | WB:S!D13:F13; JOB29 “OUT OF SCOPE”; OD-009. |
| BR-017 | Assess audible and displayed responses separately in voice tests; record missing response, interruption and timing evidence. Do not infer ASR loss, barge-in cause or a response-time SLA without evidence. | PB §6; PLAN §4/P075; WB:D!G17,G21; OD-013. A numeric latency acceptance threshold is UNKNOWN. |
| BR-018 | Preserve the currently adopted GM partial-compensation notice once before applicable navigation; do not promise a fixed amount/full award. Its certainty and disagreement with sample full-or-partial wording require business review. | KB `UC4-MY-GM-PERISHABLE-001-C01` claim GM-011; JOB29 “GRABMART GUIDANCE RULES”; H1 §6 item 2; WB:S!E16,E18; OD-006. |
| BR-019 | On a first ordinary stuck navigation action, repeat that current action once with supported context, wait and continue only after success. Specific missing-link, missing-order and missing-form recovery takes precedence; no premature transfer. | WB:S!D10,F10; JOB29 “GUIDANCE TURN BEHAVIOR”; OD-007/010. Further unsupported recovery is UNKNOWN. |
| BR-020 | Assess semantic meaning/process rather than sample wording. Apply literal matching only to a separately identified, applicable controlled-language requirement; preserve original severity separately from internal assessment. | VERIFIED process direction: PB D-03/D-06, §§3,6; PLAN §§1,4. The concrete wording register still needs OD-011 review. |

Claim suffixes above are abbreviated only in prose: e.g. GF-007 is
`UC4-MY-GF-CLAIM-007`, and SHARED-007 is `UC4-MY-SHARED-CLAIM-007`.
Elsewhere, `KB GF-STATUS` means article `UC4-MY-GF-STATUS-001`, and
`KB GF-STATUS-C01` means chunk `UC4-MY-GF-STATUS-001-C01`; the same expansion
applies to GM and SHARED article/chunk names. Slash-separated IDs retain the
prefix, e.g. `BR-001/002` means BR-001 and BR-002.

### Controlled language boundary

JOB29 explicitly designates exact opening/recording text, LOB timeline sentences,
GM partial notice/Portal redirect, and particular scope/person-offer text;
“CONTROLLED FLOW CONTENT” assigns terminal utterances to the Flow. These are
**source-backed POC controls**, not permission to make every WB sentence literal.
The inventory must record exact source section/text/hash, trigger and approval
scope under OD-011 before becoming a Problem #2 literal oracle. Official UI labels
retain their identity; natural instructional phrasing remains flexible. WB's
generic greeting preparation claim and “Glad your issue is solved” are not
independent evidence of preparation or resolution.

## Minimal records

These are proposed documentation records, implementable later in any suitable
format. Preserve source values and allow nulls; do not fill gaps with inferred facts.

| Record | Minimum fields |
|---|---|
| Source | `source_id`, original path/archive/member, SHA-256, version/date, locator, authority, adoption/formal-approval scope, supersedes link where explicit |
| Requirement | `requirement_id`, version, conditional rule/prohibition, semantic or controlled-text mode, source refs, interpretation label, approval scope, reviewer/date, open decision IDs |
| Journey / variant | JRN and original TC; version/state; goal; initial facts including unknowns; target branch; VAR and parent JRN; M01… milestones with conditions/BRs; dependency edges; branch decisions; permitted variation; prohibitions; source refs and reviewer |
| Defect / finding / group | Original DF and immutable cells/status/severity; child finding and observation; proposed triage; group memberships with BR rationale; directly reported TC separately from plausible impacts; confidence, status history, root-cause evidence, closure coverage |
| Configuration baseline | `configuration_id`, captured timestamp; Flow/Job/Agent/KB/Tool/Code versions or stable refs plus content hashes; model/settings; runner/scenario versions; effective Endpoint-to-revision binding evidence and gaps; no credentials |
| Execution evidence | `execution_id`, actual run/batch IDs, TC/VAR target, fresh-conversation identity, channel/language, fixture/version, capture time/timezone, configuration ID, transcript/audio/trace paths and hashes, attempted/skipped turns, merchant-reported versus system-confirmed observations |
| Assessment | `assessment_id`, execution ID, acceptance/JRN/BR versions, reviewer/date, observed branch, milestone observation and compliance separately, **behavior_verdict**, **coverage_verdict**, reasons/BR/finding links, evidence locators; original automated result retained separately |
| Change / comparison | `change_id`, approved diff/baseline IDs, changed BRs/dependencies; before/after executions and assessment IDs, comparable conditions and confounders; added/removed requirements; regression selection with inclusion reasons and outcomes |

Required relationships are many-to-many: `BR ↔ JRN/VAR ↔ TC ↔ finding ↔ DG`,
then `finding/BR ↔ change ↔ evidence/assessment`. A group can contain findings
with different historical statuses. Group membership never supplies a direct
DF–TC association, a common cause, remediation or a pass.

### Two independent verdicts

Use PB's vocabulary with an explicit axis:

| Verdict | Agent behavior axis | Intended-branch coverage axis |
|---|---|---|
| PASS | Applicable approved requirements satisfied on the observed branch. | Target conditions and required stages were actually exercised with evidence; not a claim that every answer was correct. |
| FAIL | Supported violation of an applicable requirement. | Use INCOMPLETE_COVERAGE for an uncompleted target, rather than conflating it with behavioral failure. |
| INCOMPLETE_COVERAGE | Not used as a substitute for a behavioral judgment. | Another branch reached, or intended stages remain unobserved. |
| BLOCKED_SPEC | Unresolved rule prevents the relevant judgment. Independently established failures remain recorded. | Contradictory/undefined fixture prevents deciding what the target is. |
| BLOCKED_ENV | Environment/evidence failure prevents the relevant judgment; preserve earlier observations. | Environment prevents establishing target coverage. |
| NEEDS_REVIEW | Evidence or interpretation needs adjudication. | Branch/coverage evidence is insufficient or disputed. |
| NOT_RUN | No execution assessed under this work. | No target execution under this work. |

Illustrative combinations, **not executed results**: an approved, correctly
handled already-approved alternative can be `PASS / INCOMPLETE_COVERAGE` for
TC-003; a fully traversed target with incorrect timing facts can be
`FAIL / PASS`. Before the alternate rule is approved, use `BLOCKED_SPEC` or
`NEEDS_REVIEW`, not a hypothetical PASS. TC-006's unresolved intended branch
cannot acquire target coverage merely by choosing the easier source column.

```yaml
acceptance_version: P2-DRAFT-0.1
journey_id: JRN-TC-006
tc_id: TC-006
specification_label: CONFLICT
open_decisions: [OD-001]
execution_id: null
configuration_id: null
observed_branch: null
behavior_verdict: NOT_RUN
coverage_verdict: NOT_RUN
evidence_links: []
reviewer: null
```

## Versioning, comparison and regression selection

1. After review, freeze a named acceptance version with source hashes, scope,
   reviewers and unresolved blockers. Configuration identity and acceptance
   identity are separate; H1's verified October 30 export is historical context,
   not a fresh Problem #2 served-revision baseline.
2. Preserve each actual conversation and original automated grade. Add a new
   assessment when a rubric changes. A **regrade** compares the same capture
   under different requirements; it does not demonstrate a deployed correction
   or supply skipped turns. A fresh run compares runtime behavior.
3. Compare before/after only with explicit configuration, requirement, fixture,
   branch, age/timezone and channel versions. Mark confounding differences and
   sample sizes; do not silently drop failed or alternate-path runs.
4. For changed BRs, select every mapped TC/JRN/VAR, all linked atomic findings,
   and prerequisite/downstream boundaries affected by the change. Add plausible
   group impacts for review; record why each is included or excluded. Recompute
   selection if a shared policy or requirement version changes.
5. Examples: BR-012 selects TC-003/005/006/007/008/009/027/029 at applicable form
   boundaries, including the TC-006 retry variants and TC-009 failed retry;
   BR-008 selects TC-027/029 plus GM direct-status/recovery variants; BR-003
   selects relevant education paths and direct-navigation negative controls.
   These are proposed regression selections, **not newly reported DF links**.
6. Require original target fixture, relevant alternatives, neighboring shared
   requirements and voice evidence where implicated. PB §7 proposes five fresh
   independent runs for high-risk paths; sampling/any external requirement needs
   OD-015 review. Neither a single pass nor five passes proves reliability.

Keep `DF_REMEDIATED`, `TC_PASS`, `VAR_PASS`, `STAKEHOLDER_ACCEPTED` and `RELEASED`
independent (PB §7; PLAN §7/P123). The current deliverable is a **reviewable draft**,
not completion of PB's full implementation/approval/execution definition of done.

## Documentation verification

Completed offline on **2026-11-02**:

- All **15 TC inventory rows and direct DF mappings** match the original workbook;
  all **18 DF status/TC/date/category/severity/retest records** match its cells.
- **49 atomic records** account for the 18 reports, including positive observations
  and documentary conflicts; they are not 49 confirmed defects. **Nine proposed
  groups** have consistent child membership and direct-TC unions.
- **Three pilots, 18 proposed variants, 20 BRs and 15 open decisions** have valid
  internal ID references. Relative links/heading anchors and Markdown table
  structure were checked. Nine source/archive fingerprints match their originals.
- **159 pre-existing repository files and 467 historical report files** are
  byte-identical to the task's preservation baseline. The original glossary bytes
  remain an unchanged prefix, followed by the new benchmark-analysis definitions.
  The newly supplied decision bundle and original workbook are unchanged.
- **Zero live requests and zero official-baseline executions.** These checks
  validate documentation/source accounting, not Agent behavior or policy approval.

Read-only source extracts and the audit result are retained at
`C:\Users\Nau\AppData\Local\Temp\opencode\uc4-problem2-sources-62rzemtm`:
`benchmark-source-extract.json`, `decision-plan.txt`, `playbook.md`,
`preservation-before.json`, `verify-documents.py` and
`documentation-verification.json`. Original paths, archive members and hashes
above remain the primary provenance.
