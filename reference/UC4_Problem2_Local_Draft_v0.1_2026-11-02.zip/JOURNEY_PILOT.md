# Problem #2 — three Business Journey Specification pilots

**P2-DRAFT-0.1 · 2026-11-02 · PROPOSED; reviewer/approval date unassigned.**

**Preparer:** AI-assisted analysis. **Business/benchmark and QA reviewers:** to assign.

[Sources and BR register](BASELINE_MODEL.md) · [TC inventory](TC_CLASSIFICATION_MATRIX.md) ·
[Decisions](OPEN_DECISIONS.md) · [Defect impact](DEFECT_GROUP_IMPACT_MATRIX.md)

These specifications use PB §§2–5's **JRN / business requirement BR / VAR** model.
Milestones are business checkpoints, not literal speeches. A composite route below
still requires separate action/wait turns when one-by-one guidance applies.
All new fixtures, branch interpretations and mappings are **PROPOSED**; explicit
**CONFLICT** and **UNKNOWN** labels take precedence. Existing approved POC rules
are cited as POC-scoped support, never formal Grab approval.

All three pilots have `behavior_verdict=NOT_RUN`, `coverage_verdict=NOT_RUN`,
`configuration_id=null`, and no new execution evidence. The dialogues in WB are
illustrations, not recordings assessed here. A hypothetical acceptable branch is
not a recorded PASS.

## Common contract

- Record English/voice as the benchmark context; actual channel, execution date,
  business timezone and served revision belong to a future run. “About two weeks”
  denotes the workbook's beyond-threshold fixture, not verified runtime math.
- Preserve clear current-order business line, age, goal, preferences and observed
  location. Ask only for genuinely missing facts. No preparation/packing fact is
  established merely by the sample greeting.
- Apply the relevant opening/disclosure once (BR-004), semantic/controlled-text
  boundary (BR-020), safety priority and terminal ownership. Exactness must cite
  the applicable JOB29 control/version, subject to OD-011; sample wording alone
  supplies no literal requirement.
- Read status from merchant observations; distinguish order visibility, status,
  request-link visibility and form visibility. A navigation acknowledgement proves
  only the immediately requested action. Merchant-reported submission is not
  backend confirmation or approval.
- Allow natural paraphrase, supported clarifications and different turn counts.
  One-by-one pacing and business observation/consent boundaries remain mandatory
  within the proposed accepted profile. Unknown outcomes never imply automatic
  transfer. See BR-001–020 for sources and applicability.

## JRN-TC-003

### Identity, goal and fixture

- **Source:** `WB:S!A6:F6`; PB §4; PLAN §5/P079–098. **LOB:** GrabFood.
- **Goal:** check cancelled-order compensation status, then submit a review request
  if still appropriate. **Original target:** full App submission happy path.
- **Starting facts:** beyond threshold; App; one-by-one; no loudspeaker; dual goal
  supplied upfront in E6. Existing location and actual status must be observed.
- **Proposed branch-driving fixture:** relevant order visible, compensation status
  absent/not compensated, merchant wants review; request link and then form become
  visible; merchant reports submitting. These facts make the target testable;
  E6 does **not** explicitly supply a not-compensated status or establish individual
  eligibility. Any eligibility prerequisite beyond the documented request process
  is **UNKNOWN** (OD-002/014).
- **Source conflicts:** E6 uses Date selector even after order visibility;
  JOB29 makes History/date recovery conditional (OD-007). Education depends on
  whether this is an upfront direct dual request or an older-order inquiry response
  (OD-004). DF-017's quoted Auto approved merchant reply is not present in E6.

### Milestones and dependency edges

| ID | Applicability / required outcome | BRs; provenance |
|---|---|---|
| M01 | Always: establish/reuse the current GF order, age-dependent context and both goals. | BR-001/002; WB:S!C6:E6; H1 §1 |
| M02 | If the reviewed education trigger applies: provide qualified GF approval/payout facts and appropriate evidence reminder before its offered walkthrough; wait for acceptance where an offer is required. Trigger is **CONFLICT**, not universal. | BR-003; JOB29 “OLDER CANCELLED ORDER”; OD-004/005 |
| M03 | Before guidance: collect only missing App/style/loudspeaker preferences and continue from known location. | BR-005; WB:S!E6 |
| M04 | Always on status path: App → Orders → Cancelled; observe whether the relevant order is visible. If missing, use the conditional recovery below. | BR-006/007; KB GF-STATUS-C01; JOB29 “GRABFOOD APP — COMPENSATION STATUS” |
| M05 | Once order visible: inspect/read the reported compensation status; clarify ambiguity rather than substitute order visibility for status. | BR-007/009; PB §4; KB GF-STATUS-C01 |
| M06 | After M05: select a source-supported next step using status **and** remaining intent. For the target, proceed to the still-requested review/submission path without promising eligibility or asking the merchant to restate the goal. | BR-009; PB D-05/D-10; OD-002 |
| M07 | Target submission: open relevant order details if needed → present Request for compensation link → Report a payment dispute → scroll → observe form visibility. Apply supported access recovery if necessary. | BR-010/012; KB GF-SUBMIT-C01, SHARED-REQUEST-C01; H1 §5 |
| M08 | Only after form visible: order details, GF prepared-food evidence guidance with no-photo qualification, merchant self-submission. | BR-013; KB GF-EVIDENCE-C01/C02; JOB29 request route |
| M09 | After merchant reports submission: acknowledge their action; compensation remains conditional on approval, with no invented result/payment date. | BR-013; JOB29 “POST-SUBMISSION RESPONSE CONSTRAINTS” |
| M10 | At an appropriate branch endpoint: further help/finish handling; do not call the payment issue resolved merely because a request was reported submitted. | BR-014; WB:S!D6:E6; JOB29 “CLOSING” |

Dependencies: `M01 → M03 → M04 → M05 → M06`; `M02 → M03` **only when
M02 applies**; target `M06 → M07 → M08 → M09 → M10`.
For a missing order within M04: `History → wait → Date selector/date → wait →
Confirm → wait → order-visibility observation → wait`; resume opening/status only
after visibility. Each arrow is a dependency, not permission to merge steps.

### Branch and variant register

| Branch / internal variant | Type; merchant-observed condition | Proposed handling and boundary | Label / provenance | Original target coverage |
|---|---|---|---|---|
| `target-submit` / original TC | Normal; observed not-compensated/absent status, review requested, supported form available | M01–M10 as applicable; obtain each observation, preserve approval uncertainty. No eligibility/award inferred. | **PROPOSED**; WB:S!D6:F6, PB §4 target proposal; OD-002/007 | Potentially complete only after actual target milestones and accepted requirements. |
| VAR-TC-003-A | Alternate; Auto approved, merchant only wants status confirmation | Explain supported approval/payout distinction; avoid unnecessary duplicate request; close only if the concern is satisfied. | **PROPOSED**; existing PB §4 meaning; WB:D!G21; exact status semantics **UNKNOWN**, OD-002 | Incomplete submission coverage even if behavior is later judged correct. |
| VAR-TC-003-B | Alternate; Auto approved, money not received | Preserve unpaid concern; distinguish approval/payout/bank receipt. Give only supported timing/next action; clarify remaining facts. No guaranteed payment date or automatic transfer. | **PROPOSED**; existing PB §4 meaning; KB GF-TIMING/GF-STATUS; next recovery **UNKNOWN**, OD-002/014 | Does not exercise target submission. |
| VAR-TC-003-C | Conditional; unclear/conflicting status | Ask a relevant status clarification; no invented approval, rejection or forced submission. Continue only once the branch can be supported. | **PROPOSED**; existing PB §4 meaning; PLAN §5 | Incomplete/needs review until target conditions and stages are established. |
| VAR-TC-003-D | Recovery; order missing from Cancelled | Conditional History/date/Confirm/visibility sequence, one action at a time; then observed status decision. Repeated unresolved UI failure is **UNKNOWN** beyond supported recovery. | **PROPOSED**; JOB29 GF status; OD-007 | Can complete submission only after recovery plus the remaining target; cannot substitute for a no-recovery fixture comparison. |
| VAR-TC-003-E | Recovery; request link absent in open App order details | Offer Portal and wait; on acceptance use the supported Portal form route with retained preferences. On decline stop that fallback and handle remaining help. | **PROPOSED**; KB GF-SUBMIT, JOB29 missing-link fallback; BR-010/011 | Alternate route: not the intended full App-submission coverage. |
| VAR-TC-003-F | Recovery; article reached/scrolled but form absent | Use JRN-TC-006's conditional role/retry stages. Role access alone does not establish visibility or retry consent. | **PROPOSED**; KB SHARED-REQUEST; JOB29 form recovery; WB:D!G7:G8 | Access recovery and any submission assessed separately; not proof of the normal fixture. |

**Prohibited:** blind duplicate claim, approval = bank receipt, date recovery when
its precondition is absent, merging one-by-one actions, invented screen controls,
missing-photo denial, lost pending submission, or premature successful close.

**Traceability:** direct reports DF-003/004/017; groups DG-002/004/005/006/007/009.
DF-017's adaptive-guidance feedback is not automatically a behavioral failure.
Review OD-002/004/007/010/014 before binding the disputed branch assertions.

## JRN-TC-006

### Identity, goal and fixture

- **Source:** `WB:S!A9:F9`; PB §5; PLAN §6/P101. **LOB:** GrabFood.
- **Goal:** obtain a compensation request form through authorized access; respect
  the merchant's retry decision. **Original intended branch: CONFLICT.** D9 says
  retry declined/soft close; E9 says re-login succeeds and the merchant submits.
- **Proposed primary fixture, awaiting OD-001:** beyond threshold; App, one-by-one,
  no loudspeaker; supported status/submission observations; request link present;
  article open and scrolled, form absent; authorized role available/confirmed;
  merchant explicitly declines the separate retry offer and then finishes.
- E9's contradictory order-visibility replies and role inference are not mandatory
  facts. The primary fixture needs explicit, internally consistent observations
  (OD-007/010). Age, preparation, eligibility and authenticated access are not
  independently verified by this specification.
- DF-008 is directly filed against TC-006, but describes a **missing App link and
  unavailable Portal** deviation. It is not evidence that either conflicting role
  retry target was fully executed.

### Milestones and dependency edges

| ID | Applicability / required outcome | BRs; provenance |
|---|---|---|
| M01 | Establish/reuse order, goal, conditional education and preferences; complete applicable status decision before this submission continuation. | BR-001/002/003/005/009; WB:S!D9:E9; OD-004 |
| M02 | Establish relevant App request link/article navigation. Missing link uses BR-010 fallback, not a premature form-role diagnosis. | BR-010; KB GF-SUBMIT; JOB29 missing-link fallback |
| M03 | Article open → scroll instructed/completed → explicit form-absent observation. | BR-006/012; WB:S!F9/E9; JOB29 form recovery |
| M04 | Explain Owner/Manager submission requirement; if access is unknown, ask and wait. Reuse already confirmed access. Do not assert the missing form proves an incorrect role. | BR-012; KB SHARED-REQUEST-C01; OD-010 |
| M05 | Once authorized access is established, offer one form retry as a distinct question, then wait. Role confirmation is not consent to retry. | BR-012; JOB29 “FORM NOT VISIBLE — ROLE ACCESS AND ONE RETRY” |
| M06 | If retry accepted: instruct one retry of the same supported form route with authorized access; await its observed result. | BR-012; same source; WB:S!E9 |
| M07 | If form becomes visible: resume details/GF evidence/self-submission in selected style; obtain submission report and conditional acknowledgement. | BR-013; KB GF-EVIDENCE, SHARED-REQUEST; WB:S!E9 |
| M08 | If accepted retry fails: speak the supported person offer and wait. The failed retry report is not transfer consent or a finish signal. | BR-015; JOB29 “CONNECTION AFTER FAILED FORM RETRY”; neighboring WB:S!E12 |
| M09 | If person offer accepted on later input: one mock transfer, Flow-owned closing; if declined: no transfer, handle further help/finish. | BR-014/015; JOB29 controlled flow content |
| M10 | If retry declined: no retry/automatic transfer; supported later-attempt/soft-close advice and further-help handling, closing only when finished. | BR-012/014; WB:S!D9; JOB29 form recovery; OD-001 |

Dependencies: `M01 → M02 → M03 → M04 → M05`; unknown role requires a separate
answer before M05. `M05/yes → M06 → visible:M07` or `not-visible:M08 → M09`.
`M05/no → M10`. Initial unsuccessful form access plus **one** accepted retry
is two attempts total, not permission for two additional retries.

### Branch and variant register

| Branch / internal variant | Type; condition | Proposed handling and boundary | Label / provenance | Original target coverage |
|---|---|---|---|---|
| `retry-declined` / proposed primary TC | Normal candidate; form absent, access confirmed, retry explicitly declined | M01–M05 then M10; no invented successful form or consented transfer. | **CONFLICT** pending OD-001; D9 supports it, E9 does not | BLOCKED_SPEC for target attribution until the owner chooses the primary fixture. |
| VAR-TC-006-A | Alternate; retry accepted, form becomes visible | M06 → M07, actual merchant-reported submission, appropriate finish. | **PROPOSED**; E9, JOB29 role recovery | Covers successful-retry variant, not a declined-retry target. |
| VAR-TC-006-B | Recovery; retry accepted, form remains absent, later person offer explicitly accepted | M06 → M08 → M09; separate retry and handoff consent, one mock transfer. | **PROPOSED**; JOB29 failed retry; WB:S!E12 supports neighboring behavior | Covers failed-retry/handoff variant, not the proposed original decline. |
| VAR-TC-006-C | Alternate; accepted retry fails, merchant declines person offer | M08 → no transfer → further-help/finish handling; do not renew retry/connection offers. | **PROPOSED**; JOB29 failed-retry decline behavior | Distinct consent-decline coverage. |
| VAR-TC-006-D | Conditional; form visible after initial article/scroll | Skip role-recovery/retry milestones, proceed with supported submission. Whether a universal spoken role reminder is mandatory remains OD-010. | **PROPOSED**; KB request route; JOB29 form boundary | Correct normal access does not test TC-006's missing-form/retry branch. |
| VAR-TC-006-E | Conditional recovery; authorized access unavailable or cannot be established | Clarify access without requesting credentials; do not promise role acquisition, guaranteed form visibility or automatic handoff. Required next disposition remains **UNKNOWN** pending owner review. | **UNKNOWN**; KB documents required role, not every unavailable-role outcome; OD-010/014 | Block the unsupported outcome; do not mark the retry branch covered. |

**Prohibited:** choosing a source outcome silently; conflating absent link with
absent form; assuming role from UI failure; requesting credentials; unconsented
retry/transfer; unlimited retries; or claiming backend submission from “form visible.”

**Traceability:** direct report DF-008; groups DG-006/007, with positive inquiry and
Date selector observations retained as DG-002/004 controls. DF-003/004/007/009/011 are
requirement-related reports on **other** TCs, not direct TC-006 reports. Their
potential impact is explicit in DG-005/007. OD-001 is the primary coverage blocker.

## JRN-TC-027

### Identity, goal and fixture

- **Source:** `WB:S!A16:F16`; PB §5; PLAN §6/P103. **LOB:** GrabMart.
- **Goal:** status review followed by a request if still needed. **Pilot target:**
  App-selected → explicit computer-Portal transition → one-by-one Portal status →
  conditional Portal submission. D16's broader “App or Portal” allowance remains
  visible; Portal-first does not demonstrate this pilot's App-transition coverage.
- **Starting facts:** beyond/about two weeks; dual goal; App selected; one-by-one;
  no loudspeaker. **Proposed target observations:** merchant can access computer
  Portal; relevant order visible but not compensated/no status; form later visible;
  merchant reports submission. E16's “No” alone does not distinguish a missing
  order from a visible order with no compensation status.
- **CONFLICT:** E16 opens App then gives Portal controls, promises bank credit
  within 3–5 business days and allows full-or-partial compensation. F16 says
  Portal-only status. KB/JOB29/POC distinguish these claims; OD-003/005/006 need
  explicit resolution. Education trigger for the upfront dual request is OD-004.

### Milestones and dependency edges

| ID | Applicability / required outcome | BRs; provenance |
|---|---|---|
| M01 | Establish/reuse GM order, age-dependent combined goal and preferences. Combined status/submission is not the POC status-only intake exception. | BR-001/002/005; WB:S!C16:E16; POC approved policy |
| M02 | If reviewed education trigger applies, supply qualified approval/next-payout facts and await any required offer response. Do not recite E16's bank-credit promise. | BR-003; KB GM-TIMING; OD-004/005 |
| M03 | Before first applicable navigation: existing POC partial notice once; explain that this status check uses computer Portal, then establish readiness/location before Portal controls. Preserve selected style/loudspeaker. | BR-005/008/018; JOB29 “GRABMART GUIDANCE RULES”; OD-003/006 |
| M04 | Once Portal accessible: Finance → wait → Transactions → wait → relevant time period/store → wait → Category / Compensation for cancelled orders → wait. Period/store is one action; Category is separate. | BR-006/008; KB GM-STATUS; JOB29 one-by-one segmentation |
| M05 | Separately ask/read the observed compensation result; distinguish missing order from visible-but-not-compensated and clarify ambiguous “No.” | BR-008/009; JOB29 GM Portal status; WB:S!E16,E18 |
| M06 | Only after M05: choose the supported outcome. If submission remains appropriate/requested, retain that goal and continue on Portal without recollecting preferences. Approval/payout alternatives need their own review. | BR-009; PB D-05; JOB29 “STATUS AND SUBMISSION TOGETHER”; OD-002 |
| M07 | Submission: from current Portal location, Help Centre → wait → Search Bar/search dispute → wait → Report a payment dispute → wait → scroll/form-visibility observation → wait. | BR-006/011/012; KB SHARED-PORTAL/REQUEST; JOB29 Portal route |
| M08 | Form visible: order details, packed-items evidence with applicable no-photo qualification, merchant self-submission; each action separated for one-by-one guidance. | BR-013; KB GM-EVIDENCE-C01/C02; WB:S!E16 |
| M09 | Obtain merchant submission report; acknowledge conditionally, preserve unconfirmed approval/payment; finish only when appropriate. | BR-013/014; JOB29 post-submission/closing |

Dependencies: `M01 → M03`; `M02 → M03` only if M02 applies;
`M03/readiness → M04 → M05 → M06`; target `M06 → M07 → M08 → M09`.
No request-entry actions belong in the status segment before M05. No Portal
controls belong before the platform transition. Missing-order recovery returns
to an observation, not directly to submission.

### Branch and variant register

| Branch / internal variant | Type; condition | Proposed handling and boundary | Label / provenance | Pilot target coverage |
|---|---|---|---|---|
| `app-to-portal-submit` / original TC pilot | Normal; App preference, Portal available, visible order without compensation, submission needed | Explicit transition, M04/M05 status observation, then supported Portal submission. | **PROPOSED**, transition source **CONFLICT** until OD-003; WB:S!D16:F16 and KB GM-STATUS | Complete only with the App transition and all applicable target stages actually observed. |
| VAR-TC-027-A | Alternate; merchant starts in Portal | Begin at confirmed Portal location; same status/conditional submission dependencies, no redundant reopening or platform question. | **PROPOSED**; D16 allows Portal; JOB29 GM Portal route | Does not prove App-transition coverage; benchmark-wide target choice requires OD-003. |
| VAR-TC-027-B | Alternate; order already compensated/approved | Clarify whether the concern is status only or unpaid funds; use supported explanation, avoid unnecessary duplicate request and premature close. | **PROPOSED**; KB GM-STATUS/TIMING, PB §4 reasoning adapted to GM; exact status semantics **UNKNOWN**, OD-002 | Alternate behavior, not original submission coverage. |
| VAR-TC-027-C | Recovery; no computer-Portal access | Supported POC access-assistance offer, then wait. Explicit later acceptance → one mock transfer; decline → further-help handling; gained access → resume known route. Never invent App status or close solely for missing access. | **PROPOSED** for acceptance; JOB29 “GRABMART PORTAL UNAVAILABLE — SUPPORT OFFER”; direct historical report WB:D!G18, owner-resolved per PLAN P012 | Does not complete status/submission unless access is recovered and the target then finishes. Each consent outcome must be recorded separately. |
| VAR-TC-027-D | Recovery; order absent from selected report | Recheck period to cover cancellation date, retaining store/Category; wait for a new observation. No GF History route or inferred rejection. | **PROPOSED**; JOB29 GM Portal status; KB GM-STATUS limitation | Can reach later target only after supported recovery; preserve different fixture identity. |
| VAR-TC-027-E | Conditional recovery; submission article scrolled, form absent | Apply role/access → one offered/accepted retry → observed result, as JRN-TC-006. Any failed-retry handoff still needs separate consent. | **PROPOSED**; KB SHARED-REQUEST; JOB29 form recovery | Records recovery variant; normal form-available coverage remains distinct. |
| VAR-TC-027-F | Conditional negative control; explicit GM status-only navigation, age/loudspeaker not supplied | Apply the **VERIFIED [POC]** navigation exception: no age/loudspeaker intake solely to enable status navigation; collect only necessary navigation facts. | **PROPOSED variant** supported by POC approved policy; outside combined target | Does not exercise age-dependent combined status/submission. |
| VAR-TC-027-G | Alternate negative control; GM submission-only, App chosen | Keep supported App submission path; no forced status detour or universal Portal redirect. | **PROPOSED**; KB GM-SUBMIT; JOB29 GM guidance/platform rules | Does not exercise the Portal status/transition target. |

**Prohibited:** Portal controls on an unestablished platform, GM App status,
unconditional Portal routing for App submission-only, bank-credit guarantees,
fixed award claims, repeated notice/preferences, skipped status/form observations,
unconsented handoff, or closing an unresolved access concern as successful.

**Traceability:** direct report DF-014; groups DG-003/004/007/008. Its October 23
owner-reported resolution is retained; drafting a recovery variant does not reopen
it. TC-029/DF-016 are neighboring all-at-once control evidence, not proof this
pilot or any new variant passed.

## Pilot acceptance and review action

For each run, assess applicable BRs against actual observations and the approved
requirement version, then assess the **target fixture independently**. A supported
alternate may be behaviorally correct while target coverage is incomplete. A
disputed rule yields BLOCKED_SPEC/NEEDS_REVIEW for the affected judgment; retain
independent established violations rather than hiding them behind the conflict.

Before baseline evaluation, reviewers should agree on the fixture, conditional
milestones, controlled-language scope and prohibited outcomes for each pilot.
Record decisions in OPEN_DECISIONS, version the affected JRN/BR/VAR records, and
have business/benchmark and QA reviewers independently annotate the same evidence.
This draft supplies no new transcript, trace, deployment verification or pass.
