# Problem #2 — open decisions and review frontier

**P2-DRAFT-0.1 · 2026-11-02 · No decision below is newly approved.**

[Sources and requirements](BASELINE_MODEL.md) · [Classification](TC_CLASSIFICATION_MATRIX.md) ·
[Pilots](JOURNEY_PILOT.md) · [Defect impact](DEFECT_GROUP_IMPACT_MATRIX.md)

The agreed root is the October 23 process direction: preserve the original
workbook, evaluate business milestones, distinguish behavior from coverage and
review inferred branches. This draft records recommendations; it does not enact
them. `CONFLICT`, `UNKNOWN` and `PROPOSED` use PB §9's meanings. Named owners and
review dates are **unassigned**, not implicitly the preparer or the LLM.

## Decision register

| ID / label | Source-grounded question | Recommendation for review; decision owner | Effect while unresolved |
|---|---|---|---|
| OD-001 **CONFLICT** | TC-006's path declines role retry (`WB:S!D9`), but its dialogue accepts re-login, sees the form and submits (`E9`). PB §5; PLAN §6/P101. | Benchmark owner + business reviewer: retain decline as a proposed primary fixture, preserve successful retry as `VAR-TC-006-A`, failed retry as `VAR-TC-006-B`. Explicitly choose; neither column silently overrides the other. | TC-006 intended-branch coverage BLOCKED_SPEC when assessed; BR-012/014/015. |
| OD-002 **PROPOSED**; exact status semantics **UNKNOWN** | DF-017 says Auto approved needs no new request and praises adaptive guidance (`WB:D!G21`). TC-003's E6 mentions auto-approved statuses, but contains no merchant reply “Auto approved.” PB §4's branches are explicitly proposals. | Business/policy reviewer: validate status meaning and no-unnecessary-duplicate rule; distinguish status-only satisfaction from approved-but-unpaid concern. KB status/timing supports approval ≠ bank receipt, not an individual award or an automatic escalation route. | `VAR-TC-003-A/B/C` require review; original submission fixture needs an explicit observed not-compensated condition, without assuming eligibility. BR-003/009. |
| OD-003 **CONFLICT** | TC-027 selects/opens App before Finance → Transactions (`WB:S!E16`); F16 says Portal only, D16 says App or Portal. TC-029 E18 does include the computer-Portal redirect. PB §5; PLAN P103; KB GM-STATUS. | Benchmark + business reviewers: retain App selection as initial state, explicitly redirect to computer Portal and establish readiness before Portal controls. Preserve style/preferences. Use current POC portal-unavailable recovery only with its scope/consent constraints. | TC-027 transition fixture needs approval; TC-029 and GM status variants are shared impact. BR-005/008/015. |
| OD-004 **CONFLICT** | Education triggers differ by intent/entry path. DF-018's TC-004 is beyond threshold (`WB:S!C7:D7`), but its fix note cites **within threshold** (`WB:D!N22`). PB D-05's relevant-status rule must also be scoped alongside JOB29's submit-only path and POC's later direct GM status-only exception. | Business + benchmark reviewers: publish an intent/age trigger table: age-only → clarify goal; recent education where applicable; older open-question policy response where applicable; direct status/submission paths governed by their explicit exceptions. Keep DF-018's owner-reported closure, but do not treat N22 as proof of original-fixture regression. | BR-001/002/003/009; TC-003/004/005/009/027/028/029 and direct-status negative controls. Do not make universal education or universal status-first intake binding. |
| OD-005 **CONFLICT**; date conventions **UNKNOWN** | WB uses “days” for usual approval; E16/E18 instead promise bank credit in 3–5 business days. KB GF/GM TIMING and H1 distinguish business-day approval, regular payout and bank receipt. C cells say order age; sample inputs sometimes say order **made**, while routing uses cancellation age. GM E14/E15/E17 refer to prepared-food photos. | Business/policy reviewer: use source-qualified KB timing distinctions for the POC; clarify age origin/timezone and the correct stage-specific evidence reminder. GM recent JOB29 says “photo of the order”; submission requires packed-items guidance. Preserve conflicting WB text as history. | BR-002/003/013; all timing paths, especially TC-025–029. No guaranteed payment date or automatic photo-based ineligibility. |
| OD-006 **CONFLICT** | TC-027/029 allow full-or-partial compensation and TC-029 repeats the notice (`WB:S!E16,E18`). Adopted POC text says “will be partial”; H1 §6 item 2/KBC flag its certainty. | Business/content owner: decide amount/qualification wording and exactness. Until reviewed, retain the existing POC control as source-qualified, once before applicable navigation; never convert either example into a guaranteed individual award. | BR-018; TC-027/029; historical DF-014's delayed notice, not wholly absent content. |
| OD-007 **CONFLICT** / fixture detail **UNKNOWN** | TC-003's order is already visible before unconditional Date selector steps (`WB:S!E6`). TC-007 D10/F10 require a stuck-step repeat, but E10 shows bundled History/date/Confirm and no explicit failed-step retry. TC-006 E9 has consecutive cannot-see/can-see replies. JOB29 makes History conditional on missing order and separates one-by-one actions. | Benchmark + QA reviewers: define missing-order versus missing-control facts explicitly; propose a Date-selector first-failure fixture for TC-007, without claiming it already exists. Preserve mandatory waits; require only applicable recovery steps, not gratuitous Date selector usage. | BR-006/007/019; TC-003/005/006/007. Date-selector omissions need the actual precondition, not a wording-only verdict. |
| OD-008 **CONFLICT** | TC-009 path says **GrabFood Portal status** (`WB:S!D12`); E12 declines status guidance and requests **Portal submission only**. KB GF-STATUS supports App status; JOB29 does not support GF Portal status. | Benchmark + business reviewers: propose E12's direct Portal submission → failed role retry → consented mock transfer as target; keep D12 discrepancy visible. Do not invent GF Portal status to satisfy the path label. | TC-009 coverage BLOCKED_SPEC pending target review; BR-009/011/012/015. |
| OD-009 **CONFLICT** / final intent **UNKNOWN** | TC-004 offers guidance and immediately asks anything else with no reply (`WB:S!E7`, PLAN P105). TC-028 closes after “okay” (`E17`). DF-012 demands “Thank you for Calling Grab,” absent from TC-010's transfer script (`WB:D!G16`; `WB:S!E13`). “Payout question” in E13 may still be UC4-related. | Business + benchmark reviewers: add explicit offer response/finish signals to fixtures; distinguish normal closing from Flow-owned mock transfer. Require a clearly unrelated TC-010 topic or clarification. Review DF-012's possible truncated closing separately from its courtesy-phrase complaint. | BR-014/015/016/020; TC-004/009/010/028 and consent variants. Acknowledgement ≠ transfer consent or automatic resolution. |
| OD-010 **UNKNOWN**; conflicting recovery assumptions **CONFLICT** | Role authorization is documented (KB SHARED-REQUEST), but scope/timing of a **spoken role reminder on every successful submission** is unsettled. DF-007/009 request role/date advice absent from their example transcripts. DF-008 N12 suggests role establishes menu visibility; KB says missing link/form does not prove wrong role. | Business + benchmark reviewers: distinguish missing App link from missing form after article/scroll; adopt explicit role-access, retry-offer, consent, attempt and observation stages for the POC. Decide universal reminder applicability separately. Keep lack of role/access and lack of computer access distinct. | BR-010/012/015/019; TC-003/005/006/007/008/009/027/029. Do not declare every omitted reminder a confirmed defect or promise the UI will appear. |
| OD-011 **PROPOSED** | Which exact text is binding, for which version/channel? WB's sample speeches are illustrative (PB D-03); JOB29 explicitly fixes some POC statements. | Business/content owner + QA: approve a compact controlled-text register with source/version, exact text or hash and applicability. All other language is evaluated semantically. `PB D-*` and `PLAN D-*` must remain namespaced because their numbering differs. | BR-004/020 and exact portions of BR-003/015/018. No new mandatory greeting/preparation/thanks phrase is inferred from WB alone. |
| OD-012 **UNKNOWN** current verification | WB statuses are dated history. PLAN P012/P033 and PB §§0,7 explicitly report DF-014/018 resolved; DF-001 is Closed/Pass, DF-016 Not a defect, DF-017 status blank. “Recent defects resolved” is not an enumerated closure of all 18. | Defect owner + QA: retain each status event and obtain cited fix/retest evidence only where a new closure assurance or current baseline claim is required. Do not reopen by default. H1's KB closure stays separate from benchmark acceptance. | All groups: current regression verification not established. Owner-reported resolutions remain recorded as such. |
| OD-013 **UNKNOWN** | DF-013's silence/ASR explanation and DF-017's barge-in cause are hypotheses (`WB:D!G17,G21`). No numerical response SLA or synchronized audio/trace record is supplied for those reports. | Voice/environment owner + QA: define measurable response/audibility expectations and collect aligned audio, recognized input, displayed text and timing before attribution. Do not change barge-in settings from a tester hypothesis. | BR-017; voice impact plausibly spans all 15, but is directly reported only for TC-026/003. REST text alone cannot close audibility findings. |
| OD-014 **UNKNOWN** formal policy/UI | H1 §6 and KB retain provisional preparation/packing, evidence substitutes, early form acceptance and authenticated-screen limits; 90/5/3-day UC4 applicability is unresolved. Other Portal KB routes exist but standard POC guidance uses Search Bar. | Grab policy/UI owner: confirm applicable policy and screens. Keep reference facts qualified; defer alternate Portal routes and unsupported escalation rather than inventing rules. | BR-010/011/012/013 and alternate branches. Retrieval success is not eligibility, UI or production approval. |
| OD-015 **PROPOSED** | Approval owners, acceptance scope/version, reviewer agreement and regression sample plan are not assigned. PB §§7–11 proposes five independent runs for high-risk paths, not a statistical guarantee. No external repeat count is specified in the inspected TC cells. | Project owner: name benchmark, business and QA reviewers; review the three pilots first; freeze only approved requirements and fixtures; agree focused sampling and modality coverage before an authorized baseline. | All documents remain draft; no execution authorization or new baseline pass follows from review-document creation. |

## Review round 1 — decisions whose source checks are complete

These recommendations form the current review frontier. A **yes** to a question
accepts only its stated recommendation, not formal Grab policy or live execution.
Dependent policy/wording decisions remain in the register for the next round.

❓ **Q1 — TC-006 fixture:** Shall the proposed primary target follow D9's declined
retry, with E9's successful retry retained as `VAR-TC-006-A`, pending named review?

➡️ **Recommended: yes.** Preserve both branches and explicitly approve which one
counts toward the original TC; keep failed retry separate (OD-001).

❓ **Q2 — TC-009 fixture:** Shall the proposed target be E12's submission-only
Portal role-retry failure and consented mock transfer, with D12's Portal-status
description recorded as a conflict requiring correction approval?

➡️ **Recommended: yes.** This avoids introducing an unsupported GrabFood status
route and preserves the benchmark discrepancy (OD-008).

❓ **Q3 — TC-027 transition:** Shall the proposed journey retain App selection,
explicitly establish computer-Portal readiness, then continue the Portal status
route with the existing preferences?

➡️ **Recommended: yes.** It matches the documented POC navigation boundary while
keeping portal-unavailable recovery and policy wording under review (OD-003).

❓ **Q4 — Review ownership:** Shall the next step be a named business/benchmark
and QA review of the three pilots and their blocked decisions before freezing an
acceptance version?

➡️ **Recommended: yes.** Resolve high-impact semantics, then use the same saved
evidence to check that two reviewers agree; authorize fresh baseline execution
separately (OD-015).

Decision capture must record `OD ID`, selected option, rationale, source/approval
scope, named decision-maker, date, affected BR/JRN/VAR versions and superseded
interpretation. Until then, recommendations remain **PROPOSED** and conflicts
remain **CONFLICT**.
