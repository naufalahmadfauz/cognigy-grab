# UC4 Problem #2 — business/benchmark worksheet and internal agreement log

**Package:** P2-DRAFT-0.2 + P2-ENG-DECISIONS-0.3 / OD002-REVIEW-0.2 overlays

**Status:** Four Round 1 internal agreements plus **OD-002 Q1–Q4 agreed internally** on 2026-11-02; **no formal benchmark or Grab policy approvals recorded**. See [Round 1 record](ENGINEERING_DECISIONS_2026-11-02.md) and [OD-002 approval provenance](OD002_STATUS_DECISION_REVIEW.md#recorded-q1q4-approval-and-provenance).

**Input authority:** October 23 Problem #2 PLAN/PB; Grab benchmark workbook (immutable); KB v0.3 POC source decisions; existing `OPEN_DECISIONS.md`.  
**Use:** Record selections from named benchmark/business and QA reviewers. An LLM recommendation cannot approve or change a business rule.

## Historical options for formal benchmark review

The next table retains the pre-agreement source options and formal acceptance
blockers. The internal choices are already recorded in the following agreement
log; they are not reopened by unfilled formal fields. OD-002 Q1–Q4 have explicit
answers in [the Round 2 record](OD002_STATUS_DECISION_REVIEW.md#7-review-frontier-and-adoption-limits).
Formal business/benchmark and QA sign-off remains pending for both rounds.

| OD | Issue and source evidence | Candidate option A (historical proposal; formal approval pending) | Alternative / why it matters | Historical / formal state |
|---|---|---|---|---|
| OD-001 | TC-006 `WB:S!D9` expects retry declined, while `E9` accepts re-login and successful form submission | Keep D9 declined retry/soft close as **proposed** original fixture; keep accepted/success as `VAR-TC-006-A`; failed retry separately | Stakeholder could choose E9 as original target. Either way preserve both and specify fixture; don't fabricate consensus. | CONFLICT; original TC coverage BLOCKED_SPEC |
| OD-008 | TC-009 `WB:S!D12` says Portal *status*, `E12` explicitly declines status and requests submission only | Use E12 Portal submission + failed retry + separate consented mock transfer as **proposed** original fixture | If D12 is required, confirm supported GF Portal status route before requiring it; current KB supports GF App status. | CONFLICT; original TC coverage BLOCKED_SPEC |
| OD-003 | TC-027 `WB:S!E16` selects App, then shifts into Portal Finance/Transactions; `F16` says Portal-only for GM status | Keep App selection; explicitly explain computer Portal status route, confirm Portal readiness and preserve style | Portal unavailable needs separate supported recovery/consent; don't silently treat App as Portal. | CONFLICT; target fixture review pending |
| OD-015 | Reviewer ownership/acceptance scope/sample count not assigned | Assign business/benchmark owner and QA reviewer; sign off only on chosen fixture/BR applicability with version and date | Without reviewer authority, mark draft and don't convert proposed instructions into Grab policy. | PROPOSED; no approvals |

## Project-side engineering agreement log (recorded 2026-11-02)

| OD | Selected internal POC direction | Scope | Formal reviewer sign-off |
|---|---|---|---|
| OD-001 | Declined retry = provisional original TC-006; success = VAR-TC-006-A; failed retry separate | Engineering fixture agreed; original workbook contradiction retained | Pending |
| OD-008 | Portal **submission-only**; failed retry → person offer → separate explicit consent → mock transfer | Engineering fixture agreed; original workbook contradiction retained | Pending |
| OD-003 | App selection → explain computer Portal requirement → verify readiness → Portal status guidance; preserve preferences | Engineering transition agreed; benchmark conflict retained | Pending |
| OD-015 | Appoint business/benchmark and QA reviewers; review and freeze scoped accepted requirements before baseline execution | Review governance agreed; appointments and sign-off not performed | Pending |
| OD-002 | Q1 Approved: visible-blank review-request target with intent/prerequisites, no eligibility/award claim. Q2 Approved provisionally: reported approval/status-only explanation without unnecessary duplicate. Q3 Approved provisionally: approval/payout/bank-receipt explanation and clarification priority, no invented remedy/date/guarantee. Q4 Approved: clarify observed status before status-dependent submission. | **VERIFIED [POC] / ENGINEERING_AGREED_POC**, OD002-REVIEW-0.2; all four provisional internal POC decisions. Behavior and original TC-003 coverage remain independent; dependent requirements, formal semantics and remedies remain open | Pending |

**Recorded authority:** the requesting project-side user's explicit conversation
agreement, 2026-11-02. Personal name, official role and formal business/benchmark
or QA authority were not supplied. OD-002's source quotation, rationale, affected
versions and superseded wording are in its linked record. These entries do not
create formal Grab policy approval or authorize runtime changes.

## Formal human review record — leave unfilled until named authorized reviewer signs off

| OD | Selected option / alternative | Business or benchmark reviewer | QA reviewer | Date | Approval scope and rationale | Impacted BR/JRN/VAR version | Decision state |
|---|---|---|---|---|---|---|---|
| OD-001 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | BR-012/014/015; JRN-TC-006; VAR-TC-006-A/B | CONFLICT |
| OD-008 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | BR-009/011/012/015; JRN-TC-009 | CONFLICT |
| OD-003 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | BR-005/008; JRN-TC-027; TC-029 comparison | CONFLICT |
| OD-015 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | Review framework and high-risk sampling | PROPOSED |
| OD-002 | _pending formal confirmation_ | _unassigned_ | _unassigned_ | — | _formal scope pending; internal Q1–Q4 recorded above_ | OD002-REVIEW-0.2: BR-009; JRN-TC-003; VAR-TC-003-A/B/C | UNKNOWN formal policy; sign-off pending |

## Reviewer checklist

- [ ] Confirm the two separate questions for each fixture: Agent behavior on observed branch and coverage of intended original TC.
- [ ] Confirm the proposed target and any distinct test variant, without overwriting Grab's workbook.
- [ ] Check BR source authority and its **POC adoption** vs **formal business approval** boundary.
- [ ] Identify which requirements are business obligations versus QA/evidence rules.
- [ ] Review the recommended next **OD-004/005** batch: education/intent triggers with timing/date-stage conventions. See [remaining blockers and outputs](OPEN_DECISIONS.md#remaining-blockers-and-next-review-batch).
- [ ] Obtain formal OD-002/014 status, duplicate/dispute and unpaid-remedy evidence; retain the answered internal Q1–Q4 choices. Review OD-007/010/009 and OD-006/011 in subsequent scoped batches.
- [ ] Record an owner, date, rationale, changed versions, evidence and dissent/unresolved status.
- [ ] After applicable decisions and named sign-off, consider a scoped baseline version and separate execution authorization. Full Business Acceptance Baseline v1.0 remains **NOT FROZEN** under this update.

**Later work, after the applicable reviews:** normalize remaining journey acceptance
conditions and evaluate separately authorized evidence. Round 2 is limited to
OD-002 and does not expand the other 12 specifications or run/regrade tests.
Retain independent historical/new verdicts; KB coverage is not 15 benchmark passes.
