# UC4 Problem #2 — Engineering Review Pack v0.3 + OD-002 agreement

**Date:** 2026-11-02  
**Status:** **bounded internal POC agreements recorded** for OD-001/002/003/008/015; dependent BR/JRN acceptance and formal Grab benchmark/policy approval remain pending; **NOT executed; baseline NOT FROZEN**

**Scope:** business journey classification and defect impact/traceability only. This package does not edit Cognigy, the Python runner, or original source records.

## Round 2 — OD-002 status decision review

[OD002_STATUS_DECISION_REVIEW.md](OD002_STATUS_DECISION_REVIEW.md) is now
`OD002-REVIEW-0.2`. The requesting project-side user approved **Q1–Q4 on 2026-11-02**
as provisional internal POC engineering decisions (`VERIFIED [POC]` /
`ENGINEERING_AGREED_POC`):

- **Q1 / A — Approved:** visible-blank-status review-request fixture for TC-003;
  preserve intent/prerequisites without asserting eligibility or a guaranteed award.
- **Q2 / B — Approved provisionally:** explain reported Auto approved for a
  status-only goal, avoid unnecessary duplicate submission and address concerns.
- **Q3 / C — Approved provisionally:** distinguish approval, payout and bank receipt;
  prioritize explanation/clarification without invented remedies, dates or guarantees.
- **Q4 / D — Approved:** clarify observed status before status-dependent submission.

The [approval provenance](OD002_STATUS_DECISION_REVIEW.md#recorded-q1q4-approval-and-provenance)
records the user's actual authority and superseded proposals. Formal policy
semantics, unpaid-payment remedies and dependent acceptance remain open. The Job
source is unchanged; internal explanation priority is settled, runtime conformance
unverified. Correct B/C handling does **not** complete TC-003 submission coverage;
D counts only if clarification later establishes and exercises A's full target.
Behavior and coverage verdicts remain `NOT_RUN`.

The eight source-pack documents were integrated from the actual v0.3 archive,
then amended only for this addendum's links and current internal decision scope.
The historical decision record and BP memberships are retained. The original
pack's v0.2 README title/stale decision checklist did not supersede its explicit
v0.3 engineering agreements. Latest historical KB/Job evidence was read from the
October 30 export matching the Problem #1 handover hash.

**Current change summary:** versioned OD-002 approval/provenance; synchronized
BR-009, TC-003/VAR-TC-003-A/B/C and linked decision/worksheet status; explicit
remaining blockers and recommended next review batch; archived the exact nine
pre-approval documents. The earlier v0.1 review's source analysis, restored v0.3
family register and glossary additions remain preserved history. No formal Grab
approval or execution is claimed.

## What changed in P2-ENG-DECISIONS-0.3 (2026-11-02)

The user explicitly agreed in the conversation to four **provisional internal engineering directions**. See [ENGINEERING_DECISIONS_2026-11-02.md](ENGINEERING_DECISIONS_2026-11-02.md). The former source contradictions remain documented, no named business/QA reviewers have been assigned, no new Agent runs have been executed, and no acceptance baseline is frozen. The existing 0.2 source classifications and proposed groupings remain draft.

## What changed from P2-DRAFT-0.1

Historical v0.2 change record: that pack was a narrowly revised **copy** of the
five uploaded Markdown drafts. This repository now continues the supplied v0.3
pack; earlier document bytes are preserved in the archives below.

1. `TC_CLASSIFICATION_MATRIX.md`: adds **BP-01 to BP-07** reusable shared process families, a 15-TC primary/secondary/conditional map, and safeguards against turning families into blanket pass or defect labels.
2. `DEFECT_GROUP_IMPACT_MATRIX.md`: adds a **BR-first impact-based regression selection procedure** and a worked DG-005 case, explicitly separating directly reported TCs, plausible applicability and negative controls.
3. `BASELINE_MODEL.md`: classifies **BR-017 as QA_EVIDENCE** and **BR-020 as QA_SEMANTIC_ACCEPTANCE**, leaving the IDs and source provenance unchanged; other BRs remain candidate Agent behavior rules.
4. `JOURNEY_PILOT.md`: adds a compact TC-003/006/027 process-family and review-gate crosswalk.
5. `OPEN_DECISIONS.md`: adds unapproved decision-capture guidance and points to the review worksheet.
6. `REVIEW_DECISION_WORKSHEET.md`: a four-decision **review artifact**, not a decision or authorization.

## Most important distinction

**BP** = shared business-process family; **BR** = source-linked requirement; **JRN** = normalized journey; **TC** = original Grab test; **DF** = original defect report; **DG** = proposed grouping of behavior findings; **VAR** = fixture variant. Their mappings are many-to-many. Group membership does **not** demonstrate a common implementation cause, active failure, or remediation. Review source `BASELINE_MODEL.md` for provenance and authority.

## Next human review (in order)

- [x] Record [OD-002 Q1–Q4](OD002_STATUS_DECISION_REVIEW.md#recorded-q1q4-approval-and-provenance) as bounded internal agreements; preserve separate behavior/coverage verdicts.
- [x] Preserve OD-001 internal choice: TC-006 declined-retry primary; formal benchmark adjudication remains pending.
- [x] Preserve OD-008 internal choice: TC-009 Portal submission-only; formal benchmark adjudication remains pending.
- [x] Preserve OD-003 internal choice: TC-027 explicit App → Portal readiness; formal benchmark adjudication remains pending.
- [x] Preserve OD-015 staged internal POC review governance.
- [ ] **Recommended next batch: OD-004 + OD-005** — review education/intent triggers with timing/date-stage conventions, preserving agreed direct-intent and approval-aware exceptions.
- [ ] Obtain OD-014 policy-owner evidence for canonical statuses, duplicate/dispute rules and approved-but-unpaid remedies/triggers; authenticated UI/eligibility limits remain explicit.
- [ ] Assign OD-015 business/benchmark and QA reviewers and their approval scope; unfilled formal fields do not reopen the internal choices.
- [ ] Follow with OD-007/010/009 fixture/access/consent boundaries and OD-006/011 GM certainty/controlled text; track OD-012/013 evidence dependencies.
- [ ] Confirm the existing BP taxonomy during scoped review, without restarting classification or expanding the other 12 specifications.

See [remaining blockers and batch outputs](OPEN_DECISIONS.md#remaining-blockers-and-next-review-batch).
**Full Business Acceptance Baseline v1.0 remains unfrozen.** Any later scoped
freeze requires applicable requirement/fixture decisions and named reviewer
sign-off; configuration capture, evidence assessment and execution are later work.

**Do not infer:** 15/15 benchmark passes, 18 open defects, 9 common root causes, formal Grab policy approval, or that a POC configuration change was made. Problem #1 KB v0.3 is separately closed for its verified isolated-POC scope.

## Files

- `BASELINE_MODEL.md`
- `TC_CLASSIFICATION_MATRIX.md`
- `JOURNEY_PILOT.md`
- `DEFECT_GROUP_IMPACT_MATRIX.md`
- `OPEN_DECISIONS.md`
- `REVIEW_DECISION_WORKSHEET.md`
- `ENGINEERING_DECISIONS_2026-11-02.md`
- `OD002_STATUS_DECISION_REVIEW.md`

The original documents have **repository-relative links** to original sources and other repo files, which resolve when these Markdown files are placed into `docs/problem2/` in the original repo. The ZIP itself does not contain or alter those source assets.

## Version history and preservation

| Version / date | Record / immutable history and SHA-256 | Change scope |
|---|---|---|
| `P2-DRAFT-0.1` / 2026-11-02 | [Local draft snapshot](../../reference/UC4_Problem2_Local_Draft_v0.1_2026-11-02.zip); `e07f611fa420c1bba181de8275d4eb3b7649c37338e65cbf8bb2634ca47c100f` | Preservation ZIP created in Round 2 from the five untouched pre-edit local files; not a newly discovered external release. |
| `P2-DRAFT-0.2` / 2026-11-02 | [Supplied structural pack](../../reference/UC4_Problem2_Structural_Review_Pack_v0.2.zip); `175d562783fbaec5f731a7f59861eb53d55def151882c872c856a6ac76fc9ea1` | BP-01–BP-07, requirement kinds, BR-led regression selection and review worksheet. |
| `P2-ENG-DECISIONS-0.3` / 2026-11-02 | [Supplied engineering pack](../../reference/UC4_Problem2_Engineering_Review_Pack_v0.3.zip); `3244e5ec8ae7cdd28a76dd3f4aec144ebbf34fa56a83b5b23b24be5080463606` | Four limited agreements and dedicated decision record. TC classification/defect matrix identical to supplied v0.2; other overlays preserved in this archive. |
| `OD002-REVIEW-0.1` / 2026-11-02 | [Pre-approval nine-document snapshot](../../reference/UC4_Problem2_OD002_Review_v0.1_2026-11-02.zip); `9e34da889adf7847a6d519bf75dd60a7a6e900767876a3a9d8c53da298dd595e` | Exact local state before Q1–Q4 were recorded as agreed: questions, proposals, source/dependency analysis and previous audit retained. Local preservation archive, not an externally supplied release. |
| `OD002-REVIEW-0.2` / 2026-11-02 | [Current agreement and verification](OD002_STATUS_DECISION_REVIEW.md#8-version-and-verification-record) | Explicit user-approved internal Q1–Q4; scoped BR/JRN/VAR status synchronization, provenance, remaining blockers and next-batch recommendation. No global acceptance freeze or formal policy approval. |

Both supplied packs are byte-identical copies of their Downloads originals. The
October 23 source bundle and Grab workbook are unchanged. The v0.3
`ENGINEERING_DECISIONS_2026-11-02.md` remains byte-identical to its archive member;
unfilled formal reviewer fields do not rescind the four Round 1 agreements or
OD-002's separately recorded Q1–Q4 approval.
