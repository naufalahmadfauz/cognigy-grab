# UC4 Problem #2 — engineering agreements and remaining review

**Date:** 2026-11-03

**Status:** **bounded internal POC agreements recorded** for OD-001/002/003/004/005/008/015; dependent BR/JRN acceptance and formal Grab benchmark/policy approval remain pending; **NOT executed; baseline NOT FROZEN**

**Scope:** business journey classification and defect impact/traceability only. This package does not edit Cognigy, the Python runner, or original source records.

## Round 3 — coupled OD-004 and OD-005 review

[OD004_OD005_TRIGGER_TIMING_REVIEW.md](OD004_OD005_TRIGGER_TIMING_REVIEW.md),
`OD004-OD005-REVIEW-0.2`, records the requesting project-side user's **2026-11-03
qualified Q1–Q7 approval** as **VERIFIED [POC] / ENGINEERING_AGREED_POC**:

- **Q1 Approved:** recent age-only education without an unnecessary goal question;
  no inference that preparation/packing occurred.
- **Q2 Approved conditionally:** requested/accepted navigation priority, including
  same-order age correction; mandatory disclosures and necessary intake retained.
  Beyond-only Tool remains an implementation conflict, with no runtime authorization
  or official early-form acceptance established.
- **Q3 Approved:** TC-027 clear upfront dual request skips unsolicited timing and
  redundant offer; GM notice, computer-Portal transition, preferences and status
  observation remain mandatory where applicable.
- **Q4 Approved as modified, conditional:** clarify only genuinely ambiguous
  assistance; never redundantly clarify clear status requests or add age/loudspeaker
  intake to the existing direct GM status-only exception.
- **Q5 Approved:** answer new timing questions after decline without automatically
  repeating the declined offer; a new explicit request may change branch.
- **Q6 Approved:** explicit cancellation-age fixtures and declared
  **Asia/Kuala_Lumpur (UTC+8)** same-session test assumptions, with documented
  relative expressions; cancellation routing stays distinct from approval after
  order made. Absolute-date/midnight/official-calendar rules remain unresolved.
- **Q7 Approved conditionally:** supported no-photo request continuation with
  available evidence/information and recommendations retained; no promise of
  eligibility, acceptance, completeness or approval. Separately established
  mandatory UI/business conditions require review.

The [approval provenance and superseded wording](OD004_OD005_TRIGGER_TIMING_REVIEW.md#recorded-q1q7-approval-and-provenance)
preserve the user's full qualifications. All seven choices are provisional internal
agreements, **not formal Grab approval**. The completed OD-002 and Round 1 records
remain byte-identical; TC-009 direct submission and the GM status-only exception
retain their scope.

**Current change summary:** recorded approval/provenance, synchronized current
trigger/date/evidence dispositions and TC-027 entry applicability, and distinguished
resolved drafting choices from residual Tool/UI/timing/policy gaps. An eleven-member
snapshot preserves the exact pre-approval ten-document package plus glossary.
Original source fingerprints, benchmark facts, DF statuses and version history remain.

**Next focused batch proposed:** [recent-navigation entry and Tool contract](OD004_OD005_TRIGGER_TIMING_REVIEW.md#remaining-blockers-and-next-focused-review)
under OD-004 Q2. Define admission/correction continuity and independent accepted-
versus-declined coverage before claiming conformance to the agreed priority.

## Round 2 — OD-002 status decision review

[OD002_STATUS_DECISION_REVIEW.md](OD002_STATUS_DECISION_REVIEW.md) is now
`OD002-REVIEW-0.2`. The requesting project-side user approved **Q1–Q4 on 2026-11-02**
as provisional internal POC engineering decisions (`VERIFIED [POC]` /
`ENGINEERING_AGREED_POC`):

- **Q1 / A — Approved:** visible-blank-status review-request fixture for TC-003;
  preserve intent/prerequisites without asserting eligibility or a guaranteed award.
- **Q2 / B — Approved provisionally:** explain reported Auto approved for a
  status-only goal, avoid unnecessary duplicate submission and address concerns.
- **Q3 / C — Approved provisionally:** distinguish approval, payout and bank receipt;
  prioritize explanation/clarification without invented remedies, dates or guarantees.
- **Q4 / D — Approved:** clarify observed status before status-dependent submission.

The [approval provenance](OD002_STATUS_DECISION_REVIEW.md#recorded-q1q4-approval-and-provenance)
records the user's actual authority and superseded proposals. Formal policy
semantics, unpaid-payment remedies and dependent acceptance remain open. The Job
source is unchanged; internal explanation priority is settled, runtime conformance
unverified. Correct B/C handling does **not** complete TC-003 submission coverage;
D counts only if clarification later establishes and exercises A's full target.
Behavior and coverage verdicts remain `NOT_RUN`.

The eight source-pack documents were integrated from the actual v0.3 archive,
then amended only for this addendum's links and current internal decision scope.
The historical decision record and BP memberships are retained. The original
pack's v0.2 README title/stale decision checklist did not supersede its explicit
v0.3 engineering agreements. Latest historical KB/Job evidence was read from the
October 30 export matching the Problem #1 handover hash.

**Round 2 change summary:** versioned OD-002 approval/provenance; synchronized
BR-009, TC-003/VAR-TC-003-A/B/C and linked decision/worksheet status; explicit
remaining blockers and recommended next review batch; archived the exact nine
pre-approval documents. The earlier v0.1 review's source analysis, restored v0.3
family register and glossary additions remain preserved history. No formal Grab
approval or execution is claimed.

## What changed in P2-ENG-DECISIONS-0.3 (2026-11-02)

The user explicitly agreed in the conversation to four **provisional internal engineering directions**. See [ENGINEERING_DECISIONS_2026-11-02.md](ENGINEERING_DECISIONS_2026-11-02.md). The former source contradictions remain documented, no named business/QA reviewers have been assigned, no new Agent runs have been executed, and no acceptance baseline is frozen. The existing 0.2 source classifications and proposed groupings remain draft.

## What changed from P2-DRAFT-0.1

Historical v0.2 change record: that pack was a narrowly revised **copy** of the
five uploaded Markdown drafts. This repository now continues the supplied v0.3
pack; earlier document bytes are preserved in the archives below.

1. `TC_CLASSIFICATION_MATRIX.md`: adds **BP-01 to BP-07** reusable shared process families, a 15-TC primary/secondary/conditional map, and safeguards against turning families into blanket pass or defect labels.
2. `DEFECT_GROUP_IMPACT_MATRIX.md`: adds a **BR-first impact-based regression selection procedure** and a worked DG-005 case, explicitly separating directly reported TCs, plausible applicability and negative controls.
3. `BASELINE_MODEL.md`: classifies **BR-017 as QA_EVIDENCE** and **BR-020 as QA_SEMANTIC_ACCEPTANCE**, leaving the IDs and source provenance unchanged; other BRs remain candidate Agent behavior rules.
4. `JOURNEY_PILOT.md`: adds a compact TC-003/006/027 process-family and review-gate crosswalk.
5. `OPEN_DECISIONS.md`: adds unapproved decision-capture guidance and points to the review worksheet.
6. `REVIEW_DECISION_WORKSHEET.md`: a four-decision **review artifact**, not a decision or authorization.

## Most important distinction

**BP** = shared business-process family; **BR** = source-linked requirement; **JRN** = normalized journey; **TC** = original Grab test; **DF** = original defect report; **DG** = proposed grouping of behavior findings; **VAR** = fixture variant. Their mappings are many-to-many. Group membership does **not** demonstrate a common implementation cause, active failure, or remediation. Review source `BASELINE_MODEL.md` for provenance and authority.

## Next human review (in order)

- [x] Record [OD-002 Q1–Q4](OD002_STATUS_DECISION_REVIEW.md#recorded-q1q4-approval-and-provenance) as bounded internal agreements; preserve separate behavior/coverage verdicts.
- [x] Preserve OD-001 internal choice: TC-006 declined-retry primary; formal benchmark adjudication remains pending.
- [x] Preserve OD-008 internal choice: TC-009 Portal submission-only; formal benchmark adjudication remains pending.
- [x] Preserve OD-003 internal choice: TC-027 explicit App → Portal readiness; formal benchmark adjudication remains pending.
- [x] Preserve OD-015 staged internal POC review governance.
- [x] Record [OD-004/005 qualified Q1–Q7](OD004_OD005_TRIGGER_TIMING_REVIEW.md#recorded-q1q7-approval-and-provenance) as provisional internal agreements; Q4 conditional modification and Q2/Q7 limits explicit.
- [ ] Review OD-004 Q2's remaining recent-entry/Tool contract; preserve the agreed priority and genuine-ambiguity/intake boundaries.
- [ ] Obtain OD-014 policy/UI-owner evidence for early form acceptance, mandatory evidence conditions, statuses/duplicates and approved-but-unpaid remedies; obtain OD-005 official timing/calendar conventions separately.
- [ ] Assign OD-015 business/benchmark and QA reviewers and their approval scope; unfilled formal fields do not reopen the internal choices.
- [ ] Follow with OD-007/010/009 fixture/access/consent boundaries and OD-006/011 GM certainty/controlled text; track OD-012/013 evidence dependencies.
- [ ] Confirm the existing BP taxonomy during scoped review, without restarting classification or expanding the other 12 specifications.

See [remaining blockers and batch outputs](OPEN_DECISIONS.md#remaining-blockers-and-next-review-batch).
**Full Business Acceptance Baseline v1.0 remains unfrozen.** Any later scoped
freeze requires applicable requirement/fixture decisions and named reviewer
sign-off; configuration capture, evidence assessment and execution are later work.

**Do not infer:** 15/15 benchmark passes, 18 open defects, 9 common root causes, formal Grab policy approval, or that a POC configuration change was made. Problem #1 KB v0.3 is separately closed for its verified isolated-POC scope.

## Files

- `BASELINE_MODEL.md`
- `TC_CLASSIFICATION_MATRIX.md`
- `JOURNEY_PILOT.md`
- `DEFECT_GROUP_IMPACT_MATRIX.md`
- `OPEN_DECISIONS.md`
- `REVIEW_DECISION_WORKSHEET.md`
- `ENGINEERING_DECISIONS_2026-11-02.md`
- `OD002_STATUS_DECISION_REVIEW.md`
- `OD004_OD005_TRIGGER_TIMING_REVIEW.md`

The original documents have **repository-relative links** to original sources and other repo files, which resolve when these Markdown files are placed into `docs/problem2/` in the original repo. The ZIP itself does not contain or alter those source assets.

## Version history and preservation

| Version / date | Record / immutable history and SHA-256 | Change scope |
|---|---|---|
| `P2-DRAFT-0.1` / 2026-11-02 | [Local draft snapshot](../../reference/UC4_Problem2_Local_Draft_v0.1_2026-11-02.zip); `e07f611fa420c1bba181de8275d4eb3b7649c37338e65cbf8bb2634ca47c100f` | Preservation ZIP created in Round 2 from the five untouched pre-edit local files; not a newly discovered external release. |
| `P2-DRAFT-0.2` / 2026-11-02 | [Supplied structural pack](../../reference/UC4_Problem2_Structural_Review_Pack_v0.2.zip); `175d562783fbaec5f731a7f59861eb53d55def151882c872c856a6ac76fc9ea1` | BP-01–BP-07, requirement kinds, BR-led regression selection and review worksheet. |
| `P2-ENG-DECISIONS-0.3` / 2026-11-02 | [Supplied engineering pack](../../reference/UC4_Problem2_Engineering_Review_Pack_v0.3.zip); `3244e5ec8ae7cdd28a76dd3f4aec144ebbf34fa56a83b5b23b24be5080463606` | Four limited agreements and dedicated decision record. TC classification/defect matrix identical to supplied v0.2; other overlays preserved in this archive. |
| `OD002-REVIEW-0.1` / 2026-11-02 | [Pre-approval nine-document snapshot](../../reference/UC4_Problem2_OD002_Review_v0.1_2026-11-02.zip); `9e34da889adf7847a6d519bf75dd60a7a6e900767876a3a9d8c53da298dd595e` | Exact local state before Q1–Q4 were recorded as agreed: questions, proposals, source/dependency analysis and previous audit retained. Local preservation archive, not an externally supplied release. |
| `OD002-REVIEW-0.2` / 2026-11-02 | [Unchanged agreement](OD002_STATUS_DECISION_REVIEW.md#8-version-and-verification-record); [pre-Round-3 snapshot](../../reference/UC4_Problem2_OD002_Review_v0.2_2026-11-03.zip), `79f89595cdffd363504a5a54e4f5d1a0dab39681b8a1c0893443667f27f5c202` | Explicit user-approved internal Q1–Q4. Snapshot created 2026-11-03 preserves all nine documents and the glossary before this review; no new approval is inferred from preservation. |
| `OD004-OD005-REVIEW-0.1` / 2026-11-03 | [Pre-approval eleven-member snapshot](../../reference/UC4_Problem2_OD004_OD005_Review_v0.1_2026-11-03.zip); `1194f6dcf1a230bd42ad925035c843943018196dd10688c0e00e554fdf850460` | Exact ten-document package and glossary before approval recording: proposed trigger/timing choices, original seven questions, source conflicts, shared impact and v0.1 audit. |
| `OD004-OD005-REVIEW-0.2` / 2026-11-03 | [Qualified approval record](OD004_OD005_TRIGGER_TIMING_REVIEW.md#recorded-q1q7-approval-and-provenance); [version/audit record](OD004_OD005_TRIGGER_TIMING_REVIEW.md#7-history-and-verification) | User's qualified Q1–Q7 agreements, synchronized applicability and residual Tool-contract/UI/timing/policy blockers. No formal approval, execution or baseline freeze. |

Both supplied packs are byte-identical copies of their Downloads originals. The
October 23 source bundle and Grab workbook are unchanged. The v0.3
`ENGINEERING_DECISIONS_2026-11-02.md` remains byte-identical to its archive member;
unfilled formal reviewer fields do not rescind the four Round 1 agreements,
OD-002's separately recorded Q1–Q4 approval or the qualified OD-004/005 Q1–Q7
internal agreement. Their different authority and execution scopes remain explicit.
