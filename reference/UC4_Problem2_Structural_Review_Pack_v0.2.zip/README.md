# UC4 Problem #2 — Structured Review Pack, P2-DRAFT-0.2

**Date:** 2026-11-02  
**Status:** **proposed review package; NOT approved; NOT executed**  
**Scope:** business journey classification and defect impact/traceability only. This package does not edit Cognigy, the Python runner, or original source records.

## What changed from P2-DRAFT-0.1

This is a narrowly revised **copy** of Codex's five uploaded Markdown drafts. The original files remain untouched.

1. `TC_CLASSIFICATION_MATRIX.md`: adds **BP-01 to BP-07** reusable shared process families, a 15-TC primary/secondary/conditional map, and safeguards against turning families into blanket pass or defect labels.
2. `DEFECT_GROUP_IMPACT_MATRIX.md`: adds a **BR-first impact-based regression selection procedure** and a worked DG-005 case, explicitly separating directly reported TCs, plausible applicability and negative controls.
3. `BASELINE_MODEL.md`: classifies **BR-017 as QA_EVIDENCE** and **BR-020 as QA_SEMANTIC_ACCEPTANCE**, leaving the IDs and source provenance unchanged; other BRs remain candidate Agent behavior rules.
4. `JOURNEY_PILOT.md`: adds a compact TC-003/006/027 process-family and review-gate crosswalk.
5. `OPEN_DECISIONS.md`: adds unapproved decision-capture guidance and points to the review worksheet.
6. `REVIEW_DECISION_WORKSHEET.md`: a four-decision **review artifact**, not a decision or authorization.

## Most important distinction

**BP** = shared business-process family; **BR** = source-linked requirement; **JRN** = normalized journey; **TC** = original Grab test; **DF** = original defect report; **DG** = proposed grouping of behavior findings; **VAR** = fixture variant. Their mappings are many-to-many. Group membership does **not** demonstrate a common implementation cause, active failure, or remediation. Review source `BASELINE_MODEL.md` for provenance and authority.

## Next human review (in order)

- [ ] Confirm that BP family membership correctly groups business capabilities (not just similar dialogue).
- [ ] Validate TC-003 observed status vs original submission coverage; inspect OD-002 and related policy conditions.
- [ ] Decide OD-001 (TC-006 decline versus accepted retry).
- [ ] Decide OD-008 (TC-009 status versus submit-only target).
- [ ] Decide OD-003 (TC-027 explicit App → Portal transition).
- [ ] Assign OD-015 reviewers and approval scope; unresolved issues stay UNKNOWN/CONFLICT.
- [ ] Once the appropriate reviewers approve, freeze a versioned **business acceptance baseline**, then take an independent snapshot of the **currently served Agent** before behavior comparisons.

**Do not infer:** 15/15 benchmark passes, 18 open defects, 9 common root causes, formal Grab policy approval, or that a POC configuration change was made. Problem #1 KB v0.3 is separately closed for its verified isolated-POC scope.

## Files

- `BASELINE_MODEL.md`
- `TC_CLASSIFICATION_MATRIX.md`
- `JOURNEY_PILOT.md`
- `DEFECT_GROUP_IMPACT_MATRIX.md`
- `OPEN_DECISIONS.md`
- `REVIEW_DECISION_WORKSHEET.md`

The original documents have **repository-relative links** to original sources and other repo files, which resolve when these Markdown files are placed into `docs/problem2/` in the original repo. The ZIP itself does not contain or alter those source assets.
