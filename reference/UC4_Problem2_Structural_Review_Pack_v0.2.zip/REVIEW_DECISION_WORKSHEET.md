# UC4 Problem #2 — Round 1 business/benchmark decision worksheet

**Package:** P2-DRAFT-0.2 — STRUCTURAL REVIEW ADDENDUM  
**Status:** Review-ready, **no approvals recorded**.  
**Input authority:** October 23 Problem #2 PLAN/PB; Grab benchmark workbook (immutable); KB v0.3 POC source decisions; existing `OPEN_DECISIONS.md`.  
**Use:** Record selections from named benchmark/business and QA reviewers. An LLM recommendation cannot approve or change a business rule.

## The four decisions to take to review

| OD | Issue and source evidence | Candidate option A (recommended for review; NOT approved) | Alternative / why it matters | Current state |
|---|---|---|---|---|
| OD-001 | TC-006 `WB:S!D9` expects retry declined, while `E9` accepts re-login and successful form submission | Keep D9 declined retry/soft close as **proposed** original fixture; keep accepted/success as `VAR-TC-006-A`; failed retry separately | Stakeholder could choose E9 as original target. Either way preserve both and specify fixture; don't fabricate consensus. | CONFLICT; original TC coverage BLOCKED_SPEC |
| OD-008 | TC-009 `WB:S!D12` says Portal *status*, `E12` explicitly declines status and requests submission only | Use E12 Portal submission + failed retry + separate consented mock transfer as **proposed** original fixture | If D12 is required, confirm supported GF Portal status route before requiring it; current KB supports GF App status. | CONFLICT; original TC coverage BLOCKED_SPEC |
| OD-003 | TC-027 `WB:S!E16` selects App, then shifts into Portal Finance/Transactions; `F16` says Portal-only for GM status | Keep App selection; explicitly explain computer Portal status route, confirm Portal readiness and preserve style | Portal unavailable needs separate supported recovery/consent; don't silently treat App as Portal. | CONFLICT; target fixture review pending |
| OD-015 | Reviewer ownership/acceptance scope/sample count not assigned | Assign business/benchmark owner and QA reviewer; sign off only on chosen fixture/BR applicability with version and date | Without reviewer authority, mark draft and don't convert proposed instructions into Grab policy. | PROPOSED; no approvals |

## Human review record — leave unfilled until genuine approval

| OD | Selected option / alternative | Business or benchmark reviewer | QA reviewer | Date | Approval scope and rationale | Impacted BR/JRN/VAR version | Decision state |
|---|---|---|---|---|---|---|---|
| OD-001 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | BR-012/014/015; JRN-TC-006; VAR-TC-006-A/B | CONFLICT |
| OD-008 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | BR-009/011/012/015; JRN-TC-009 | CONFLICT |
| OD-003 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | BR-005/008; JRN-TC-027; TC-029 comparison | CONFLICT |
| OD-015 | _pending_ | _unassigned_ | _unassigned_ | — | _not decided_ | Review framework and high-risk sampling | PROPOSED |

## Reviewer checklist

- [ ] Confirm the two separate questions for each fixture: Agent behavior on observed branch and coverage of intended original TC.
- [ ] Confirm the proposed target and any distinct test variant, without overwriting Grab's workbook.
- [ ] Check BR source authority and its **POC adoption** vs **formal business approval** boundary.
- [ ] Identify which requirements are business obligations versus QA/evidence rules.
- [ ] Review priority OD-002 (Auto approved/status meaning), OD-004 (education applicability), OD-007 (conditional History/date recovery), OD-010 (role reminder applicability), and OD-006 (GM partial notice wording) before making corresponding branch assertions binding.
- [ ] Record an owner, date, rationale, changed versions, evidence and dissent/unresolved status.
- [ ] Only after review, approve a baseline version and separately authorize any live retesting. No Python or live Cognigy modifications are authorized by this worksheet.

**After these decisions:** normalize all 15 journey acceptance conditions and grouped-defect mappings, then evaluate saved runtime evidence or specifically authorized new runs. Retain both historical and new verdicts; never mark all 15 as tested because KB coverage passed separately.
