# UC4 Problem 2 — Benchmark Journey & Defect Traceability Playbook

**Project:** GrabFood / GrabMart Malaysia cancelled-order compensation voice Agent (Cognigy)  
**Checkpoint:** 2026-10-23 | **Record version:** 1.0 | **Purpose:** LLM/developer operational context  
**Decision status:** Approach agreed in discussion; conversion of individual TCs, branch policies, and stakeholder acceptance are **not yet executed or approved**.  
**Safety boundary:** Documentation/planning only. Do not edit a live Flow, Agent Job, Knowledge Store, original benchmark, or officially reported defect history on the basis of this document.

## 0. Current state and source hierarchy

- Problem 1 (Knowledge Base) and recent defects, including DF-014 and DF-018, are **resolved per user's 2026-10-23 status update**. Do not reopen merely because the older workbook/handover shows earlier statuses.
- Source workbook inspected: `Grab_UC4_Benchmark_Test_Scenarios_Feedback (3).xlsx`, SHA-256 `12e17ad51b6ee2053a4e2c56d3ae8b5ff56f544a6f9a1487dd274c05af5c797e`.
- Workbook snapshot: `Scenarios` has **15 benchmark TC rows** (TC-001–TC-010 and TC-025–TC-029); `Defect Log` has **18 DF rows** (DF-001–DF-018), not necessarily 18 valid unresolved defects. Seven DF rows are categorized `Missing or changed verbatim line` and require semantic reclassification, not automatic dismissal.
- **Authority:** Approved Grab-supplied project KB/policy > validated supplementary official Grab sources for missing coverage > explicitly reviewed project-authored rules. The benchmark is a test artifact, **not independent proof of policy**. If benchmark, policy and runtime disagree, record a conflict and ask for named review; never silently invent policy or move acceptance criteria to accommodate the Agent.
- Stakeholder clarification from meeting: **Grab evaluates correct merchant outcome through the correct business process, not exact transcript wording.** Exact approved terms/disclosures remain mandatory where explicitly designated.

## 1. Agreed decisions (D-01 through D-12)

| ID | Decision / invariant |
|---|---|
| D-01 | Retain Grab's original Excel as the immutable stakeholder reference; build an internal normalized acceptance model alongside it. Do not rename Grab TC/DF IDs. |
| D-02 | Replace transcript-matching as the main acceptance method with **business-journey evaluation**: starting state, merchant goal, mandatory milestones, conditional decisions, authorized outcome, and forbidden behaviors. |
| D-03 | Treat each sample transcript as **one illustration** of a possible conversation. Natural paraphrases and adaptive clarifications are allowed if the meaning and required process are preserved. |
| D-04 | Journey ordering is **dependency-based**: identify which milestones must precede others, and which are conditional. Do not convert all dialogue into a rigid linear state machine. |
| D-05 | Always check relevant status and merchant intent before choosing a submission branch; a single example does not authorize duplicate submissions or unsupported escalations. |
| D-06 | Separate mandatory business facts/disclosures, mandatory sequence/decision constraints, and flexible conversational phrasing. Consequence determines severity—not whether a step happens to be called a sequence check. |
| D-07 | Introduce stable internal **BR** (business requirement), **JRN** (journey), and **VAR** (test variant) IDs, with many-to-many mappings to existing **TC** and **DF** IDs. |
| D-08 | One DF report may contain several **atomic findings**; one root-cause requirement may affect many DF reports and TCs. Do not merge or alter official DF rows; use child findings internally. |
| D-09 | Alternative branches inferred by AI are **proposals**, never policy truth. Human/Grab owner confirms, rejects, or marks unresolved before a new binding acceptance criterion or live fix. |
| D-10 | Separate **correct Agent handling of the observed branch** from **completion of the original TC's intended coverage**. If a submission TC takes an already-approved branch, the branch can be correct while the targeted submission test remains unexecuted. |
| D-11 | Fix the violated **shared business behavior**, not a hardcoded TC transcript. Diagnose prompt vs Knowledge, Tool, Code, context, ASR, simulator, test setup before selecting an implementation. |
| D-12 | Evidence-driven closure: linked requirement, fix diff, affected TC/variant regression, actual transcript/tool traces and review. A single passing simulation is insufficient for a stability claim. |

## 2. Terms and relationships

- **BR-### — Business requirement:** A verifiable normative rule with source, applicability, evidence and owner. Example *candidate*, `BR-GF-STATUS-001`: If a status is already approved, do not unnecessarily guide a second claim; verify actual approved status semantics before activation.
- **JRN-TC-### — Business journey specification:** Human-readable state/goal/decisions/milestones/allowed outcomes/constraints and exceptions, normalized from a TC and approved rules.
- **VAR-TC-###-A/B — Scenario variant:** A distinct initial state or merchant response that should test a different branch without inventing a new Grab-issued TC ID.
- **TC-### — Grab benchmark test:** Original external evaluation case; preserves external numbering and requested target journey.
- **DF-### — Grab defect log report:** Original external report; status history preserved. Use internal `DF-###/F01` etc for independent findings when necessary.
- **Fix / change:** Reviewed implementation change with Git/ZIP identity and diff; may address several BRs/findings; implement only after triage.
- **Evidence:** Baseline identifier, actual user utterances, spoken and displayed responses (where relevant), Tool/Code/context traces, pass/fail reason, tester and timestamp.

Relationships are many-to-many: `BR <-> JRN/VAR <-> TC <-> DF finding <-> fix <-> execution evidence`. A reported failure in one TC does **not** mean the implementation must be TC-specific.

## 3. Required journey specification schema

Every normalized journey should define:

1. **Identity/provenance:** JRN ID, original TC, LOB, worksheet row/version and preparer/reviewer.
2. **Goal & scope:** Merchant's question/outcome, what the TC specifically intends to exercise, preconditions, language/channel, dates and time threshold assumptions.
3. **Scenario fixture:** Simulated merchant statements and **branch-driving status** (e.g., not compensated) so the original target route is testable.
4. **Milestones:** `M01...` required capabilities/checkpoints, not exact speeches. Mark `always`, `if ...`, or `not applicable`.
5. **Dependency edges:** e.g., policy education before navigation; status observation before deciding on claim; explicit consent before transfer; single action/checkpoint in one-by-one.
6. **Decision table:** Merchant-observed value, interpretation, permitted next move, forbidden move, source/approval status, unresolved questions.
7. **Factual assertions:** Required claim IDs / KB provenance; note any exact approved language separately, otherwise semantic equivalence is accepted.
8. **Acceptable variation:** Natural phrasing, clarifications, different turn counts, approved route recovery without breaking invariant ordering.
9. **Negative assertions:** Forbidden premature closing, duplicate claim, fabricated status, omitted role guidance, reasking collected preferences, unsupported handoff, etc. Apply only where approved/relevant.
10. **Acceptance verdict:** `PASS`, `FAIL`, `INCOMPLETE_COVERAGE`, `BLOCKED_SPEC`, `BLOCKED_ENV`, `NOT_RUN`, or `NEEDS_REVIEW` with evidence and branch reached.
11. **Traceability:** Linked BRs, variants, DF/findings, owner/review status and affected regression group.

Do **not** require a greeting or disclaimer phrased word-for-word unless an approved exact wording requirement exists. Conversely, semantic flexibility is not permission to omit a policy, instruction, consent or step.

## 4. Worked case: TC-003 / DF-017 — compensation status

**What the workbook actually says:** TC-003 is a GrabFood beyond-threshold status-then-submission scenario. DF-017 notes that an order showing `Auto approved` should not need another Request for Compensation, and highlights that real Agent status guidance adapts to the merchant's observed screen. DF-017 is *feedback within the workbook*, not by itself an independently approved policy.

**Proposed normalized decision (requires approval against current KB):**

| Merchant-observed state / goal | Candidate outcome | Original TC-003 submission coverage |
|---|---|---|
| Not compensated + eligible + merchant wants to submit | Complete suitable status check, explain applicable policy, guide appropriate form/evidence, confirm self-submission and close. | **Covered** if all mandatory steps exercised. |
| `Auto approved`, merchant only requested confirmation | Explain the approved status and relevant payout stage; avoid redundant submission; offer further help/close. | **Not covered**: correct alternative behavior, but must rerun target submission fixture. |
| `Auto approved`, merchant says money not received | Distinguish approval from payout/bank arrival; consult approved KB and supported status/payout path, or clarify/escalate if policy requires. | **Not covered** until submission route is independently exercised. |
| Unclear or conflicting status | Ask one relevant clarification; do not assert approval or instruct submission without sufficient facts. | **Incomplete/needs review**, not automatic success. |

**Policy guardrail:** Do not claim `Auto approved = money deposited`. Whether retry, payout checks or escalation are required must be sourced and confirmed.

**Example regression IDs (internal only):** `VAR-TC-003-A` = already approved/status only, `VAR-TC-003-B` = approved/not received, `VAR-TC-003-C` = status unclear. Original `TC-003` remains the happy-path submission target.

## 5. Two further benchmark issues to reconcile

- **TC-006 inconsistency:** Its `Expected flow path` says the merchant **declines retry**, while the sample transcript has a merchant **agreeing to re-login and succeeding**. Do not choose one silently. Create `SPEC_CONFLICT` ticket, propose a primary fixture and optional separate variant, request human/stakeholder confirmation.
- **TC-027 portal transition:** The sample merchant selects **GrabMerchant App**, then the script proceeds through **Finance > Transactions** portal actions. The intended business route may require an explicit *computer-portal redirect* before those steps. Verify the approved navigation source and mark the transcript's transition as a candidate scenario clarification, not an instruction to make the Agent ignore platform state.
- **TC-004 illustrative offer/continuation:** If a step offers guidance, the Agent should respect response/wait requirements rather than assume acceptance merely because the sample dialogue omits a merchant turn. Flag where approval is needed.

## 6. Acceptance and severity rubric

| Class | Evaluate | Example | Verdict |
|---|---|---|---|
| **Business/factual hard** | Correct policy, eligibility, disclosures, merchant consent and authorized outcome | Skip required compensation policy or transfer without consent | FAIL when applicable; severity by merchant harm |
| **Sequence/dependency hard** | Preconditions, checkpoint ordering, branch selection | Submission before required status check; combine two one-by-one actions | FAIL when required; severity depends on impact |
| **Flexible conversational** | Natural wording, acknowledgements and clarifications | “Choose Finance” instead of “Open Finance” | PASS if meaning and action preserved |
| **Exact controlled text** | Designated wording approved by policy owner | Required partial-compensation sentence | FAIL if exactness is actually mandated and materially altered |
| **Coverage/fixture** | Did this run exercise the intended branch? | Already-approved branch in a submission TC | INCOMPLETE_COVERAGE; record branch behavior separately |
| **Specification conflict** | Contradictory/incomplete normative expected behavior | TC-006 decline vs retry | BLOCKED_SPEC; no invented requirement |
| **Environment/ASR** | Channel/test inputs and transcript fidelity | Barge-in causes displayed/spoken divergence | BLOCKED_ENV or separate defect after evidence |

Never decide severity solely by spreadsheet category `Missing or changed verbatim line`. Grade actual process, business risk, consent/safety, customer impact and recurrence. Preserve the official severity and record a proposed internal triage assessment separately.

## 7. Defect-triage and retest protocol

**Intake:** Preserve external DF record unchanged. Link to original TC, transcript, timestamp, benchmark version and stated merchant input.

**Normalize:** Split compound DF into atomic findings (`DF-014/F01` policy-before-navigation, `/F02` missing status steps, `/F03` portal-unavailable recovery—examples of findings from historical report, not newly open defects). Distinguish actual observed failure from tester's explanation/hypothesis.

**Classify:** `CONFIRMED_BEHAVIOR`, `WORDING_ONLY`, `BENCHMARK_CONFLICT`, `UNKNOWN_POLICY`, `ENVIRONMENT_ASR`, `TEST_FIXTURE_ISSUE`, `NOT_A_DEFECT`, `NEEDS_MORE_EVIDENCE`. A category is a review result, not an automatic resolution.

**Trace:** Link each finding to 1+ BR and impacted JRN/VAR cases; if BR not in catalog, draft a **proposed** BR with provenance and approver. Do not modify implementation for unsupported guesses.

**Diagnose:** Check approved KB/claims; Agent persona and Job; Tool contracts and params; Code; Context/state; Flow wiring; simulator/WebRTC input; ASR/barge-in. Identify a defensible root cause and choose the smallest solution; keep behavior Agent-led where appropriate.

**Implement:** Use a fresh and identified Flow/Agent baseline, track hashes, review diff, protect frozen `[MAIN]`, retain rollback. Changes to Code or custom params require documented purpose, contract, edge cases and alternatives considered (Problem 3/4 dependency).

**Retest:** Run (i) original targeted TC under correct fixture, (ii) alternative branches linked by BR, (iii) neighboring TCs for same LOB / feature, and (iv) relevant regression or voice modality. Proposed initial sampling: five **independent fresh sessions** per high-risk journey, plus the benchmark's stipulated external repetition requirement where applicable. Five passes are not proof of certainty; any failure must be recorded/investigated.

**Closure gates:** Distinguish `DF_REMEDIATED`, `TC_PASS`, `VAR_PASS`, `STAKEHOLDER_ACCEPTED`, `RELEASED`; do not infer one from another. User's latest declaration closes recent historic defects even though the workbook snapshot still has old statuses.

## 8. Execution plan (P0–P7)

| Phase | Actions | Evidence/output | Exit gate |
|---|---|---|---|
| **P0. Preserve inputs** | Hash/record benchmark; copy it read-only; capture last approved KB/policy refs and test environment info. | Source manifest; owner and review list. | Unambiguous baseline and no silent changes to Grab's Excel. |
| **P1. Extract normative content** | Read all 15 Scenarios. Separate facts, intent, mandatory steps, decisions, exact-language claims and illustrative dialogue. | First-pass per-TC extraction; question/conflict list. | No requirement is sourced solely from example wording without status label. |
| **P2. Normalize journeys** | Produce `JRN-TC-###` with milestones, dependencies, successful outcome and fixture. | Journey catalog for all 15 TCs; reviewable diffs. | Each case can be evaluated semantically without a verbatim transcript. |
| **P3. Discover alternatives** | Enumerate materially different outcomes, recovery branches, eligibility/status/role/consent distinctions. Classify VERIFIED / PROPOSED / UNKNOWN / CONFLICT. | Branch/variant register, source links, priority. | No proposed AI inference silently becomes an approved policy. |
| **P4. Human/Grab review** | Resolve ambiguous TCs such as TC-006; validate selected BRs with supplied KB and stakeholders. | Signed requirement baseline and unresolved decision log. | High-impact expected outcomes have named approval; unresolved ones remain blocked. |
| **P5. Map Defect Log** | Reclassify all 18 DF rows; split compound findings; map findings many-to-many to BR/TC/VAR; preserve original reported status. | Defect-traceability matrix, triage rationale. | Each genuine finding has testable requirement + owner + evidence or explicit pending state. |
| **P6. Pilot evaluation** | Choose TC-003, TC-006 and TC-027; annotate existing executions and run fresh targeted + variant sessions without live edits. | Sample annotated test reports, pass/fail and coverage notes. | Two reviewers can reach consistent verdicts from same evidence. |
| **P7. Operationalize** | Freeze a versioned acceptance baseline; connect to Git/change process and later scenario/simulator batch regression (Problems 4/5). | Reusable fixture/report schemas, ownership and change-control procedure. | Change of BR/JRN version triggers impacted TC regression and release approval. |

**Prioritize:** P0-P2 first, then review high-risk policy/consent/role/status/portal alternatives; do not author endless low-value branches. P6 can pilot early once representative journeys are drafted, but *do not claim a signed business baseline until P4*.

## 9. Approval and branching policy

Use these labels on every inferred decision/variant:

- `VERIFIED`: Source-backed **and** reviewed/approved for this UC4 context. Cite claim/KB ID or explicit Grab decision.
- `PROPOSED`: Plausible interpretation inferred from benchmark, merchant intent or product logic. Not binding; human reviews.
- `UNKNOWN`: Required policy, UI behavior or permitted recovery cannot be established. Clarify; do not invent.
- `CONFLICT`: Two sources/columns disagree. Preserve both and record resolution authority.

A valid alternate branch may end in normal closing, clarifying a still-unresolved merchant concern, an authorized recovery route, or consented mock transfer. **Do not force unknown → automatic transfer** and do not infer that a UI status alone resolves the merchant's goal.

## 10. Minimum machine-readable record templates

These are templates for future structured files; they are **not** a claim that current 15 journeys or 18 reports have already been converted.

```yaml
journey_id: JRN-TC-003
source_tc: TC-003
lob: GrabFood
state: DRAFT                 # DRAFT | REVIEWED | APPROVED
merchant_goal: "Check compensation status and, if needed, submit an eligible request"
fixture:
  age_condition: beyond_threshold
  status: not_compensated   # drives original happy-path submission test
  intent: status_then_submit
source_refs:
  benchmark: "Scenarios!row 6"
  policy_claim_ids: []     # must populate from approved catalog
milestones:
  - id: M01
    action: "Identify merchant's goal and applicable order context"
    requirement_ids: []
  - id: M02
    action: "Explain applicable policy when required"
    requirement_ids: []
  - id: M03
    action: "Check order status using appropriate guided route"
    requirement_ids: []
  - id: M04
    action: "Choose submission only if status, eligibility, and request support it"
    requirement_ids: []
required_before:
  - [M03, M04]
branches:
  - variant: VAR-TC-003-A
    if: "merchant reports Auto approved"
    proposed_action: "Explain approval and payout stage; avoid unnecessary re-claim"
    approval: PROPOSED
    required_policy_review: true
forbidden:
  - "Assert unobserved compensation status"
  - "Treat approved as evidence of bank receipt"
linked_defects: [DF-017]
coverage_rule: "A correct alternative branch does not complete original submission coverage"
```

```yaml
defect_finding_id: DF-014/F01
external_df_id: DF-014
source_tc: TC-027
finding: "Required compensation policy education occurred after navigation began"
observed_evidence: "Original workbook Defect Log!row 18; verify against run"
classification: CONFIRMED_BEHAVIOR   # example hypothesis, must be reviewer-validated
requirement_ids: []
impacted_journeys: [JRN-TC-027]
root_cause: UNCONFIRMED
fix_id: null
status: HISTORICAL_RESOLVED_PER_USER
retest_evidence: []
```

```yaml
execution_id: "<timestamp-session-id>"
acceptance_version: "<approved-version>"
tc_id: TC-003
variant_id: null
run_id: 1
fresh_session: true
channel: WebRTC
requested_target: "status_then_submit"
observed_branch: "auto_approved"
behavior_verdict: NEEDS_REVIEW
coverage_verdict: INCOMPLETE_COVERAGE
failed_requirement_ids: []
evidence_links: []
notes: "Separate behavior correctness from target path coverage"
```

## 11. Definition of done — Problem 2 process

This **documentation checkpoint** is complete when the plan is approved for use. The **implementation work** is complete only when:

- [ ] All 15 benchmark cases have reviewed journey specs and source references.
- [ ] Required policy/conditional claims link to approved KB/source; unresolved assumptions are visibly marked.
- [ ] Major contradictions (beginning with TC-006 and TC-027) have explicit reviewer decisions.
- [ ] All 18 reported DF rows are mapped or explicitly classified as `NOT_A_DEFECT`, `NEEDS_EVIDENCE`, etc.; original report preserved.
- [ ] Critical alternatives and recovery branches have an approved prioritization and validation status.
- [ ] A representative pilot demonstrates semantic pass/fail judgments and separate branch-coverage decisions.
- [ ] Stable baseline IDs, owner, review dates and regression evidence conventions exist.
- [ ] No changes were made to deployed Cognigy assets merely by writing this plan.

## 12. Handoff instructions for future LLMs

1. Begin by reading this document and the companion formatted decision record `UC4_Problem2_Benchmark_Journey_Decision_and_Action_Plan_2026-10-23.docx`.
2. Request the exact workbook/KB/current Flow baseline if implementation requires it; never assume archived IDs, historical ZIPs or older defect statuses are live.
3. Do **not** equate a changed phrase with a defect; compare semantically to an approved milestone and evaluate exceptions.
4. When creating candidate journeys, tag every inferred policy branch `PROPOSED` and surface conflicts instead of resolving them autonomously.
5. Never fabricate expected outcomes, thresholds, role policy, screen routes, payout timing, or permitted transfers. Confirm via approved KB or owner.
6. Preserve Grab TC/DF IDs and split compound findings only as internal subidentifiers. Maintain traceability through code/config diff and test evidence.
7. Address the source requirement, then run the exact requested scenario and adjacent alternative paths; never mark a targeted TC as covered by an unrelated successful branch.
8. Follow Problems 3–5 for Code/Tool justification, version control and simulator automation when those plans are agreed. No Agent Job patch merely to match a transcript.

## Related records and next action

- Original stakeholder reference: `Grab_UC4_Benchmark_Test_Scenarios_Feedback (3).xlsx`, tabs `Scenarios`, `Defect Log`.
- Project handover context: `UC4_NEW_CHAT_HANDOVER_2026-10-23.md`; Problem 1 decision record and source-of-truth governance.
- **Immediate next action (after approval):** Draft normalized journeys for TC-003, TC-006 and TC-027, with a contradiction/branch review sheet. Use those to validate the approach before converting the other 12 cases. **This document does not claim that work has been done.**
